



// Menu icon and navbar toggle
let menuIcon = document.querySelector("#menu-icon");
let navbar = document.querySelector(".navbar");

menuIcon.addEventListener('click', () => {
    menuIcon.classList.toggle('bx-x'); // Toggles the menu icon to an 'x' when clicked
    navbar.classList.toggle('active'); // Toggles the navbar visibility
});

// Sticky navbar
window.onscroll = () => {
    let header = document.querySelector('.header');
    header.classList.toggle('sticky', window.scrollY > 100);

    // Remove menu icon and hide navbar when scrolling
    if (navbar.classList.contains('active')) {
        menuIcon.classList.remove('bx-x');
        navbar.classList.remove('active');
    }
    
};

// Initialize swiper
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 50,
    loop: true,
    grabCursor: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});

// Dark mode and light mode toggle
let darkModeIcon = document.querySelector('#darkMode-icon');

darkModeIcon.onclick = () => {
    darkModeIcon.classList.toggle('bx-sun');
    document.body.classList.toggle('dark-mode');

    if (document.body.classList.contains('dark-mode')) {
        applyMode(darkMode);
    } else {
        applyMode(lightMode);
    }
};

// Set initial mode
document.addEventListener('DOMContentLoaded', () => {
    applyMode(lightMode);
});




// Resize handling
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
});

document.addEventListener("DOMContentLoaded", function() {
    let nextBtn = document.querySelector('.next');
    let prevBtn = document.querySelector('.prev');
    let slider = document.querySelector('.slider');
    let sliderList = slider.querySelector('.list');
    let thumbnail = document.querySelector('.thumbnail');
    let sliderItems = sliderList.querySelectorAll('.item');
    let thumbnailItems = thumbnail.querySelectorAll('.item');

    // Set the first slide as active initially
    sliderItems[0].classList.add('active');

    nextBtn.onclick = function() {
        moveSlider('next');
    };

    prevBtn.onclick = function() {
        moveSlider('prev');
    };

    function moveSlider(direction) {
        let activeSlide = sliderList.querySelector('.item.active');
        activeSlide.classList.remove('active');

        if (direction === 'next') {
            sliderList.appendChild(sliderItems[0]);
            thumbnail.appendChild(thumbnailItems[0]);

            // Requery the sliderItems and thumbnailItems after DOM changes
            sliderItems = sliderList.querySelectorAll('.item');
            thumbnailItems = thumbnail.querySelectorAll('.item');

            sliderItems[0].classList.add('active');
        } else if (direction === 'prev') {
            sliderList.prepend(sliderItems[sliderItems.length - 1]);
            thumbnail.prepend(thumbnailItems[thumbnailItems.length - 1]);

            // Requery the sliderItems and thumbnailItems after DOM changes
            sliderItems = sliderList.querySelectorAll('.item');
            thumbnailItems = thumbnail.querySelectorAll('.item');

            sliderItems[0].classList.add('active');
        }

        // Remove transition classes after animation ends
        slider.addEventListener('animationend', function() {
            slider.classList.remove('next');
            slider.classList.remove('prev');
        }, { once: true });

        // Trigger the correct animation class based on direction
        slider.classList.add(direction);
    }
});
//Filter
$(document).ready(function () {
    $(".filter-item").click(function () {
        const value = $(this).attr("data-filter");

        // Toggle active class for filter items
        $(this).addClass("active-filter").siblings().removeClass("active-filter");

        // Filter posts with fade in/out effect
        if (value == "all") {
            $(".post-box").fadeIn(500); // Fade in all posts
        } else {
            $(".post-box").fadeOut(200).filter("." + value).fadeIn(500); // Fade out all posts, then fade in filtered posts
        }
    });
});
