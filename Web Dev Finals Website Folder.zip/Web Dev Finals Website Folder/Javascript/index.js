window.addEventListener('load', () => {
    const preloader = document.querySelector('.preloader');
    setTimeout(() => {
        preloader.classList.add('hidden'); // Adds class to fade out and hide preloader
    }, 500); // Increased delay to 4 seconds before fading out
});




// Menu icon and navbar toggle
let menuIcon = document.querySelector("#menu-icon");
let navbar = document.querySelector(".navbar");

menuIcon.addEventListener('click', () => {
    menuIcon.classList.toggle('bx-x'); // Toggles the menu icon to an 'x' when clicked
    navbar.classList.toggle('active'); // Toggles the navbar visibility
});

// Sticky navbar
window.onscroll = () => {
    let header = document.querySelector('.header');
    header.classList.toggle('sticky', window.scrollY > 100);

    // Remove menu icon and hide navbar when scrolling
    if (navbar.classList.contains('active')) {
        menuIcon.classList.remove('bx-x');
        navbar.classList.remove('active');
    }
    
};

// Initialize swiper
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 50,
    loop: true,
    grabCursor: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});

// Dark mode and light mode
let darkModeIcon = document.querySelector('#darkMode-icon');

darkModeIcon.onclick = () => {
    darkModeIcon.classList.toggle('bx-sun');
    document.body.classList.toggle('dark-mode');
}

// Scroll reveal
ScrollReveal({
    reset: true,
    distance: '80px',
    duration: 2000,
    delay: 200,
});

// Reveal elements with ScrollReveal
ScrollReveal().reveal('.home-content h3, .home-content h1, .home-content p', { origin: 'top' });
ScrollReveal().reveal('.home-img img, .services-container, .portfolio-box, .testimonial-wrapper, .contact form', { origin: 'bottom' });
ScrollReveal().reveal('.home-content h1, about-img img', { origin: 'left' });
ScrollReveal().reveal('.home-content h3, .homecontent p, .about-content ', { origin: 'right' });

document.addEventListener('DOMContentLoaded', function() {
    const leftBtn = document.querySelector('.leftbtn');
    const rightBtn = document.querySelector('.rightbtn');
    const hotcards = document.querySelector('.hotcards');

    leftBtn.addEventListener('click', () => {
        hotcards.scrollBy({
            top: 0,
            left: -200,
            behavior: 'smooth'
        });
    });

    rightBtn.addEventListener('click', () => {
        hotcards.scrollBy({
            top: 0,
            left: 200,
            behavior: 'smooth'
        });
    });
});

