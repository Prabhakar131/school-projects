


// Menu icon and navbar toggle
let menuIcon = document.querySelector("#menu-icon");
let navbar = document.querySelector(".navbar");

menuIcon.addEventListener('click', () => {
    menuIcon.classList.toggle('bx-x'); // Toggles the menu icon to an 'x' when clicked
    navbar.classList.toggle('active'); // Toggles the navbar visibility
});

// Sticky navbar
window.onscroll = () => {
    let header = document.querySelector('.header');
    header.classList.toggle('sticky', window.scrollY > 100);

    // Remove menu icon and hide navbar when scrolling
    if (navbar.classList.contains('active')) {
        menuIcon.classList.remove('bx-x');
        navbar.classList.remove('active');
    }
    
};

// Initialize swiper
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 50,
    loop: true,
    grabCursor: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});

// Dark mode and light mode
let darkModeIcon = document.querySelector('#darkMode-icon');

darkModeIcon.onclick = () => {
    darkModeIcon.classList.toggle('bx-sun');
    document.body.classList.toggle('dark-mode');
}

// Scroll reveal
ScrollReveal({
    reset: true,
    distance: '80px',
    duration: 2000,
    delay: 200,
});


ScrollReveal().reveal(' about-img img', { origin: 'left' });
ScrollReveal().reveal('..about-content ', { origin: 'right' });
// ScrollReveal for the timeline section
ScrollReveal().reveal('.timeline-item.left-timeline-item', { origin: 'left', distance: '50px', duration: 1000, delay: 300 });
ScrollReveal().reveal('.timeline-item.right-timeline-item', { origin: 'right', distance: '50px', duration: 1000, delay: 300 });


