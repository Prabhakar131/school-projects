
// Menu icon and navbar toggle
let menuIcon = document.querySelector("#menu-icon");
let navbar = document.querySelector(".navbar");

menuIcon.addEventListener('click', () => {
    menuIcon.classList.toggle('bx-x'); // Toggles the menu icon to an 'x' when clicked
    navbar.classList.toggle('active'); // Toggles the navbar visibility
});

// Sticky navbar
window.onscroll = () => {
    let header = document.querySelector('.header');
    header.classList.toggle('sticky', window.scrollY > 100);

    // Remove menu icon and hide navbar when scrolling
    if (navbar.classList.contains('active')) {
        menuIcon.classList.remove('bx-x');
        navbar.classList.remove('active');
    }
};

// Initialize swiper
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 50,
    loop: true,
    grabCursor: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    }
});

// Dark mode and light mode
let darkModeIcon = document.querySelector('#darkMode-icon');

darkModeIcon.onclick = () => {
    darkModeIcon.classList.toggle('bx-sun');
    document.body.classList.toggle('dark-mode');
};


// Reveal elements with ScrollReveal
ScrollReveal().reveal(' .testimonial-wrapper', { origin: 'bottom' });


document.addEventListener('DOMContentLoaded', function() {
    const leftBtn = document.querySelector('.leftbtn');
    const rightBtn = document.querySelector('.rightbtn');
    const hotcards = document.querySelector('.hotcards');

    leftBtn.addEventListener('click', () => {
        hotcards.scrollBy({
            top: 0,
            left: -200,
            behavior: 'smooth'
        });
    });

    rightBtn.addEventListener('click', () => {
        hotcards.scrollBy({
            top: 0,
            left: 200,
            behavior: 'smooth'
        });
    });
});

var options = {
    typeSpeed: 120,
    backSpeed: 70,
    loop: true,
    smartBackspace: true,
    backDelay: 1000,
};

var typed1 = new Typed(".auto-type-1", {
    ...options,
    strings: ["Graphic Designer", "Creative Visionary", "Branding Expert",],
});

var typed2 = new Typed(".auto-type-2", {
    ...options,
    strings: ["Web Developer", "Creative Coder", "Frontend Specialist"],
});

var typed3 = new Typed(".auto-type-3", {
    ...options,
    strings: ["Digital Marketer", "SEO Specialist", "Content Strategist"],
});



// Circle Slider 
let items = document.querySelectorAll('.circle-slider .list .item');
let prevBtn = document.getElementById('prev');
let nextBtn = document.getElementById('next');
let lastPosition = items.length - 1;
let firstPosition = 0;
let active = 0;

nextBtn.onclick = () => {
    active = active + 1;
    setSlider();
}
prevBtn.onclick = () => {
    active = active - 1;
    setSlider();
}
const setSlider = () => {
    let oldActive = document.querySelector('.circle-slider .list .item.active');
    if(oldActive) oldActive.classList.remove('active');
    items[active].classList.add('active');
    // 
    nextBtn.classList.remove('d-none');
    prevBtn.classList.remove('d-none');
    if(active == lastPosition) nextBtn.classList.add('d-none');
    if(active == firstPosition) prevBtn.classList.add('d-none');
}
setSlider();

// set diameter
const setDiameter = () => {
    let slider = document.querySelector('.circle-slider');
    let widthSlider = slider.offsetWidth;
    let heightSlider = slider.offsetHeight;
    let diameter = Math.sqrt(Math.pow(widthSlider, 2) + Math.pow(heightSlider, 2));
    document.documentElement.style.setProperty('--diameter', diameter+'px');
}
setDiameter();
window.addEventListener('resize', () => {
    setDiameter();
})