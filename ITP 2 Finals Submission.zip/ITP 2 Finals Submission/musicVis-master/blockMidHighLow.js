
// Threshold for rotating stars based on energy levels
var rotateThresh;
// Threshold for progressing noise lines based on energy levels 
var progThresh;
// Threshold for resetting noise seed based on energy levels 
var seedThresh; 
// Variable to control default colour for noise lines
var lineColour = "#00FF00"; 
 // Variable to control the number of noise lines to draw
var numNoiseLines;
// Variable to control the size of stars in the visualizer
var starSize; 

function BlockMidHighLow() { 
    this.name = "Block Mid High Low"; 
    // Variable to control the step size for noise generation
    var noiseStep = 0.01; 
    // Variable to control the progress of the noise lines animation
    var prog = 0;
    // GUI object for user interface controls 
    var gui; 
    // Array to store configurations of star rings
    var starRings = []; 
    // Array to store the shooting stars
    var shootingStars = []; 
    // Method to check if mouse is inside GUI
    this.inMouseInGUI = function() { 
        // Check if the mouse pointer is within the boundaries of the GUI
        var inGUI = false;
        var gui_x = gui.prototype._panel.style.left;
        var gui_y = gui.prototype._panel.style.top;
        var gui_height = gui.prototype._panel.clientHeight;
        var gui_width = gui.prototype._panel.clientWidth;
        gui_x = parseInt(gui_x, 10);
        gui_y = parseInt(gui_y, 10);
        gui_height = parseInt(gui_height, 10);
        gui_width = parseInt(gui_width, 10);
        if (mouseX > gui_x && mouseX < gui_x + gui_width) {
            if (mouseY > gui_y && mouseY < gui_y + gui_height) {
                inGUI = true;
            }
        }
        return inGUI;
    };
    
    this.setup = function() {
        // Initialize parameters and GUI controls in setup function 
        // Initial threshold for star rotation
        rotateThresh = 207; 
        // Initial threshold for noise line progression
        progThresh = 30; 
        // Initial threshold for noise seed reset
        seedThresh = 100; 
        // Initial number of noise lines
        numNoiseLines = 5; 
        // Initial size of stars
        starSize = 25; 
        // Create GUI with controls for the audio visualizer
        gui = createGui("Audio Visualizer");
        gui.setPosition(width - 200, 0); 
        // Define sliders and their ranges for GUI controls
        sliderRange(0.001, 1, 0.001);
        gui.addGlobals("noiseStep");
        sliderRange(0, 255, 1);
        gui.addGlobals("rotateThresh");
        gui.addGlobals("progThresh");
        gui.addGlobals("seedThresh");
        gui.addGlobals("lineColour");
        sliderRange(1, 20, 1);
        gui.addGlobals("numNoiseLines");
        sliderRange(5, 50, 1);
        gui.addGlobals("starSize");
        // Create rings of stars with varying parameters
        // Variable to control the number of star rings
        var numRings = 4; 
        // Variable to control the number of stars per ring
        var numStars = 10; 
        // Variable to control maximum radius for star rings
        var maxRadius = min(width, height) / 2; 
        for (var i = 1; i <= numRings; i++) {
            // Variable to control the radius of current star ring
            var ringRadius = (maxRadius / numRings) * i + 50; 
            var stars = [];
            for (var j = 0; j < numStars; j++) {
                // Variable to control the angle of each star
                var angle = TWO_PI / numStars * j; 
                // Store star angle in array
                stars.push({ angle: angle }); 
            }
            starRings.push({
                radius: ringRadius,
                stars: stars,
                clockwise: (i % 2 === 0), // Direction of rotation
                rotation: 0 // Initial rotation angle
            });
        }
    };
    // Call setup function to initialize visualizer
    this.setup(); 
    // Method to handle GUI position on window resize
    this.onResize = function() { 
        gui.setPosition(width - 200, 0); 
    };
    // Call onResize method to set initial GUI position
    this.onResize(); 
    // Methods to hide and unhide GUI
    this.unSelectVisual = function() { 
        console.log("de select"); 
        gui.hide(); 
    };
    this.selectVisual = function() { 
        console.log("select"); 
        gui.show(); 
    };

    this.draw = function() { 
        background(0, 0, 0, 25); 
        // Analyze audio frequencies of song 
        fourier.analyze();
        // Get energy level of bass frequencies
        var bass = fourier.getEnergy("bass"); 
        // Get energy level of treble frequencies
        var treble = fourier.getEnergy("treble");
        // Get energy level of low mid-range frequencies 
        var lowMid = fourier.getEnergy("lowMid"); 
        // Get energy level of high mid-range frequencies
        var highMid = fourier.getEnergy("highMid"); 
        // Draw rotating stars based on audio energy levels
        rotatingStars(bass, treble, lowMid, highMid);
        // Draw noise lines influenced by audio energy levels
        noiseLine(bass, treble);
        // Create shooting stars based on audio energy levels
        createShootingStars(bass, treble, lowMid, highMid);
        // Update and remove the position and trail of shooting stars
        removeShootingStars();
    };
    function rotatingStars(bass, treble, lowMid, highMid) { 
        // Array to store the  energy levels
        var energies = [bass, treble, lowMid, highMid]; 
        // Array to store the star colors
        var colors = ["#0000FF", "#FF0000", "#FFFF00", "#FFFFFF"];      
        // Iterate through each star ring
        for (var i = 0; i < starRings.length; i++) {
            // Current star ring
            var ring = starRings[i];
            // Current energy level 
            var energy = energies[i % energies.length]; 
            // Current star color
            var color = colors[i % colors.length]; 
            // Control rotation direction and speed based on energy threshold
            if (energy < rotateThresh) {
                // Increase rotation angle clockwise
                if (ring.clockwise) {
                    ring.rotation += 0.01; 
                } 
                // Decrease rotation angle counter-clockwise
                else {
                    ring.rotation -= 0.01; 
                }
            }
            // Map energy level to star size
            var r = map(energy, 0, 255, starSize / 2, starSize); 
            // Number of points for each star
            var starPoints = 5; 
            // Outer radius of star
            var outerRadius = r; 
            // Inner radius of star
            var innerRadius = r / 2; 
            // Iterate through each star in the ring
            for (var j = 0; j < ring.stars.length; j++) {
                 // Current star
                var star = ring.stars[j];
                 // Calculate x position
                var x = width / 2 + cos(star.angle + ring.rotation) * ring.radius;
                // Calculate y position
                var y = height / 2 + sin(star.angle + ring.rotation) * ring.radius; 
                push(); 
                // Translate to star position
                translate(x, y); 
                // Rotate based on ring rotation
                rotate(ring.rotation); 
                 // Set star color
                fill(color);
                beginShape(); 
                for (var k = 0; k < 2 * starPoints; k++) {
                    // Store star angle in array
                    var angle = k * PI / starPoints;
                    // Alternate between outer and inner radius
                    var radius = (k % 2 === 0) ? outerRadius : innerRadius; 
                    // Calculate x position of star point
                    var starX = cos(angle) * radius; 
                     // Calculate y position of star point
                    var starY = sin(angle) * radius;
                    // Add vertex for star point
                    vertex(starX, starY); 
                }
                endShape(CLOSE); 
                pop(); 
            }
        }
    }
    function noiseLine(energy1, energy2) {
        push(); 
        // Translate to center of canvas
        translate(width / 2, height / 2); 
        // Iterate through each noise line
        for (var n = 0; n < numNoiseLines; n++) {
            beginShape();
            noFill(); 
            // Set stroke colour and weight for each noise line
            stroke(lineColour); 
            strokeWeight(3); 
            // Iterate through points in noise line
            for (var i = 0; i < 100; i++) {
                // Generate x and y positions based on noise and progression
                var x = map(noise(i * noiseStep + prog + n * 1000), 0, 1, -100, 100);
                var y = map(noise(i * noiseStep + prog + n * 1000 + 1000), 0, 1, -100, 100);
                // Add vertex to noise line shape
                vertex(x, y); 
            }
            endShape(); 
        }
        // Increment progress of  noise animation based on energy thresholds
        if (energy1 > progThresh) {
            prog += 0.05;
        }
        // Reset noise seed based on energy threshold
        if (energy2 > seedThresh) {
            noiseSeed();
        }
        pop(); 
    }
    function createShootingStars(bass, treble, lowMid, highMid) { 
        // Array to store the energy levels
        var energyLevels = [bass, treble, lowMid, highMid]; 
        // Array to store the  star colors
        var colors = ["#0000FF", "#FF0000", "#FFFF00", "#FFFFFF"]; 
        // Iterate through energy levels array to create shooting stars
        for (var i = 0; i < energyLevels.length; i++) {
            // Create randoom shooting star if the energy level is high enough 
            if (energyLevels[i] > 20 && random() < 0.05) {
                shootingStars.push({
                    x: random(width), 
                    y: random(height), 
                    speed: random(5, 15),
                    direction: random(TWO_PI), 
                    color: colors[i],
                    trail: [] 
                });
            }
        }
    }
    function removeShootingStars() { 
        // Iterate through shooting stars array in reverse order for removal
        for (var i = shootingStars.length - 1; i >= 0; i--) {
            var star = shootingStars[i]; 
            // Add current position to trail with full opacity
            star.trail.push({ x: star.x, y: star.y, alpha: 255 });
            // Remove oldest trail point if trail length exceeds limit
            if (star.trail.length > 10) {
                star.trail.shift(); 
            }
            // Update position based on speed and direction
            // Update x position
            star.x += cos(star.direction) * star.speed; 
            // Update y position
            star.y += sin(star.direction) * star.speed; 
            push(); 
            // Set stroke weight for drawing trail
            strokeWeight(5); 
            // Iterate through trail points of shooting star
            for (var j = 0; j < star.trail.length; j++) {
                // Current trail point
                var t = star.trail[j]; 
                // Set stroke color with alpha
                stroke(red(star.color), green(star.color), blue(star.color), t.alpha); 
                // Draw point at trail position
                point(t.x, t.y); 
                // Decrease alpha for fading effect
                t.alpha -= 25; 
            }
            // Set stroke weight for current shooting star
            strokeWeight(6); 
            // Draw current shooting star
            point(star.x, star.y); 
            pop(); 
            // Remove shooting star if it goes out of bounds
            if (star.x < 0 || star.x > width || star.y < 0 || star.y > height) {
                shootingStars.splice(i, 1); // Remove shooting star from array
            }
        }
    }
}

