function ControlsAndInput() {
    this.menuDisplayed = false;
    this.selectedVisualization = -1; // Initialize with no selection

    // Playback button displayed in the top left of the screen
    this.playbackButton = new PlaybackButton();

    // Make the window fullscreen or revert to windowed with 'F' key
    this.mousePressed = function() {
        var isPlaybackButtonClicked = this.playbackButton.hitCheck();

        if (this.menuDisplayed) {
            this.handleMenuClick(mouseX, mouseY);
        }
    };

    // Responds to keyboard presses
    this.keyPressed = function(keycode) {
        if (keycode == 32) { // Space bar
            this.menuDisplayed = !this.menuDisplayed;
        }

        if (keycode == 70) { // 'F' key for fullscreen
            var fs = fullscreen();
            fullscreen(!fs);
        }

        if (keycode > 48 && keycode < 58) { // Numbers 1-9
            var visNumber = keycode - 49;
            this.selectedVisualization = visNumber;
            vis.selectVisual(vis.visuals[visNumber].name);
        }
    };

    // Draws the playback button and potentially the menu
    this.draw = function() {
        push();
        fill("white");
        stroke("black");
        strokeWeight(2);
        textSize(34);

        this.playbackButton.draw();

        if (this.menuDisplayed) {
            this.menu();
        }
        pop();
    };

    // Draws the menu
    this.menu = function() {
        push();

        fill(0, 0, 200);
        noStroke();
        rect(10, 70, 300, vis.visuals.length * 40 + 60, 10); // Shifted right by 10 pixels

        fill(255);
        stroke("black");
        strokeWeight(1);
        textSize(22);
        textStyle(BOLD);
        text("VISUALISATIONS:", 30, 100); // Adjusted position

        textSize(18);
        textStyle(NORMAL);
        for (var i = 0; i < vis.visuals.length; i++) {
            var yLoc = 140 + i * 40; // Adjusted position
            if (i === this.selectedVisualization) {
                stroke(0, 255, 0);
                strokeWeight(3);
                noFill();
                rect(20, yLoc - 20, 280, 30); // Adjusted position
                fill(255);
                stroke("black");
                strokeWeight(1);
            }
            text((i + 1) + ": " + vis.visuals[i].name, 30, yLoc); // Adjusted position
        }

        pop();
    };

    // Handles clicks on the menu items
    this.handleMenuClick = function(mouseX, mouseY) {
        for (var i = 0; i < vis.visuals.length; i++) {
            var yLoc = 140 + i * 40; // Adjusted position
            if (mouseX > 20 && mouseX < 300 && mouseY > yLoc - 20 && mouseY < yLoc + 10) {
                this.selectedVisualization = i;
                vis.selectVisual(vis.visuals[i].name);
                break;
            }
        }
    };
}
