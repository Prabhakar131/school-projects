// playbackButton.js
function PlaybackButton() {
    this.x = 20;
    this.y = 20;
    this.width = 20;
    this.height = 20;

    // Progress bar properties
    this.progressBarX = this.x + 40;
    this.progressBarY = this.y + 5;
    this.progressBarWidth = 200;
    this.progressBarHeight = 10;

    // Arrow properties
    this.arrowWidth = 10;
    this.arrowHeight = 20;

    // Flag to determine whether to play or pause after button click and
    // to determine which icon to draw
    this.playing = false;

    this.draw = function() {
        // Draw playback button
        if (this.playing) {
            rect(this.x, this.y, this.width / 2 - 2, this.height);
            rect(this.x + (this.width / 2 + 2), this.y, this.width / 2 - 2, this.height);
        } else {
            triangle(this.x, this.y, this.x + this.width, this.y + this.height / 2, this.x, this.y + this.height);
        }

        // Draw progress bar
        this.drawProgressBar();

        // Draw arrow on progress bar
        this.drawArrow();
    };

    this.drawProgressBar = function() {
        // Draw the background of the progress bar
        fill(100);
        rect(this.progressBarX, this.progressBarY, this.progressBarWidth, this.progressBarHeight);

        // Draw the current progress
        let progress = map(sound.currentTime(), 0, sound.duration(), 0, this.progressBarWidth);
        fill(255);
        rect(this.progressBarX, this.progressBarY, progress, this.progressBarHeight);
    };

    this.drawArrow = function() {
        // Calculate the arrow position based on progress
        let progress = map(sound.currentTime(), 0, sound.duration(), 0, this.progressBarWidth);
        let arrowX = this.progressBarX + progress - this.arrowWidth / 2;
        let arrowY = this.progressBarY + this.progressBarHeight / 2;

        // Draw the arrow
        fill(255, 0, 0);
        triangle(arrowX, arrowY, arrowX + this.arrowWidth, arrowY - this.arrowHeight / 2, arrowX + this.arrowWidth, arrowY + this.arrowHeight / 2);
    };

    // Checks for clicks on the button, starts or pauses playback.
    // @returns true if clicked false otherwise.
    this.hitCheck = function() {
        // Check if playback button is clicked
        if (mouseX > this.x && mouseX < this.x + this.width && mouseY > this.y && mouseY < this.y + this.height) {
            if (sound.isPlaying()) {
                sound.pause();
                isGameActive = false; // Set the game state to inactive
            } else {
                sound.loop();
                isGameActive = true; // Set the game state to active
            }
            this.playing = !this.playing;
            return true;
        }

        // Check if progress bar is clicked
        if (mouseX > this.progressBarX && mouseX < this.progressBarX + this.progressBarWidth && mouseY > this.progressBarY && mouseY < this.progressBarY + this.progressBarHeight) {
            let newTime = map(mouseX, this.progressBarX, this.progressBarX + this.progressBarWidth, 0, sound.duration());
            sound.jump(newTime);
            return true;
        }

        return false;
    };

    // Update the arrow position based on mouse drag
    this.updateArrowPosition = function() {
        if (mouseIsPressed && mouseX > this.progressBarX && mouseX < this.progressBarX + this.progressBarWidth && mouseY > this.progressBarY && mouseY < this.progressBarY + this.progressBarHeight) {
            let newTime = map(mouseX, this.progressBarX, this.progressBarX + this.progressBarWidth, 0, sound.duration());
            sound.jump(newTime);
        }
    };
}
