function PianoTiles() {
    this.name = "Piano Tiles";

    // Game states
    this.startScreen = true; // Flag to indicate if the start screen is active
    this.levelCompleted = false;
    this.timeUp = false;
    this.gameComplete = false; // Flag to indicate game completion
    this.message = '';
    this.messageDuration = 120;
    this.slowDownActive = false;
    this.slowDownFrames = 0;
    this.slowDownDuration = 240;

     // FireworkEffect initialization
     this.fireworkEffect = new FireworkEffect();


    // Tile properties
    this.tileWidth = 80;
    this.tileHeight = 100;
    this.tiles = [];
    this.tileSpeed = 3; // Set a fixed speed for all tiles
    this.score = 0;

    // Time-related variables
    this.levelDuration = 30 * 60;
    this.frameCount = 0;
    this.timeLeft = this.levelDuration;

    // Score target
    this.targetScore = 10;
    this.currentLevel = 1;
    this.finalLevel = 3; // The final level of the game

    // Colors for different energy levels
    this.tileColors = {
        lowMid: color(255, 255, 0), // Yellow
        highMid: color(255, 0, 0), // Red
        treble: color(0, 0, 255), // Blue
        bass: color(0, 255, 0), // Green
        special: color(255, 140, 0) // Orange for special tiles
    };
    
    // p5.FFT object to analyze the audio spectrum
    this.fft = new p5.FFT();

    // Lane properties
    this.numLanes = 5;
    this.laneWidth = this.tileWidth + 20; // Width of each lane with some padding
    this.middleWidth = width / 2;
    this.laneXPositions = []; // Array to store the x-coordinates of lanes

    // Calculate lane positions
    this.calculateLanes = function() {
        let totalLanesWidth = this.numLanes * this.laneWidth;
        let startX = this.middleWidth - totalLanesWidth / 2;

        for (let i = 0; i < this.numLanes; i++) {
            this.laneXPositions.push(startX + i * this.laneWidth);
        }
    };

    // Call the lane calculation function
    this.calculateLanes();

    // p5.FFT object to analyze the audio spectrum
    this.fft = new p5.FFT();


  // 3D Landscape parameters
this.numBoxes = 20; // Number of boxes in the terrain grid
this.sideLength = 60; // Size of each box
this.minHeight = 1; // Minimum height of the terrain boxes
this.maxHeight = 300; // Maximum height of the terrain boxes
this.noiseOffset = 100; // Offset for noise function (used in terrain generation)
this.noiseScale = 0.005; // Scale for the noise function
this.timeScale = 0.0002; // Time scaling for terrain changes
this.rotateScale = 0.0001; // Rotation scaling for the landscape

// Height scaling for terrain animation
this.heightScale = 1; // Scale factor for terrain height
this.heightDir = 0.05; // Direction in which the heightScale changes (used for animation)

// Create the graphics buffer for the 3D landscape
this.landscapeBuffer = createGraphics(windowWidth, windowHeight, WEBGL); // Create an off-screen buffer for 3D rendering

// GUI for the 3D landscape
this.landscapeGui = createGui('3D Landscape Controls');
this.landscapeGui.addGlobals('numBoxes', 'sideLength', 'minHeight', 'maxHeight', 'noiseScale', 'timeScale', 'rotateScale', 'heightScale');
this.landscapeGui.setPosition(20, 20); // Position the GUI on the screen
this.landscapeGui.hide(); // Initially hide the GUI

// Function to draw the 3D landscape
this.draw3DLandscape = function() {
    this.landscapeBuffer.background(20); // Set background color of the landscape buffer
    this.landscapeBuffer.push(); // Save the current transformation state

    // Center the landscape on the screen, move it down, and tilt it towards the user
    this.landscapeBuffer.translate(0, 50, -this.numBoxes * this.sideLength / 2); // Translate the landscape
    this.landscapeBuffer.rotateX(-PI / 6); // Rotate the landscape towards the user

    const t = millis(); // Get the current time in milliseconds
    this.heightScale = constrain(this.heightScale + this.heightDir, 0, 1); // Adjust heightScale and constrain its value
    this.landscapeBuffer.rotateY(-t * this.rotateScale); // Rotate the landscape over time

    // Add basic ambient light
    this.landscapeBuffer.ambientLight(150);

    // Static directional light for overall illumination
    this.landscapeBuffer.directionalLight(150, 150, 150, -0.5, -1, -0.5);

    // Draw the terrain with height-based animations
    this.drawTerrain(t);
    this.landscapeBuffer.pop(); // Restore the previous transformation state

    // Draw the buffer to the main canvas
    image(this.landscapeBuffer, 0, 0, width, height);
};

// Function to draw the terrain with height-based animations and dynamic deformation
this.drawTerrain = function (t) {
    let spectrum = this.fft.analyze(); // Analyze the audio spectrum

    for (let i = 0; i < this.numBoxes; i++) {
        for (let j = 0; j < this.numBoxes; j++) {
            let x = (i * this.sideLength) - (this.numBoxes * this.sideLength) / 2; // Calculate x position
            let z = (j * this.sideLength) - (this.numBoxes * this.sideLength) / 2; // Calculate z position
            let noiseValue = this.getNoiseValue(x, z, t); // Get noise value for terrain height
            let energyFactor = this.getEnergyFactor(spectrum, noiseValue); // Get energy factor based on the spectrum

            this.drawBox(x, z, noiseValue, energyFactor, t); // Draw the box for the current grid position with animation
        }
    }
};

// Function to draw a box in the terrain with height-based animations
this.drawBox = function (x, z, noiseValue, energyFactor, t) {
    let h = this.getBoxHeight(noiseValue) * energyFactor; // Calculate the height of the box based on noise and energy
    h = max(h, 0.01); // Ensure the height is not too small

    // Apply height-based pulsating animation
    let heightVariation = map(sin(t * 0.003 + (x + z) * 0.1), -1, 1, 0.8, 1.2);
    h *= heightVariation; // Modulate the height dynamically

    this.landscapeBuffer.push(); // Save the current transformation state
    this.landscapeBuffer.noStroke(); // Disable stroke for the box
    this.landscapeBuffer.translate(x, -h / 2, z); // Position the box

    // Set the fill color based on noise value using existing colors for treble, lowMid, highMid, and bass
    this.landscapeBuffer.fill(this.getDynamicColour(noiseValue)); 

    this.landscapeBuffer.box(this.sideLength, h, this.sideLength); // Draw the box
    this.landscapeBuffer.pop(); // Restore the previous transformation state
};

// Function to get the noise value for terrain generation
this.getNoiseValue = function (x, z, time) {
    x = x * this.noiseScale + this.noiseOffset; // Scale and offset the x coordinate
    z = z * this.noiseScale + this.noiseOffset; // Scale and offset the z coordinate
    time = time * this.timeScale + this.noiseOffset; // Scale and offset the time
    return noise(x, z, time); // Return the noise value for the given coordinates and time
};

// Function to calculate the height of a box based on noise value
this.getBoxHeight = function (noiseValue) {
    return map(noiseValue, 0, 1, this.minHeight, this.maxHeight) * this.heightScale; // Map the noise value to a height range
};

// Function to determine the color of a box based on noise value using music energy colors
this.getDynamicColour = function (noiseValue) {
    // Map noise values to use the colors for bass, lowMid, highMid, and treble
    if (noiseValue < 0.25) {
        return this.tileColors.bass; // Green
    } else if (noiseValue < 0.5) {
        return this.tileColors.lowMid; // Yellow
    } else if (noiseValue < 0.75) {
        return this.tileColors.highMid; // Red
    } else {
        return this.tileColors.treble; // Blue
    }
};

// Function to get the energy factor based on the spectrum and noise value
this.getEnergyFactor = function(spectrum, noiseValue) {
    let bassEnergy = this.getEnergy(spectrum, "bass");
    let lowMidEnergy = this.getEnergy(spectrum, "lowMid");
    return map(bassEnergy + lowMidEnergy, 0, 510, 0.5, 1.5); // Combine energies to get a factor
};
    // Function to display the start screen with rules and regulations
    this.displayStartScreen = function() {
        // Animate a gradient background
        let gradientShift = frameCount * 0.02; // Adjust speed
        for (let i = 0; i < height; i++) {
            let inter = map(i, 0, height, 0, 1);
            let c1 = color(0, 0, 50 + 50 * sin(gradientShift)); // Oscillating blue
            let c2 = color(0, 0, 150 + 50 * sin(gradientShift + PI / 2)); // Oscillating dark blue
            let c = lerpColor(c1, c2, inter);
            stroke(c);
            line(0, i, width, i);
        }
        push()
        textAlign(CENTER);
    
        // Main header text without pulsing effect
        textSize(70);
        textStyle(BOLD);
        fill(255);
        text("Piano Tiles Game", width / 2 - 30, height / 4 - 80);
    
        // Shift the rest of the elements up by another 10 pixels
        textSize(32);
        fill(255);
        text("Rules and Regulations:", width / 2 - 140, height / 2 - 160);
    
        textSize(24);
        textAlign(LEFT);
        let spacing = 50; // Adjust the spacing between lines
        text("1. Tiles fall from the top, click them to score points.", width / 4, height / 2 - spacing - 50);
        text("2. The game ends when the time runs out or the target score is reached.", width / 4, height / 2 - 50);
        text("3. Special tiles have different effects:", width / 4, height / 2 + spacing - 50);
    
        // Adding some color variation for special tiles for emphasis
        fill(255, 200, 0);
        text("   - Star tile: Decreases the target score.", width / 4 + 20, height / 2 + spacing * 2 - 50);
    
        // Rotating Star tile icon
        push();
        translate(width / 4 + 20 - 10, height / 2 + spacing * 2 - 60);
        rotate(frameCount * 0.05); // Rotate the star
        fill(255, 200, 0);
        rotatingStarIcon(0, 0, 10, 20, 5);
        pop();
    
        fill(0, 200, 255);
        text("   - Hexagon tile: Slows down the tile speed.", width / 4 + 20, height / 2 + spacing * 3 - 50);
    
        // Rotating Hexagon tile icon
        push();
        translate(width / 4 + 20 - 10, height / 2 + spacing * 3 - 60);
        rotate(frameCount * 0.05); // Rotate the hexagon
        fill(0, 200, 255);
        rotatingHexagonIcon(0, 0, 20);
        pop();
    
        fill(255); // Reset color
        text("4. Press 'N' to start the next level.", width / 4, height / 2 + spacing * 4 - 50);
        text("5. Press 'R' to restart the game when time is up.", width / 4, height / 2 + spacing * 5 - 50);
    
        // Apply pulsing effect to "Press 'S' to Start"
        let pulse = 1 + 0.1 * sin(frameCount * 0.1); // Pulsing effect for the start button
        textAlign(CENTER);
        textSize(32 * pulse);
        fill(255);
        text("Press 'S' to Start", width / 2, height / 2 + spacing * 6 - 40);
        pop()
    };
    
    // Function to draw a star
    function rotatingStarIcon(x, y, radius1, radius2, npoints) {
        let angle = TWO_PI / npoints;
        let halfAngle = angle / 2.0;
        beginShape();
        for (let a = 0; a < TWO_PI; a += angle) {
            let sx = x + cos(a) * radius2;
            let sy = y + sin(a) * radius2;
            vertex(sx, sy);
            sx = x + cos(a + halfAngle) * radius1;
            sy = y + sin(a + halfAngle) * radius1;
            vertex(sx, sy);
        }
        endShape(CLOSE);
    }
    
    // Function to draw a hexagon
    function rotatingHexagonIcon(x, y, radius) {
        beginShape();
        for (let i = 0; i < 6; i++) {
            vertex(x + radius * cos(TWO_PI / 6 * i), y + radius * sin(TWO_PI / 6 * i));
        }
        endShape(CLOSE);
    }

    this.showTile = function(tile) {
        fill(tile.color);
        noStroke();
    
        if (tile.shape === "rectangle") {
            rect(tile.x, tile.y, tile.w, tile.h);
        } else if (tile.shape === "star") {
            // Center the star in the lane by adjusting the drawing coordinates
            this.drawStarSpecialTile(tile.x + this.laneWidth / 2, tile.y + tile.h / 2, tile.w / 4, tile.w / 2, 5);
        } else if (tile.shape === "hexagon") {
            // Center the hexagon in the lane by adjusting the drawing coordinates
            this.drawHexagonSpecialTile(tile.x + this.laneWidth / 2, tile.y + tile.h / 2, tile.w / 2);
        }
    };
    

    // Function to draw a star shape
    this.drawStarSpecialTile = function(x, y, radius1, radius2, npoints) {
        let angle = TWO_PI / npoints;
        let halfAngle = angle / 2.0;
        beginShape();
        for (let a = 0; a < TWO_PI; a += angle) {
            let sx = x + cos(a) * radius2;
            let sy = y + sin(a) * radius2;
            vertex(sx, sy);
            sx = x + cos(a + halfAngle) * radius1;
            sy = y + sin(a + halfAngle) * radius1;
            vertex(sx, sy);
        }
        endShape(CLOSE);
    };

    // Function to draw a hexagon shape
    this.drawHexagonSpecialTile = function(x, y, radius) {
        beginShape();
        for (let a = 0; a < TWO_PI; a += TWO_PI / 6) {
            let sx = x + cos(a) * radius;
            let sy = y + sin(a) * radius;
            vertex(sx, sy);
        }
        endShape(CLOSE);
    };

    // Function to move a tile down the screen
    this.moveTile = function(tile) {
        if (this.slowDownActive && this.slowDownFrames > 0) {
            tile.y += this.tileSpeed * 0.2;
            this.slowDownFrames--;
        } else {
            tile.y += this.tileSpeed;
        }

        if (this.slowDownFrames <= 0) {
            this.slowDownActive = false;
        }
    };

    // Function to draw the lanes
    this.drawLanes = function() {
        stroke(200); // Set a light gray color for the lanes
        strokeWeight(2); // Set the thickness of the lane lines
        for (let i = 0; i < this.numLanes; i++) {
            let xPos = this.laneXPositions[i];
            line(xPos + this.laneWidth / 2, 0, xPos + this.laneWidth / 2, height);
        }
    };
    this.draw = function() {
        push()
        if (this.startScreen) {
            this.displayStartScreen();
        } else if (!this.levelCompleted && !this.timeUp && !this.gameComplete) {
            if (isGameActive) {

                this.draw3DLandscape();
                // Game is active
                this.drawLanes();
    
                for (let i = this.tiles.length - 1; i >= 0; i--) {
                    this.moveTile(this.tiles[i]);
                    this.showTile(this.tiles[i]);
    
                    if (this.tiles[i].y > height) {
                        this.tiles.splice(i, 1);
                    }
                }
    
                this.updateTimer();
    
                if (this.timeLeft > 0 && this.score < this.targetScore) {
                    if (frameCount % 30 === 0) {
                        this.addTile();
                    }
                }
    
                this.drawDisplayContainer(this.timeLeft); // Only this function handles the message display
    
              
            } else {
                push()
                // Game is paused
                noStroke();
                fill(255, 0, 0); // Red color for the pause message
                textSize(50); // Large font size
                textAlign(CENTER, CENTER); // Center the text horizontally and vertically
                text("Game Paused", width / 2, height / 2 - 20); // Display pause message
                textSize(48)
                text("Press Play Button to Resume", width / 2, height / 2 + 50); // Instruction to resume
                pop()           
            }

        } else if (this.gameComplete) {
            this.fireworkEffect.draw(); 
            this.showGameCompleteScreen();
        } else if (this.levelCompleted) {
            this.showNextLevelOption();
        } else if (this.timeUp) {
            this.showTimeUpScreen();
        }
        pop()
    };
    

    // Function to display a message
    this.displayMessage = function(msg) {
        fill(255);
        textSize(32);
        text(msg, width / 2 - textWidth(msg) / 2, height / 2 + 100);
    };

    // Function to draw the display container with score, time, and level information
this.drawDisplayContainer = function(timeLeft) {
    let containerX = width - 355;
    let containerY = 15;
    let containerWidth = 320;
    let containerHeight = 180;
    
    fill(0);
    stroke(255);
    rect(containerX, containerY, containerWidth, containerHeight, 10);


    if (this.showSpecialMessage && frameCount - this.lastMessageFrame < this.messageDuration) {
        // Display the special message and hide other attributes
        push()
        fill(255);
        textFont("monospace");
        textSize(43)
        text(this.message, containerX + 30, containerY + 90);
        pop()
    } else {
        push()
        fill(255);
        textFont("monospace");
        textSize(32);
        // Revert to showing the original attributes once the message duration is over
        this.showSpecialMessage = false; // Reset the flag
        let secondsLeft = timeLeft / 60;
        text('Score: ' + this.score,  containerX + 20, containerY + 35);
        text('Time Left: ' + secondsLeft.toFixed(1),  containerX + 20, containerY + 75);
        text('Level: ' + this.currentLevel,  containerX + 20, containerY + 115);
        let pointsNeeded = max(0, this.targetScore - this.score);
        text("Points Needed: " + pointsNeeded,  containerX + 20, containerY + 155);
        pop()
    }
};
     
    // Function to show next level option
    this.showNextLevelOption = function() {
        push()
        noStroke()
        textFont("monospace")
        fill(25,200,100);
        textSize(55);
        textAlign(CENTER, CENTER);
        text('Level Completed!', width/2 , height / 2 - 70);
        textSize(52);
        text('Press N to start the next level', width/2 , height / 2 );
        pop()
    };

    // Function to show "Time is Up" screen with restart option
    this.showTimeUpScreen = function() {
        push()
        noStroke()
        textFont("monospace")
        fill(255, 0, 0);
        textSize(65);
        textAlign(CENTER, CENTER);
        text('Time is Up!', width/2 , height / 2 - 80);
        textSize(62);
        text('Press R to restart the game', width/2 , height / 2);
        pop()
    };

    // Function to show the "Game Complete" screen after the final level
    this.showGameCompleteScreen = function() {
        push()
        noStroke()
        fill(0, 255, 0);
        textSize(48);
        textFont("monospace")
        textAlign(CENTER, CENTER);
        text('Congratulations!', width/2 , height / 2 - 50);
        textSize(46);
        text('You have completed the game!', width/2 , height / 2 + 20);
        textSize(44);
        text('Press R to restart the game', width/2 , height / 2 + 80);
        pop()
    };

    // Function to update the timer
    this.updateTimer = function() {
        if (this.score >= this.targetScore) {
            this.levelCompleted = true;
            if (this.currentLevel >= this.finalLevel) {
                this.gameComplete = true;
            }
        } else {
            this.frameCount++;
            this.timeLeft = max(0, this.levelDuration - this.frameCount);
            if (this.timeLeft <= 0) {
                this.timeUp = true;
            }
        }
    };

    this.addTile = function() {
        let randomLane = floor(random(0, this.numLanes)); // Randomly select a lane
        let xPos = this.laneXPositions[randomLane]; // Get the x-position of the selected lane
        let minGap = this.tileHeight + 20; // Minimum gap between tiles
    
        // Check the last tile in the selected lane
        let lastTileInLane = this.tiles.filter(tile => tile.x === xPos).pop();
    
        // Only add a new tile if there is enough space
        if (!lastTileInLane || (lastTileInLane.y > minGap)) {
            let isSpecial = false;
            let shape = "rectangle";
            let color = this.getTileColor();
    
            if (random() < 0.1) {
                isSpecial = true;
                shape = random(["hexagon","star"]); 
                color = this.tileColors.special;
            }
    
            let newTile = {
                x: xPos,
                y: 0,
                w: this.tileWidth,
                h: this.tileHeight,
                speed: this.tileSpeed, // Set the speed to the fixed value
                isSpecial: isSpecial,
                shape: shape,
                color: color
            };
    
            this.tiles.push(newTile);
        }
    };
    

    // Function to get the color of a tile based on the energy level
// Function to get the color of a tile based on the energy level
this.getTileColor = function() {
    let spectrum = this.fft.analyze();
    let bassEnergy = this.getEnergy(spectrum, "bass");
    let lowMidEnergy = this.getEnergy(spectrum, "lowMid");
    let highMidEnergy = this.getEnergy(spectrum, "highMid");
    let trebleEnergy = this.getEnergy(spectrum, "treble");

    // Total energy sum to calculate probabilities
    let totalEnergy = bassEnergy + lowMidEnergy + highMidEnergy + trebleEnergy;

    // Avoid division by zero if total energy is very low
    if (totalEnergy < 1) {
        return color(255); // Default color if energy levels are too low
    }

    // Calculate probabilities for each frequency band
    let bassProbability = bassEnergy / totalEnergy;
    let lowMidProbability = lowMidEnergy / totalEnergy;
    let highMidProbability = highMidEnergy / totalEnergy;
    let trebleProbability = trebleEnergy / totalEnergy;

    // Random value between 0 and 1 to determine the selected color
    let randomValue = random(0,1);

    // Weighted selection based on calculated probabilities
    if (randomValue < bassProbability) {
        return this.tileColors.bass;  // Green for bass
    } else if (randomValue < bassProbability + lowMidProbability) {
        return this.tileColors.lowMid;  // Yellow for lowMid
    } else if (randomValue < bassProbability + lowMidProbability + highMidProbability) {
        return this.tileColors.highMid;  // Red for highMid
    } else {
        return this.tileColors.treble;  // Blue for treble
    }
};

    // Function to get the energy of a specific frequency band
    this.getEnergy = function(spectrum, type) {
        if (type === "bass") {
            return this.fft.getEnergy("bass");
        } else if (type === "lowMid") {
            return this.fft.getEnergy("lowMid");
        } else if (type === "highMid") {
            return this.fft.getEnergy("highMid");
        } else if (type === "treble") {
            return this.fft.getEnergy("treble");
        }
        return 0;
    };

    // Function to handle mouse presses
    this.mousePressed = function(x, y) {
        for (let i = this.tiles.length - 1; i >= 0; i--) {
            if (this.clicked(this.tiles[i], x, y)) {
                if (this.tiles[i].isSpecial) {
                    this.handleSpecialTile(this.tiles[i]);
                }
                this.tiles.splice(i, 1);
                this.score += 1;
                break;
            }
        }
    };

    this.handleSpecialTile = function(tile) {
        if (tile.shape === "star") {
            this.targetScore = max(1, this.targetScore - 2);
            push()
            this.message = "Score Target \nDecreased!";
            pop()
        } else if (tile.shape === "hexagon") {
            this.slowDownActive = true;
            this.slowDownFrames = this.slowDownDuration;
            push()
            this.message = "Tile Speed \nSlowed Down!";
            pop()
        }
        this.lastMessageFrame = frameCount;
        this.showSpecialMessage = true; // Flag to control special message display
    };
    
    // Function to check if a tile was clicked
    this.clicked = function(tile, x, y) {
        if (tile.shape === "rectangle") {
            return (x > tile.x && x < tile.x + tile.w && y > tile.y && y < tile.y + tile.h);
        } else if (tile.shape === "star" || tile.shape === "hexagon") {
            let d = dist(x, y, tile.x + tile.w / 2, tile.y + tile.h / 2);
            return d < tile.w / 2;
        }
        return false;
    };

    // Function to handle key presses
    this.keyPressed = function(keycode) {
        if (keycode === 78 && this.levelCompleted) {
            this.startNextLevel();
        } else if (keycode === 82 && (this.timeUp || this.gameComplete)) {
            this.restartGame();
        } else if (keycode === 83 && this.startScreen) {
            this.startScreen = false;
        }
    };

    this.startNextLevel = function() {
        this.currentLevel += 1;
        
        // Increment the target score to progressively increase the challenge level
        this.targetScore += 4 ; 
        // Slightly increase the speed of the falling tiles to enhance difficulty
        this.tileSpeed += 0.1; // Moderate increase in tile speed per level
        
        // Decrease the interval between new tiles being added, while ensuring it remains manageable
        this.tileInterval = max(25, 35 - this.currentLevel); // Gradual reduction in interval, with a lower bound
        
        // Reduce the level duration by 5 seconds for each level, with a minimum duration cap
        this.levelDuration = max(15 * 60, this.levelDuration - 5 * 60); // Minimum duration is 15 seconds
        
        // Reset score and other level-specific properties for the new level
        this.score = 0;
        this.frameCount = 0;
        this.timeLeft = this.levelDuration;
        this.levelCompleted = false;
        this.tiles = [];
        
        // Reset any active slowdown effects for the new level
        this.slowDownActive = false;
        this.slowDownFrames = 0;
        
        // Increment the frequency of special tiles appearing as the levels progress, with an upper limit
        this.specialTileFrequency = min(0.15, 0.1 + this.currentLevel * 0.01); // Cap frequency at 15%
    };
    
    this.restartGame = function() {
        this.currentLevel = 1;
        this.targetScore = 10;
        this.score = 0;
        this.frameCount = 0;
        // Reset the level duration to the initial value
        this.levelDuration = 30 * 60; // Reset to 30 seconds (or your initial duration value)
        this.timeLeft = this.levelDuration;
        this.timeUp = false;
        this.levelCompleted = false;
        this.gameComplete = false;
        this.tiles = [];
        
        // Reset slowdown effect for game restart
        this.slowDownActive = false;
        this.slowDownFrames = 0;
    };
    

    // Function to handle window resizing
    this.onResize = function() {
        this.calculateLanes(); // Recalculate lane positions if the window is resized
    };
// FireworkEffect class definition within PianoTiles
function FireworkEffect() {
    var fireworks = new Fireworks();

    this.setup = function() {
        background(0);
        angleMode(RADIANS);
        frameRate(60);
        fireworks = new Fireworks();
    };

    this.setup();

    this.draw = function() {
        background(0, 0, 0, 25); // Fading effect for trails
        if (random() < 0.08) { // Increase frequency of fireworks
            fireworks.addFirework();
        }
        fireworks.update();
    };

    // Fireworks management class
    function Fireworks() {
        var fireworks = [];

        this.addFirework = function() {
            var r = random(100, 255);
            var g = random(100, 255);
            var b = random(100, 255);
            var f_colour = color(r, g, b);
            var f_x = random(width * 0.2, width * 0.8);
            var f_y = random(height * 0.1, height * 0.6);
            var type = random(['standard', 'ring', 'explosion']);
            var firework = new Firework(f_colour, f_x, f_y, type);
            fireworks.push(firework);
        };

        this.update = function() {
            for (let i = fireworks.length - 1; i >= 0; i--) {
                fireworks[i].draw();
                if (fireworks[i].depleted) {
                    fireworks.splice(i, 1); // Remove depleted fireworks
                }
            }
        };
    }

    // Firework class to handle individual fireworks
    function Firework(colour, x, y, type) {
        var particles = [];
        this.depleted = false;

        // Initialize particles based on firework type
        if (type === 'standard') {
            for (var i = 0; i < 360; i += 18) {
                particles.push(new Particle(x, y, colour, i, random(5, 10)));
            }
        } else if (type === 'ring') {
            for (var i = 0; i < 360; i += 10) {
                particles.push(new Particle(x, y, colour, i, 7));
            }
        } else if (type === 'explosion') {
            for (var i = 0; i < 360; i += 12) { // Multiple layered explosion
                particles.push(new Particle(x, y, colour, i, random(6, 12), false, false, 4)); // Increased explosion stages
            }
        }

        this.draw = function() {
            for (var i = 0; i < particles.length; i++) {
                particles[i].draw();
            }

            // Check if all particles are depleted
            this.depleted = particles.every(p => p.speed <= 0 || p.age <= 0);
        };
    }

    // Particle class for firework particles
    function Particle(x, y, colour, angle, speed, isStar = false, isSpiral = false, explosionStages = 1) {
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.speed = speed;
        this.colour = colour;
        this.age = 255; // Lifespan of the particle
        this.explosionStages = explosionStages;
        this.explosionCounter = 0;

        this.draw = function() {
            this.update();
            var r = red(this.colour) - (255 - this.age);
            var g = green(this.colour) - (255 - this.age);
            var b = blue(this.colour) - (255 - this.age);

            // Glow effect by drawing a larger transparent ellipse
            var glowSize = 15 + sin(frameCount * 0.1) * 5; // Pulsing glow effect
            fill(r, g, b, this.age / 2);
            noStroke();
            ellipse(this.x, this.y, glowSize, glowSize);

            // Main particle
            var c = color(constrain(r, 0, 255), constrain(g, 0, 255), constrain(b, 0, 255));
            fill(c);
            noStroke();
            ellipse(this.x, this.y, 10, 10); // Particle size

            // Multi-stage explosions with more variability
            if (this.explosionStages > 1 && this.age < 200 && this.explosionCounter < this.explosionStages) {
                this.explosionCounter++;
                this.age += 60; // Reset age to prolong life and make stages more distinct
                this.speed = random(6, 12); // Reset speed for secondary explosion
                this.angle += random(-PI / 8, PI / 8); // Add randomness to explosion direction
                this.colour = color(random(100, 255), random(100, 255), random(100, 255)); // Change color with each stage
            }
        };

        this.update = function() {
            this.speed -= 0.1;
            this.age -= 4; // Particle fades faster
            this.x += cos(this.angle) * this.speed;
            this.y += sin(this.angle) * this.speed;
        };
    }
}


}

