var ridgeGui;
var butterflySpeed = 10; // This will now control the velocity
var showButterflies = true;
var showFractalTrees = true;
var showRidgePlots = true;
var speed = 0.7;
var maxWaves = 10;
var fractalDepth = 8;

function setup() {
    createCanvas(windowWidth, windowHeight);
    background(0);
    controls = new ControlsandInput();

    // Instantiate the new fft object
    fourier = new p5.FFT();

    // Create a new visualisation container
    vis = new Visualisations();
    vis.add(new RidgePlots());
}

function RidgePlots() 
{

    this.name = "Ridge Plots"; // Set the name of the visual

    // Variables for center coordinates and maximum radius of the plot
    var centerX;
    var centerY;
    var maxRadius;

    // Array to hold the wave data
    var output = [];

    // Array to hold butterfly objects
    var butterflies = [];

    // Array to hold fractal tree settings
    var fractalTrees = [];

    // Function to generate fractal trees with different properties
    function generateFractalTrees() {
        fractalTrees = []; // Clear previous trees
        var energyTypes = ["bass", "treble", "lowMid", "highMid"]; // Types of energy
        var energyColors = {
            "bass": "#00FF00",
            "treble": "#0000FF",
            "lowMid": "#FF0000",
            "highMid": "#FFFF00"
        };

        // Generate trees with random positions and properties
        for (var i = 0; i < 11; i++) { // Fixed number of trees
            var energyType = random(energyTypes); // Random energy type
            var color = energyColors[energyType]; // Corresponding color
            var x = (width / 2 - 500) + i * 100; // X position
            var y = windowHeight; // Y position
            var treeMaxRadius = min(width, height) / 5 * random(0.4, 0.8); // Maximum radius
            fractalTrees.push({ x: x, y: y, color: color, energyType: energyType, maxRadius: treeMaxRadius }); // Add to array
        }
    }

    // Function to generate butterfly objects with different properties
    function generateButterflies() {
        butterflies = []; // Clear previous butterflies
        var energyTypes = ["bass", "treble", "lowMid", "highMid"]; // Types of energy
        var energyColors = {
            "bass": "#00FF00",
            "treble": "#0000FF",
            "lowMid": "#FF0000",
            "highMid": "#FFFF00"
        };

        // Generate butterflies with random positions and properties
        for (var i = 0; i < 16; i++) { // Fixed number of butterflies
            var energyType = random(energyTypes); // Random energy type
            var color = energyColors[energyType]; // Corresponding color
            butterflies.push(new Butterfly(random(width), random(height), color, energyType)); // Add to array
        }
    }

    // Butterfly constructor function
    function Butterfly(x, y, color, energyType) {
        this.x = x; // X position
        this.y = y; // Y position
        this.color = color; // Butterfly color
        this.energyType = energyType; // Energy type
        this.angle = random(TWO_PI); // Random initial angle
        this.wingAngle = 0; // Initial wing angle
        this.size = 20; // Fixed size for the butterfly

        // Update the butterfly's position and wing flapping
        this.update = function() {
            this.angle += map(noise(frameCount * 0.01), 0, 1, -0.1, 0.1); // Update angle with noise
            this.x += cos(this.angle) * butterflySpeed * 0.5; // Update X position with butterflySpeed controlling velocity
            this.y += sin(this.angle) * butterflySpeed * 0.5; // Update Y position with butterflySpeed controlling velocity

            // Keep the butterfly confined to the screen
            this.x = constrain(this.x, this.size, width - this.size);
            this.y = constrain(this.y, this.size, height - this.size);

            // Wing flapping influenced by tree energy
            var energy = fourier.getEnergy(this.energyType); // Get energy level
            var wingSpeed = map(energy, 0, 255, 0.05, 0.2); // Map energy to wing speed
            this.wingAngle = sin(frameCount * wingSpeed) * PI / 6; // Update wing angle
        }

        // Display the butterfly on the screen
        this.display = function() {
            push(); // Save current state
            translate(this.x, this.y); // Translate to butterfly position
            fill(this.color); // Set fill color
            noStroke(); // No stroke

            // Draw left wing
            push(); // Save current state
            rotate(-this.wingAngle); // Rotate wing
            ellipse(-this.size / 2, 0, this.size, this.size * 1.5); // Draw ellipse
            pop(); // Restore state

            // Draw right wing
            push(); // Save current state
            rotate(this.wingAngle); // Rotate wing
            ellipse(this.size / 2, 0, this.size, this.size * 1.5); // Draw ellipse
            pop(); // Restore state

            // Draw body
            fill(0); // Set fill color to black
            ellipse(0, 0, this.size / 4, this.size / 2); // Draw body ellipse

            // Draw antennas
            stroke(255); // Set stroke to white for the antennas
            strokeWeight(1); // Set stroke weight
            line(0, -this.size / 4, -this.size / 4, -this.size / 2); // Draw left antenna
            line(0, -this.size / 4, this.size / 4, -this.size / 2); // Draw right antenna

            pop(); // Restore state
        }
    }

    // Function to handle resizing of the window
    this.onResize = function() {
        centerX = width / 2; // Update center X
        centerY = height / 2; // Update center Y
        maxRadius = min(width, height) / 3; // Update maximum radius

        // Generate fractal trees and butterflies on resize
        generateFractalTrees();
        generateButterflies();
    }
    this.onResize(); // Call onResize initially

    // Initial setup function
    this.setup = function() {
        this.onResize(); // Call onResize during setup
        // Initialize the GUI
        ridgeGui = createGui('Ridge Plot Controls');
        ridgeGui.addGlobals('butterflySpeed', 'showButterflies', 'showFractalTrees', 'showRidgePlots', 'speed', 'maxWaves', 'fractalDepth');
        ridgeGui.setPosition(windowWidth - 220, 20); // Move GUI to the right
        ridgeGui.hide(); // Hide GUI initially
    }
    this.setup(); // Call setup

    // Function called when the visual is deselected
    this.unSelectVisual = function() {
        console.log("de select"); // Log deselect
        ridgeGui.hide(); // Hide GUI when deselected
    }

    // Function called when the visual is selected
    this.selectVisual = function() {
        console.log("select"); // Log select
        ridgeGui.show(); // Show GUI when selected
    }

    // Main draw function called on every frame
    this.draw = function() {
        background(0); // Clear the background
        noFill(); // No fill for shapes
        strokeWeight(2); // Set stroke weight

        // Add a new wave every 10 frames
        if (frameCount % 10 == 0) {
            addWave();
        }

        if (showRidgePlots) {
            drawRidgePlots(); // Draw ridge plots
        }

        if (showFractalTrees) {
            drawFractalTrees(); // Draw fractal trees
        }

        if (showButterflies) {
            drawButterflies(); // Draw butterflies
        }
    }

    // Function to add a new wave to the output array
    function addWave() {
        var w = fourier.waveform(); // Get the waveform data
        var outputWave = []; // Initialize a new wave array
        var smallScale = maxRadius * 0.3; // Small scale factor
        var bigScale = maxRadius * 0.6; // Big scale factor

        // Generate wave data based on the waveform
        for (var i = 0; i < w.length; i++) {
            if (i % 20 == 0) { // Process every 20th element
                var angle = map(i, 0, w.length, 0, TWO_PI); // Map index to angle
                var r;
                if (i < w.length * 0.25 || i > w.length * 0.75) {
                    r = maxRadius + map(w[i], -1, 1, -smallScale, smallScale); // Map to small scale
                } else {
                    r = maxRadius + map(w[i], -1, 1, -bigScale, bigScale); // Map to big scale
                }
                var amplitude = w[i]; // Amplitude value
                var o = { angle: angle, r: r, amplitude: amplitude }; // Wave object
                outputWave.push(o); // Add to wave array
            }
        }
        output.push(outputWave); // Add new wave to output
    }

    // Function to draw the ridge plots
    function drawRidgePlots() {
        for (var i = output.length - 1; i >= 0; i--) { // Loop through waves in reverse order
            var wave = output[i];
            colorMode(HSB, 360); // Set color mode to HSB
            stroke((frameCount + i * 10) % 360, 360, 360); // Set stroke color

            beginShape(); // Begin shape
            for (var j = 0; j < wave.length; j++) { // Loop through wave points
                var angle = wave[j].angle;
                var baseRadius = wave[j].r;
                var amplitude = wave[j].amplitude;
                var pulsateRadius = baseRadius + map(amplitude, -1, 1, -baseRadius * 0.5, baseRadius * 0.5) + baseRadius * 0.1 * sin(frameCount * 0.1); // Pulsating effect
                var r = max(pulsateRadius, 0); // Ensure r is not negative
                var x = centerX + r * cos(angle); // Calculate X position
                var y = centerY + r * sin(angle); // Calculate Y position
                vertex(x, y); // Add vertex to shape
            }
            endShape(CLOSE); // Close shape

            // Reduce the radius of the wave for trailing effect
            for (var j = 0; j < wave.length; j++) {
                wave[j].r -= speed;
            }

            // Remove wave if it has shrunk to invisible
            if (wave[0].r < -maxRadius) {
                output.splice(i, 1); // Remove from output
            }
        }

        // Limit the number of waves displayed
        while (output.length > maxWaves) {
            output.shift(); // Remove the oldest wave
        }

        // Switch back to RGB mode for other visualizations
        colorMode(RGB);
    }

    // Function to draw the fractal trees
    function drawFractalTrees() {
        for (var i = 0; i < fractalTrees.length; i++) { // Loop through fractal trees
            fourier.analyze(); // Analyze the sound
            var tree = fractalTrees[i];
            var energy = 0;

            if (tree.energyType === "bass") {
                energy = fourier.getEnergy("bass"); // Get bass energy
            } else if (tree.energyType === "treble") {
                energy = fourier.getEnergy("treble"); // Get treble energy
            } else if (tree.energyType === "lowMid") {
                energy = fourier.getEnergy("lowMid"); // Get low mid energy
            } else if (tree.energyType === "highMid") {
                energy = fourier.getEnergy("highMid"); // Get high mid energy
            }

            push(); // Save current state
            translate(tree.x, tree.y); // Translate to tree position
            stroke(tree.color); // Set stroke color
            drawFractalBranch(tree.maxRadius, energy, fractalDepth); // Draw fractal branches
            pop(); // Restore state
        }
    }

    // Recursive function to draw fractal branches
    function drawFractalBranch(len, energy, depth) {
        if (depth === 0 || len < 1) {
            return; // Base case for recursion
        }

        var angle = map(energy, 0, 255, PI / 9, PI / 4); // Map energy to angle
        var lenReduction = map(energy, 0, 255, 0.7, 0.85); // Map energy to length reduction

        strokeWeight(map(len, 10, maxRadius, 1, 5)); // Set stroke weight
        line(0, 0, 0, -len); // Draw branch
        translate(0, -len); // Move to the end of the branch

        if (len > 10) { // Continue recursion if length is sufficient
            push(); // Save current state
            rotate(angle); // Rotate to the right
            drawFractalBranch(len * lenReduction, energy, depth - 1); // Draw right branch
            pop(); // Restore state

            push(); // Save current state
            rotate(-angle); // Rotate to the left
            drawFractalBranch(len * lenReduction, energy, depth - 1); // Draw left branch
            pop(); // Restore state
        }
    }

    // Function to draw butterflies
    function drawButterflies() {
        for (var i = 0; i < butterflies.length; i++) { // Loop through butterflies
            butterflies[i].update(); // Update butterfly position and wings
            butterflies[i].display(); // Display butterfly
        }
    }
}
