// placeCueBallAt(x, y)
// Places the cue ball at the specified position after validating placement rules
function placeCueBallAt(x, y) {
  // 1. Ensure the cue ball is within the D Zone
  if (!isWithinD(x, y)) {
      console.log("Cue ball must be placed within the D Zone.");
      push();
      fill(255, 0, 0, 150); // Red highlight for invalid placement
      noStroke();
      ellipse(x, y, ballDiameter * 1.2); // Highlight the invalid position
      pop();
      return; // Exit if placement is invalid
  }

  // 2. Check if the position overlaps with other balls
  let overlapping = balls.some((ball) => {
      let dx = x - ball.position.x;
      let dy = y - ball.position.y;
      let distance = Math.sqrt(dx * dx + dy * dy);
      return distance < ballDiameter;
  });

  // 3. Check if the position overlaps with any pockets
  let overlappingPocket = pockets.some((pocket) => {
      let dx = x - pocket.x;
      let dy = y - pocket.y;
      let distance = Math.sqrt(dx * dx + dy * dy);
      return distance < pocket.radius + ballDiameter / 2;
  });

  // 4. Check if the position collides with maze walls (only in Mode 4)
  let collidingWithMazeWalls = false;
  if (currentMode === 4) {
      let tempCueBall = Bodies.circle(x, y, ballDiameter / 2, {
          isStatic: true, // Temporary static body for checking collisions
          isSensor: true, // Doesn't interact with the physics world
          label: "tempCueBall",
      });
      let collisions = Matter.Query.collides(tempCueBall, mazeWalls);
      collidingWithMazeWalls = collisions.length > 0;
  }

  if (collidingWithMazeWalls) {
      console.log("Cannot place cue ball inside maze walls.");
      push();
      fill(255, 0, 0, 150); // Red highlight for invalid placement
      noStroke();
      ellipse(x, y, ballDiameter * 1.2); // Highlight the invalid position
      pop();
      return; // Exit if placement is invalid
  }

  // 5. Place the cue ball if all checks pass
  if (!overlapping && !overlappingPocket && !collidingWithMazeWalls) {
      createAndAddCueBall(x, y);
      console.log("Cue ball placed successfully.");
  } else {
      // Invalid placement due to overlap
      console.log("Cannot place cue ball here. Overlapping with another ball or pocket.");
      push();
      fill(255, 0, 0, 150); // Red highlight for invalid placement
      noStroke();
      ellipse(x, y, ballDiameter * 1.2); // Highlight the invalid position
      pop();
  }
}

// resetCueBallPosition()
// Removes the current cue ball and prompts the user to place a new one manually
function resetCueBallPosition() {
  if (cueBall) {
      World.remove(world, cueBall); // Remove existing cue ball
      cueBall = null;
      cue = null;
      console.log("Cue ball removed.");
  }

  placingCueBall = true; // Enable manual placement
  console.log("Cue ball placement initiated.");
}

// resetCueBallStandardMode()
// Removes the current cue ball and prompts placement for Standard Mode
function resetCueBallStandardMode() {
  if (cueBall) {
      World.remove(world, cueBall); // Remove existing cue ball
      cueBall = null;
      cue = null;
      console.log("Cue ball removed for Standard Mode.");
  }

  placingCueBall = true; // Enable manual placement
  console.log("Cue ball placement initiated for Standard Mode.");
}

// resetCueBallMazeRunnerMode()
// Removes the current cue ball and prompts placement for MazeRunner Mode
function resetCueBallMazeRunnerMode() {
  if (cueBall) {
      World.remove(world, cueBall); // Remove existing cue ball
      cueBall = null;
      cue = null;
      console.log("Cue ball removed for MazeRunner Mode.");
  }

  placingCueBall = true; // Enable manual placement
  console.log("Cue ball placement initiated for MazeRunner Mode.");
}

// createAndAddCueBall(x, y)
// Creates a new cue ball at the given position and places it on the table
function createAndAddCueBall(x, y) {
  cueBall = Bodies.circle(x, y, ballDiameter / 2, {
      restitution: 0.9, // Bounciness
      friction: 0.005, // Low friction
      label: "cueBall", // Identify as the cue ball
  });
  cueBall.color = "white"; // Set cue ball color
  World.add(world, cueBall); // Add cue ball to the physics world

  cue = createCue(); // Create cue stick for the cue ball

  placingCueBall = false; // Disable manual placement mode
  console.log("New cue ball created and placed successfully.");
}

// drawStrengthBar()
// Draws a dynamic power strength bar showing the cue force
function drawStrengthBar() {
  push(); // Save current styles

  let barX = width - 50; // X position of the bar
  let barY = height / 2; // Y position of the bar
  let barWidth = 20; // Width of the bar
  let barHeight = 200; // Height of the bar
  let cornerRadius = barWidth / 2; // Rounded edges for the bar

  // Draw the background of the bar
  fill(180); // Light gray background
  noStroke();
  rectMode(CENTER);
  rect(barX, barY, barWidth, barHeight, cornerRadius);

  // Calculate and draw the strength bar based on cue force
  let strengthHeight = map(cueForce, 0.005, 0.06, 0, barHeight - 4); // Scale cue force to bar height
  let strengthY = barY + barHeight / 2 - strengthHeight / 2 - 2; // Align strength bar within the background
  let gradientColor = lerpColor(color(0, 255, 0), color(255, 0, 0), cueForce / 0.06); // Green to red gradient
  fill(gradientColor);
  rect(barX, strengthY, barWidth - 4, strengthHeight, cornerRadius / 2);

  // Add a sleek white border around the bar
  noFill();
  stroke(255); // White border
  strokeWeight(1.5);
  rect(barX, barY, barWidth, barHeight, cornerRadius);

  // Draw the "Power" label above the bar
  noStroke();
  fill(0, 0, 0, 100); // Shadow for the label
  textSize(14);
  textAlign(CENTER);
  text("Power", barX + 1, barY - barHeight / 2 - 9); // Slight shadow offset
  fill(255); // White label text
  text("Power", barX, barY - barHeight / 2 - 10); // Main label

  pop(); // Restore styles
}


// createCueBall()
// Creates the cue ball at a fixed position on the table
function createCueBall() {
  cueBall = Bodies.circle(
    (width - tableWidth) / 2 + tableWidth / 5, // Initial X position
    height / 2, // Initial Y position
    ballDiameter / 2, // Radius of the cue ball
    {
      restitution: 0.9, // Bounciness
      friction: 0.005, // Low friction for smooth movement
      label: "cueBall", // Identify as the cue ball
    }
  );
  cueBall.color = "white"; // Set cue ball color to white
  World.add(world, cueBall); // Add the cue ball to the physics world
}

// createCue()
// Creates a cue stick representation based on the cue ball's position
function createCue() {
  if (!cueBall) return null; // Exit if there is no cue ball
  let offset = ballDiameter; // Offset to position the cue stick
  return {
    x: cueBall.position.x - cos(cueDirection) * (offset + 200), // X position
    y: cueBall.position.y - sin(cueDirection) * (offset + 200), // Y position
    length: 200, // Cue stick length
    angle: cueDirection, // Angle of the cue stick
  };
}

// resetCueStick()
// Resets the cue stick's state and position to default
function resetCueStick() {
  cueState = "rest"; // Set the cue state to rest
  cueStickOffset = 0; // Reset the offset
  cueForce = 0.006; // Reset the force
  cueDirection = 0; // Reset the direction
}


// updateCueWithMouse()
// Updates the cue stick position and behavior based on mouse input
function updateCueWithMouse() {
  // Exit if there is no cue ball
  if (!cueBall) {
      return;
  }

  // Calculate direction from the cue ball to the mouse position
  let dx = mousePosition.x - cueBall.position.x;
  let dy = mousePosition.y - cueBall.position.y;
  cueDirection = Math.atan2(dy, dx);

  // Skip further processing if control mode is set to "mouse"
  if (controlMode === "mouse") {
      return;
  }

  // Handle cue stick pullback when the mouse is pressed
  if (isMousePressed && cueState === "rest") {
      let distance = Math.min(Math.sqrt(dx * dx + dy * dy), maxPullBack); // Limit pullback distance
      cueStickOffset = distance; // Set pullback distance
      cueForce = map(distance, 0, maxPullBack, 0.001, 0.012); // Map pullback to cue force
  } 
  // Start striking motion when the mouse is released
  else if (!isMousePressed && cueState === "rest" && cueStickOffset > 0) {
      cueState = "striking";
  }
}

// drawCue()
// Draws the cue stick and handles its animation and interaction with the cue ball
function drawCue() {
  if (!isCueBallInMotion && cueBall) {
      push();

      // Calculate cue stick position
      let initialOffset = ballDiameter;
      let cueX1 = cueBall.position.x - cos(cueDirection) * (initialOffset + 200 + cueStickOffset);
      let cueY1 = cueBall.position.y - sin(cueDirection) * (initialOffset + 200 + cueStickOffset);
      let cueX2 = cueBall.position.x - cos(cueDirection) * (initialOffset + cueStickOffset);
      let cueY2 = cueBall.position.y - sin(cueDirection) * (initialOffset + cueStickOffset);

      let cueWidth = 10;
      let tipLength = 20;
      let gradientStops = 5;

      // Draw cue stick with gradient effect
      for (let i = 0; i < gradientStops; i++) {
          let t = i / gradientStops;
          let gradColor = lerpColor(color(139, 69, 19), color(255, 228, 181), t); // Gradient from brown to beige
          stroke(gradColor);
          strokeWeight(cueWidth * (1 - t * 0.7));
          let x1 = lerp(cueX1, cueX2, t);
          let y1 = lerp(cueY1, cueY2, t);
          let x2 = lerp(cueX1, cueX2, t + 1 / gradientStops);
          let y2 = lerp(cueY1, cueY2, t + 1 / gradientStops);
          line(x1, y1, x2, y2);
      }

      // Draw cue tip
      let tipX1 = cueX2;
      let tipY1 = cueY2;
      let tipX2 = tipX1 - cos(cueDirection) * tipLength;
      let tipY2 = tipY1 - sin(cueDirection) * tipLength;

      stroke(50, 50, 50); // Dark gray tip
      strokeWeight(cueWidth * 0.5);
      line(tipX1, tipY1, tipX2, tipY2);

      fill(0, 255, 0); // Green tip highlight
      noStroke();
      ellipse(tipX2, tipY2, cueWidth * 0.6, cueWidth * 0.6);

      pop();
  }

  // Cue stick animation
  if (cueState === "pullingBack") {
      if (cueStickOffset < maxPullBack) {
          cueStickOffset += pullBackSpeed; // Pull the cue stick back
      } else {
          cueState = "striking"; // Ready to strike
      }
  } else if (cueState === "striking") {
      if (cueStickOffset > 0) {
          cueStickOffset -= strikeSpeed; // Strike forward
      } else {
          cueState = "rest"; // Cue returns to rest

          // Apply force to the cue ball
          if (cueForce > 0.001 && cueBall) {
              let scalingFactor = 0.2; // Scale the force
              let forceX = cos(cueDirection) * cueForce * scalingFactor;
              let forceY = sin(cueDirection) * cueForce * scalingFactor;
              Matter.Body.applyForce(cueBall, cueBall.position, { x: forceX, y: forceY });
              isCueBallInMotion = true; // Cue ball is now in motion
          }
      }
  }
}

// canResetBall(ball)
// Checks if the ball can be reset to its original position without overlapping others
function canResetBall(ball) {
  return !balls.some((otherBall) => {
    if (otherBall === ball) return false; // Skip the ball being checked
    let dx = ball.originalPosition.x - otherBall.position.x;
    let dy = ball.originalPosition.y - otherBall.position.y;
    let distance = Math.sqrt(dx * dx + dy * dy); // Calculate distance between balls
    return distance < ballDiameter; // Overlaps if distance is less than ball diameter
  });
}
