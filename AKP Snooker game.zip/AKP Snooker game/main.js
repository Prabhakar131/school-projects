/*
Snooker/MazeRunner Game Overview
This code creates a snooker-inspired game with multiple gameplay modes, including the innovative "MazeRunner" (Mode 4). Built using Matter.js, a physics engine, the game features dynamic interactions between balls, pockets, cushions, and a procedurally generated maze.

Game Mechanics
The gameplay revolves around striking balls with a cue ball to pot them into pockets. Key mechanics include:

Cue Stick Controls: Players can control the cue stick using either the keyboard or mouse to adjust its angle and force.
Ball Dynamics: Realistic physics governs ball movements, collisions, and interactions with the table and other elements.
Pocketing System: Balls are potted with specific rules for handling red and colored balls.
Modes
The game supports four modes:

Mode 1 (Standard): Classic snooker setup with triangular reds and colored balls in traditional positions.
Mode 2 (Random Reds): Random placement of reds with fixed positions for colored balls.
Mode 3 (Fully Random): Both reds and colored balls are randomly positioned.
Mode 4 (MazeRunner): Players navigate a procedurally generated maze to pot the cue ball into a designated target pocket, marked with a halo.
Features
Procedural Maze Generation (Mode 4):

A grid-based maze is generated using a depth-first search algorithm with backtracking.
Walls toggle dynamically, and solvability is ensured by validating connectivity between the start and target pocket.
Target Pocket (Mode 4):

A random pocket serves as the goal. Correct pocketing completes the mode, while wrong pocketing prompts a retry with visual feedback.
Collision Handling:

Red balls are removed upon pocketing.
Colored balls reset to their original positions after a delay, with overlap checks.
Cue ball pocketing requires manual repositioning in the D Zone.
Cue Stick Dynamics:

Players pull back and release the cue stick to strike the cue ball, with adjustable power and a dynamic power bar for feedback.
Visual Enhancements:

Rounded table edges, semi-transparent cushions, and pocket halos enhance visuals.
An instruction screen introduces controls and gameplay mechanics.
Mode 4 Extension: MazeRunner
This unique mode challenges players to navigate a maze, potting the cue ball into a designated pocket. The maze dynamically rearranges every 10 seconds, adding variety and complexity. Players must avoid maze walls while maintaining precision to reach the goal.

Challenges and Rules
Balls must not overlap with each other, pockets, or maze walls (in Mode 4).
Cue ball placement is restricted to the D Zone, with penalties for violations.
Error messages notify players of rule infractions, such as wrong pocketing or consecutive colored ball potting.
Conclusion
The Snooker/MazeRunner game combines classic snooker mechanics with the strategic and problem-solving challenges of MazeRunner mode. The extension transforms traditional gameplay into an engaging hybrid experience, offering precision, strategy, and innovation.
*/






// Matter.js module aliases
var Engine = Matter.Engine;
var World = Matter.World;
var Bodies = Matter.Bodies;

// Global variables declaration 
var engine;
var world;

var tableWidth;
var tableHeight;
var ballDiameter;
var pocketDiameter;
var edgeOffset;

var balls;
var cueBall;
var pockets;
var cue;

var cueForce;
var cueDirection;
var tableEdges;

var isCueBallInMotion;
var cueStickOffset;
var maxPullBack;
var pullBackSpeed;
var strikeSpeed;
var cueState;

var mousePosition;
var isMousePressed;
var controlMode;
var showInstructions;

var dCenterX;
var dCenterY;
var dZoneRadius;
var placingCueBall;
var coloredPottedCount;

var showConsecutivePottedBallsMessage;
var messageDisplayTime;
var messageTimer;

var showResetFailureMessage;
var resetFailureCount;
var resetFailureDisplayTime;
var resetFailureTimer;

var cushions;
var mazeWalls;
var currentMode;
var rows;
var cols;
var cellSize;
var wallThickness;
var maze;
var wallOptions;

var showWrongPocketMessage;
var wrongPocketDisplayTime;
var wrongPocketTimer;
var isModeComplete;


function setup() {
  // Canvas and environment setup
  createCanvas(windowWidth, windowHeight);

  // Game variables initialization
  tableWidth = windowWidth * 0.8;
  tableHeight = tableWidth / 2;
  ballDiameter = tableHeight / 36;
  pocketDiameter = ballDiameter * 1.5;
  edgeOffset = 49;

  balls = [];
  cueBall = null;
  pockets = [];
  cue = null;
  cueForce = 0.006;
  cueDirection = 0;
  tableEdges = [];
  isCueBallInMotion = false;
  cueStickOffset = 0; // Distance the cue stick is offset backward
  maxPullBack = 50; // Maximum pull-back distance
  pullBackSpeed = 5; // Speed of pulling back
  strikeSpeed = 10; // Speed of striking forward
  cueState = "rest"; // Cue stick state: 'rest', 'pullingBack', 'striking'
  mousePosition = { x: 0, y: 0 }; // Track the mouse position
  isMousePressed = false; // Track whether the mouse is pressed
  controlMode = "keyboard"; // Default to keyboard control
  showInstructions = true;

  // D zone parameters
  dCenterX = (width - tableWidth) / 2 + tableWidth / 4;
  dCenterY = height / 2;
  dZoneRadius = tableWidth / 12;
  placingCueBall = true; // Initialize to true at game start
  coloredPottedCount = 0; // Tracks consecutive colored pottings

  // Message management variables
  showConsecutivePottedBallsMessage = false;
  messageDisplayTime = 3000; // 3 seconds
  messageTimer = 0;

  // Reset failure message variables
  showResetFailureMessage = false;
  resetFailureCount = 0;
  resetFailureDisplayTime = 3000; // 3 seconds
  resetFailureTimer = 0;

  cushions = [];
  mazeWalls = [];
  currentMode = 4;

  // Maze generation variables
  rows = 6; // Number of rows in the maze
  cols = 6; // Number of columns in the maze
  cellSize = 60; // Size of each cell in pixels
  wallThickness = 4; // Thickness of maze walls
  maze = []; // 2D array to represent the maze structure

  // Maze wall options for Matter.js
  wallOptions = {
    isStatic: true,
    restitution: 1.2,
    friction: 0.02,
    label: "mazeWall", // Distinct label to differentiate from cushions
  };

  // Wrong pocket message in Mode 4
  showWrongPocketMessage = false;
  wrongPocketDisplayTime = 3000; // e.g., 3 seconds
  wrongPocketTimer = 0;

  // Mode complete for MazeRunner
  isModeComplete = false;

  // Initialize Matter.js engine and world
  engine = Engine.create();
  world = engine.world;
  engine.world.gravity.y = 0;

  // Initialize game elements
  createTable();
  createCushions();
  createPockets();
  targetPocket = pockets[3];
  setupBalls(currentMode);

  debugBallAndPocketSizes();

  // Add collision handler
  Matter.Events.on(engine, "collisionStart", handleCollision);

  // Adjust maze dimensions based on table size
  cellSize = tableWidth / (cols * 2);
  rows = floor(tableHeight / cellSize);
  cols = floor(tableWidth / cellSize);

  // Generate initial maze walls
  generateMazeWalls();

  // Schedule dynamic rearrangement every ~10 seconds in Mode 4
  setInterval(() => {
    if (currentMode === 4) {
      dynamicRearrangeMazeWalls();
    }
  }, 10000);
}

function draw() {
  background(139);
   // Draw instruction screen on top 
   if (showInstructions) {
    drawInstructionScreen();
    return;
  }


  Engine.update(engine);
  checkPocketedBalls();
  drawTable();
  drawDZone();
  drawCushions();
  drawPockets();
  drawBalls();


  
  // If we are not currently placing the cue ball and it's not in motion, show the cue
  if (!placingCueBall && !isCueBallInMotion) {
    drawCue();
  }

  drawStrengthBar();

  // Handle cue stick based on control mode
  if (controlMode === "mouse" && !placingCueBall) {
    updateCueWithMouse();
  }

  // If we are placing the cue ball, show a ghost cue ball at the confined mouse position
  if (placingCueBall) {
    let confinedPos = confinePointToD(mouseX, mouseY);
    drawGhostCueBall(confinedPos.x, confinedPos.y);
    // Display a message to place the cue ball
    displayPlaceCueBallMessage(width, dCenterY, dZoneRadius);
   ;
  }

  // Display numerical cueForce when in mouse mode
  if (controlMode === "mouse" && !placingCueBall) {
    displayCueForce(cueForce, width, height);
  }

    

  if (showWrongPocketMessage) {
    displayWrongPocketMessage(wrongPocketTimer, wrongPocketDisplayTime, width, height);
  }

  

  // Display consecutive colored potted balls error message if applicable
  if (showConsecutivePottedBallsMessage) {
    push();
    fill(255, 0, 0);
    textSize(24);
    textAlign(CENTER, CENTER);
    text("Error: Two colored balls potted consecutively!", width / 2, height / 2 - 50);
    pop();

    // Check if the display time has elapsed
    if (millis() - messageTimer > messageDisplayTime) {
      showConsecutivePottedBallsMessage = false;
    }
  }

  // Display reset failure message if applicable
  if (showResetFailureMessage) {
    displayResetFailureMessage(resetFailureCount, resetFailureTimer, resetFailureDisplayTime, width, height);
  }

  // Safety check for cueBall motion
  if (cueBall) {
    isCueBallInMotion =
      Math.abs(cueBall.velocity.x) > 0.01 || Math.abs(cueBall.velocity.y) > 0.01;
  } else {
    isCueBallInMotion = false;
  }

  // Draw Maze Walls only in Mode 4
  if (currentMode === 4) {
    drawMazeWalls();
    drawHaloAroundPockets();
  }

  // --- Display Mode Complete if set ---
  if (isModeComplete) {
    drawModeCompleteScreen(); 
     return;
  }
}

