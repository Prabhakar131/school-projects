// displayConsecutiveColoredPottedBallsMessage()
// Activates the message for consecutive colored balls being potted
function displayConsecutiveColoredPottedBallsMessage() {
  showConsecutivePottedBallsMessage = true; // Enable the message
  messageTimer = millis(); // Record the current time
}

// displayResetFailureMessage(ballColor)
// Activates the reset failure message with the specific ball color
function displayResetFailureMessage(ballColor) {
  showResetFailureMessage = true; // Enable the message
  resetFailureCount = ballColor; // Set the ball color causing the failure
  resetFailureTimer = millis(); // Record the current time
}

// drawInstructionScreen()
// Draws the instruction screen with gradient background and game instructions
function drawInstructionScreen() {
  push(); // Save current styles

  // Gradient background from orange to red
  for (let i = 0; i < height; i++) {
    let inter = map(i, 0, height, 0, 1);
    let c = lerpColor(color(255, 183, 77), color(255, 87, 51), inter);
    stroke(c);
    line(0, i, width, i);
  }

  // Centered instruction box
  const boxWidth = width * 0.8;
  const boxHeight = height * 0.8;
  const boxX = (width - boxWidth) / 2;
  const boxY = (height - boxHeight) / 2;

  fill(255, 234, 167, 220); // Light pastel yellow
  stroke(255, 87, 51); // Red-orange border
  strokeWeight(4);
  rect(boxX, boxY, boxWidth, boxHeight, 20); // Rounded corners

  // Title and instructions
  noStroke();
  fill(51, 51, 255); // Vibrant blue text
  textAlign(CENTER, CENTER);
  textSize(36);
  textStyle(BOLD);
  text("🎱 Welcome to the Snooker/Maze Game! 🎮", width / 2, boxY + 50);

  textSize(20);
  textStyle(NORMAL);
  textAlign(LEFT, TOP);
  const instructions = `
- Use 'T' to toggle between keyboard and mouse cue controls.
- Press 1, 2, 3 for normal modes; Press 4 for MazeRunner mode.

Keyboard Controls:
  • LEFT/RIGHT to aim
  • UP/DOWN to adjust power
  • SPACE to shoot

Mouse Controls:
  • Move mouse to aim
  • Click (and drag) or scroll wheel to adjust power
  • Release to shoot

Press ENTER to close this instruction screen.
`;
  text(instructions, boxX + 40, boxY + 120, boxWidth - 80, boxHeight - 160);

  // Glowing effect around the box
  noFill();
  stroke(255, 87, 51, 150);
  strokeWeight(8);
  rect(boxX - 5, boxY - 5, boxWidth + 10, boxHeight + 10, 20);

  // Bottom box for "Press ENTER to Play"
  const bottomBoxWidth = 300;
  const bottomBoxHeight = 60;
  const bottomBoxX = (width - bottomBoxWidth) / 2;
  const bottomBoxY = boxY + boxHeight - 80;

  fill(255, 87, 51); // Red-orange fill
  stroke(255); // White border
  strokeWeight(2);
  rect(bottomBoxX, bottomBoxY, bottomBoxWidth, bottomBoxHeight, 15); // Rounded corners

  // Text inside bottom box
  noStroke();
  fill(255); // White text
  textSize(24);
  textStyle(BOLD);
  text("Press ENTER to Play!", width / 2.4, bottomBoxY + bottomBoxHeight / 3);

  pop(); // Restore styles
}

// drawModeCompleteScreen()
// Draws a screen indicating that MazeRunner mode is complete
function drawModeCompleteScreen() {
  push(); // Save current styles

  // Dark overlay background
  fill(0, 0, 0); // Black
  rectMode(CORNER);
  rect(0, 0, width, height);

  // Main message
  fill(0, 255, 0); // Green text
  textSize(50);
  textAlign(CENTER, CENTER);
  text("MazeRunner Complete!", width / 2, height / 2 - 20);

  // Subtext
  textSize(20);
  fill(255); // White text
  text("Press 'R' to reset and play again.", width / 2, height / 2 + 40);

  pop(); // Restore styles
}

// displayPlaceCueBallMessage(width, dCenterY, dZoneRadius)
// Displays a message prompting the user to place the cue ball in the D zone
function displayPlaceCueBallMessage(width, dCenterY, dZoneRadius) {
  push(); // Save current styles

  // Background box dimensions and position
  let textPadding = 20;
  let boxWidth = 900;
  let boxHeight = 50;
  let boxX = width / 2 - boxWidth / 2;
  let boxY = dCenterY - dZoneRadius - 60;

  // Draw the background box with rounded corners
  fill(50, 50, 50); // Dark gray fill
  rect(boxX, boxY, boxWidth, boxHeight, 10);

  // Add red border around the box
  stroke(255, 0, 0); // Red color
  strokeWeight(2);
  noFill();
  rect(boxX, boxY, boxWidth, boxHeight, 10);

  // Reset stroke for text
  noStroke();

  // Draw text shadow
  textSize(28); // Set text size
  textAlign(CENTER, CENTER); // Center alignment
  fill(0, 0, 0, 100); // Semi-transparent black
  text(
    "Place the Cue Ball within the D Zone without overlapping other balls",
    width / 2 + 2, // Shadow offset
    dCenterY - dZoneRadius - 35
  );

  // Draw main text
  fill(255, 0, 0); // Red text
  text(
    "Place the Cue Ball within the D Zone without overlapping other balls",
    width / 2,
    dCenterY - dZoneRadius - 37
  );

  pop(); // Restore styles
}

// displayCueForce(cueForce, width, height)
// Displays the cue force percentage on the screen
function displayCueForce(cueForce, width, height) {
  push(); // Save current styles
  fill(255); // White text color
  textSize(16); // Set text size
  textAlign(RIGHT, TOP); // Align text to the top-right corner
  text(`Force: ${Math.min((cueForce * 100).toFixed(0), 100)}%`, width - 10, height - 220); // Display force percentage
  pop(); // Restore styles
}

// displayWrongPocketMessage(wrongPocketTimer, wrongPocketDisplayTime, width, height)
// Displays a "Wrong Pocket" message with a background box
function displayWrongPocketMessage(wrongPocketTimer, wrongPocketDisplayTime, width, height) {
  push(); // Save current styles

  // Background box dimensions and position
  let boxWidth = 400;
  let boxHeight = 80;
  let boxX = width / 2 - boxWidth / 2;
  let boxY = height / 2 - 120;

  // Draw background box with rounded corners
  fill(50, 50, 50, 200); // Semi-transparent dark gray
  rect(boxX, boxY, boxWidth, boxHeight, 10);

  // Add red border around the box
  stroke(255, 0, 0); // Red color
  strokeWeight(3);
  noFill();
  rect(boxX, boxY, boxWidth, boxHeight, 10);

  // Reset stroke for text
  noStroke();

  // Draw text shadow
  textSize(30); // Text size
  textAlign(CENTER, CENTER); // Center alignment
  fill(0, 0, 0, 100); // Semi-transparent black
  text("Wrong Pocket! Try again.", width / 2 + 2, height / 2 - 82);

  // Draw main text
  fill(255, 0, 0); // Red text
  text("Wrong Pocket! Try again.", width / 2, height / 2 - 80);

  pop(); // Restore styles

  // Hide message after the specified display time
  if (millis() - wrongPocketTimer > wrongPocketDisplayTime) {
    showWrongPocketMessage = false;
  }
}


// displayResetFailureMessage(resetFailureCount, resetFailureTimer, resetFailureDisplayTime, width, height)
// Displays a red error message if a ball fails to reset
function displayResetFailureMessage(resetFailureCount, resetFailureTimer, resetFailureDisplayTime, width, height) {
  push(); // Save current styles
  fill(255, 0, 0); // Red text color
  textSize(20); // Set text size
  textAlign(CENTER, CENTER); // Center text alignment
  text(
    `Failed to reset ${resetFailureCount} ball. Please check positions.`,
    width / 2,
    height / 2
  ); // Display failure message
  pop(); // Restore styles

  // Hide message after the specified display time
  if (millis() - resetFailureTimer > resetFailureDisplayTime) {
    showResetFailureMessage = false;
  }
}
