// drawBalls()
// Draws all the balls on the table, including highlights and labels
function drawBalls() {
  push(); // Save current styles

  // Draw non-cue balls
  balls.forEach((ball) => {
    if (ball.label === "cueBall") return; // Skip cue ball
    const ballX = ball.position.x;
    const ballY = ball.position.y;
    const radius = ballDiameter / 2;

    fill(ball.color || "red"); // Use the ball's color or default to red
    noStroke();
    ellipse(ballX, ballY, ballDiameter); // Draw the ball

    // Add a highlight for a shiny effect
    fill(255, 255, 255, 150);
    ellipse(ballX - radius / 3, ballY - radius / 3, radius / 2, radius / 2);
  });

  // Draw the cue ball separately
  if (!placingCueBall && cueBall) {
    const cueBallX = cueBall.position.x;
    const cueBallY = cueBall.position.y;
    const radius = ballDiameter / 2;

    fill(255); // White for cue ball
    noStroke();
    ellipse(cueBallX, cueBallY, ballDiameter); // Draw the cue ball

    // Cue ball highlight for shiny effect
    fill(255, 255, 255, 150);
    ellipse(cueBallX - radius / 3, cueBallY - radius / 3, radius / 2, radius / 2);

    // Optional "C" label on the cue ball
    fill(0); // Black text
    textSize(10);
    textAlign(CENTER, CENTER);
    text("C", cueBallX, cueBallY);
  }

  pop(); // Restore styles
}

  // setupBalls(mode)
// Sets up balls on the table based on the selected game mode
function setupBalls(mode) {
  // Remove existing balls from the world
  balls.forEach((ball) => {
    World.remove(world, ball);
  });
  balls = []; // Clear the balls array

  let centerX = width / 2;
  let centerY = height / 2;

  let leftBoundary = (width - tableWidth) / 2 + edgeOffset / 2;
  let rightBoundary = (width + tableWidth) / 2 - edgeOffset / 2;
  let topBoundary = (height - tableHeight) / 2 + edgeOffset / 2;
  let bottomBoundary = (height + tableHeight) / 2 - edgeOffset / 2;

  if (mode === 1) {
      // Triangular arrangement of reds + colored balls
      let redStartX = centerX + tableWidth / 6;
      let redStartY = centerY;
      let rows = 5;

      // Arrange red balls in a triangle
      for (let row = 0; row < rows; row++) {
          for (let col = 0; col <= row; col++) {
              let x = redStartX + row * ballDiameter * 0.87;
              let y = redStartY - (row * ballDiameter) / 2 + col * ballDiameter;
              addBall(x, y, "red");
          }
      }
      addColoredBalls(centerX, centerY); // Add colored balls
  } else if (mode === 2) {
      // Random reds + standard colored balls in fixed positions
      addColoredBalls(centerX, centerY);
      for (let i = 0; i < 15; i++) {
          let x, y;
          do {
              x = random(leftBoundary, rightBoundary);
              y = random(topBoundary, bottomBoundary);
          } while (!isInsidePlayableArea(x, y) || isOverlappingPocket(x, y));
          addBall(x, y, "red");
      }
  } else if (mode === 3) {
      // Randomly place everything
      for (let i = 0; i < 15; i++) {
          let x, y;
          do {
              x = random(leftBoundary, rightBoundary);
              y = random(topBoundary, bottomBoundary);
          } while (!isInsidePlayableArea(x, y) || isOverlappingPocket(x, y));
          addBall(x, y, "red");
      }
      const colorLabels = ["yellow", "green", "brown", "blue", "pink", "black"];
      colorLabels.forEach((color) => {
          let x, y;
          do {
              x = random(leftBoundary, rightBoundary);
              y = random(topBoundary, bottomBoundary);
          } while (!isInsidePlayableArea(x, y) || isOverlappingPocket(x, y));
          addBall(x, y, color);
      });
  } else if (mode === 4) {
      // MazeRunner mode: no additional balls
      return;
  } else if (mode === 0) {
      // No balls placed for mode 0
      console.log("Waiting for user to select mode 1-4...");
  }
}

  

// isOverlappingPocket(x, y)
// Checks if the given position overlaps with any pocket
function isOverlappingPocket(x, y) {
  return pockets.some((pocket) => {
    let dx = x - pocket.x;
    let dy = y - pocket.y;
    let distance = Math.sqrt(dx * dx + dy * dy);
    return distance < pocket.radius + ballDiameter / 2; // Overlaps if within pocket radius + ball radius
  });
}

// isInsidePlayableArea(x, y)
// Checks if the given position is within the playable area of the table
function isInsidePlayableArea(x, y) {
  let leftBoundary = (width - tableWidth) / 2 + edgeOffset / 2;
  let rightBoundary = (width + tableWidth) / 2 - edgeOffset / 2;
  let topBoundary = (height - tableHeight) / 2 + edgeOffset / 2;
  let bottomBoundary = (height + tableHeight) / 2 - edgeOffset / 2;
  return x >= leftBoundary && x <= rightBoundary && y >= topBoundary && y <= bottomBoundary;
}

// addColoredBalls(centerX, centerY)
// Adds colored balls to the table at predefined positions
function addColoredBalls(centerX, centerY) {
  const colorPositions = [
    { x: centerX, y: centerY, color: "blue" }, // Center blue ball
    { x: (width - tableWidth) / 2 + tableWidth / 4, y: centerY, color: "brown" }, // Left brown ball
    { x: centerX + tableWidth / 8, y: centerY, color: "pink" }, // Slightly right pink ball
    { x: centerX + tableWidth / 3, y: centerY, color: "black" }, // Far right black ball
    {
      x: (width - tableWidth) / 2 + tableWidth / 4,
      y: centerY - tableWidth / 12,
      color: "green", // Upper left green ball
    },
    {
      x: (width - tableWidth) / 2 + tableWidth / 4,
      y: centerY + tableWidth / 12,
      color: "yellow", // Lower left yellow ball
    },
  ];
  // Add each ball using its position and color
  colorPositions.forEach((pos) => addBall(pos.x, pos.y, pos.color));
}

// addBall(x, y, color)
// Adds a new ball to the game at the specified position with the given color
function addBall(x, y, color) {
  const ball = Bodies.circle(x, y, ballDiameter / 2, {
    restitution: 0.9, // Bounciness of the ball
    friction: 0.005, // Low friction for smooth movement
    label: "ball", // Identify as a ball
  });
  ball.color = color; // Assign color to the ball
  ball.originalPosition = { x: x, y: y }; // Store its original position
  balls.push(ball); // Add the ball to the balls array
  World.add(world, ball); // Add the ball to the physics world
}

  
// checkPocketedBalls()
// Checks if balls are pocketed, handles their removal or resetting, and manages game logic
function checkPocketedBalls() {
  let pottedBalls = [];

  // Check each ball for pocketing
  balls.forEach((ball) => {
    if (!ball.isPotted) {
      let pocketed = pockets.some((pocket) => {
        let dx = ball.position.x - pocket.x;
        let dy = ball.position.y - pocket.y;
        let distance = Math.sqrt(dx * dx + dy * dy);
        return distance < pocket.radius;
      });

      if (pocketed) {
        pottedBalls.push(ball); // Add to potted list
        ball.isPotted = true; // Mark as potted
      }
    }
  });

  // Handle potted balls
  if (pottedBalls.length > 0) {
    pottedBalls.forEach((ball) => {
      if (currentMode === 4) {
        // MazeRunner: Only track the cue ball
      } else {
        // Normal modes
        if (ball.color !== "red") {
          // Handle colored balls
          coloredPottedCount += 1;
          if (coloredPottedCount >= 2) {
            displayConsecutiveColoredPottedBallsMessage();
            coloredPottedCount = 0;
          }
          // Reset colored ball after delay
          setTimeout(() => {
            if (canResetBall(ball)) {
              resetBallToOriginalPosition(ball);
            } else {
              console.log(`Cannot reset Ball ${ball.color} due to overlapping. Retrying...`);
              setTimeout(() => {
                if (canResetBall(ball)) {
                  resetBallToOriginalPosition(ball);
                } else {
                  console.log(`Failed to reset Ball ${ball.color}. Please check ball positions.`);
                  displayResetFailureMessage(ball.color);
                }
              }, 500);
            }
          }, 500);
        } else {
          // Remove red balls permanently
          World.remove(world, ball);
          let index = balls.indexOf(ball);
          if (index > -1) balls.splice(index, 1);
          console.log(`Red ball potted and removed from the table.`);
        }
      }
    });
  }

  // Handle the cue ball specifically
  if (cueBall && !placingCueBall) {
    let cuePocketed = pockets.some((pocket) => {
      let dx = cueBall.position.x - pocket.x;
      let dy = cueBall.position.y - pocket.y;
      let distance = Math.sqrt(dx * dx + dy * dy);
      return distance < pocket.radius;
    });

    if (cuePocketed) {
      if (currentMode === 4) {
        // MazeRunner: Check if potted into the target pocket
        let dxTarget = cueBall.position.x - targetPocket.x;
        let dyTarget = cueBall.position.y - targetPocket.y;
        let distTarget = Math.sqrt(dxTarget * dxTarget + dyTarget * dyTarget);

        if (distTarget < targetPocket.radius) {
          console.log("Cue ball potted into the correct pocket! Mode Complete!");
          isModeComplete = true; // Mark mode as complete
          World.remove(world, cueBall);
          cueBall = null;
          cue = null;
        } else {
          // Wrong pocket in MazeRunner
          console.log("Wrong pocket. You must pot the ball in the halo pocket!");
          showWrongPocketMessage = true;
          wrongPocketTimer = millis();
          World.remove(world, cueBall);
          cueBall = null;
          cue = null;
          placingCueBall = true; // Force user to place a new cue ball
        }
      } else {
        // Normal mode: Cue ball scratched
        placingCueBall = true;
        World.remove(world, cueBall);
        cueBall = null;
        cue = null;
        console.log("Cue ball scratched. Please place it in the D Zone.");
      }
    }
  }
}



// resetBallToOriginalPosition(ball)
// Resets the ball to its original position and clears its motion
function resetBallToOriginalPosition(ball) {
  Matter.Body.setPosition(ball, { x: ball.originalPosition.x, y: ball.originalPosition.y }); // Reset position
  Matter.Body.setVelocity(ball, { x: 0, y: 0 }); // Stop any movement
  Matter.Body.setAngularVelocity(ball, 0); // Stop rotation
  Matter.Body.setAngle(ball, 0); // Reset angle
  ball.isPotted = false; // Mark the ball as not potted
  console.log(`Ball ${ball.color} potted and returned to original position.`); // Log the reset
}
