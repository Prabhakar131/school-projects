// confinePointToD(x, y)
// Confines a point to the semicircle D zone
function confinePointToD(x, y) {
  // Calculate the distance of the point from the center of the D zone
  let dx = x - dCenterX;
  let dy = y - dCenterY;
  let distance = Math.sqrt(dx * dx + dy * dy);

  // Adjust radius to account for the ball's diameter
  let adjustedRadius = dZoneRadius - ballDiameter / 2;

  // If the point is outside the semicircle, confine it to the edge
  if (distance > adjustedRadius) {
    let angle = Math.atan2(dy, dx);
    x = dCenterX + adjustedRadius * Math.cos(angle);
    y = dCenterY + adjustedRadius * Math.sin(angle);
  }

  // Ensure the point remains within the left-open side of the D zone
  if (x > dCenterX) {
    dx = x - dCenterX;
    dy = y - dCenterY;
    let angle = Math.atan2(dy, dx);

    // Constrain the point to the semicircle boundary
    x = dCenterX + adjustedRadius * Math.cos(angle);
    y = dCenterY + adjustedRadius * Math.sin(angle);

    // If x still exceeds the center, set it to dCenterX
    if (x > dCenterX) {
      x = dCenterX;
    }
  }

  // Return the confined point coordinates
  return { x, y };
}

// isWithinD(x, y)
// Checks if a point is within the semicircle D zone
function isWithinD(x, y) {
  // Calculate the squared distance from the point to the center of the D zone
  let dx = x - dCenterX;
  let dy = y - dCenterY;
  let distanceSquared = dx * dx + dy * dy;

  // Adjust radius to account for the ball's diameter
  let adjustedRadius = dZoneRadius - ballDiameter / 2;

  // Return true if the point is within the radius and on the left side of the center
  return distanceSquared <= adjustedRadius * adjustedRadius && x <= dCenterX;
}

// drawGhostCueBall(x, y)
// Draws a translucent "ghost" cue ball at the given coordinates
function drawGhostCueBall(x, y) {
  push(); // Save current drawing style
  fill(255, 255, 255, 150); // Set translucent white fill color
  noStroke(); // Remove stroke around the ellipse
  ellipse(x, y, ballDiameter); // Draw the ghost ball
  pop(); // Restore previous drawing style
}
// debugBallAndPocketSizes()
// Logs ball diameter and pocket sizes for debugging
function debugBallAndPocketSizes() {
  console.log("---- Debugging Ball and Pocket Sizes ----");
  console.log(`Ball Diameter: ${ballDiameter}`); // Log ball diameter
  pockets.forEach((pocket, index) => {
    let pDiam = pocket.radius * 2;
    console.log(`Pocket ${index + 1} Diameter: ${pDiam}`); // Log each pocket diameter
  });
  console.log("----------------------------------------");
}
