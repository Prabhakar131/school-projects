// keyPressed()
function keyPressed() {
  // Hide instructions when ENTER is pressed
  if (keyCode === ENTER) {
      showInstructions = false;
  }

  // Toggle control mode between 'keyboard' and 'mouse' when 'T' or 't' is pressed
  if (key === "T" || key === "t") {
      if (controlMode === "keyboard") {
          controlMode = "mouse";
      } else {
          controlMode = "keyboard";
      }
      console.log("Switched to " + controlMode + " control");
  }

  // Handle keyboard cue stick controls if in 'keyboard' mode
  if (controlMode === "keyboard") {
      if (keyCode === LEFT_ARROW) {
          cueDirection -= 0.1;
      } else if (keyCode === RIGHT_ARROW) {
          cueDirection += 0.1;
      } else if (keyCode === UP_ARROW) {
          cueForce = min(cueForce + 0.01, 0.06);
      } else if (keyCode === DOWN_ARROW) {
          cueForce = max(cueForce - 0.005, 0.005);
      } else if (key === " " && cueState === "rest" && !isCueBallInMotion) {
          cueState = "pullingBack";
      }
  }

  // Function to remove all maze walls from the world and clear the mazeWalls array
  function removeMazeWalls() {
      mazeWalls.forEach((wall) => World.remove(world, wall));
      mazeWalls = [];
      console.log("Maze walls removed.");
      console.log(`Current mazeWalls count: ${mazeWalls.length}`); // Should be 0
  }

  // Handle resetting after Mode Complete
  if (isModeComplete && (key === 'R' || key === 'r' || key === 'Enter')) {
      resetModeComplete();
  }

  // ----------------- SWITCH MODES -----------------
  // Handle mode switching based on keys "0" to "4"
  if (key === "0" || key === "1" || key === "2" || key === "3" || key === "4") {
      let selectedMode = parseInt(key); // Convert key to integer

      // Update currentMode to the selected mode
      currentMode = selectedMode;

      // Setup balls based on the selected mode
      setupBalls(selectedMode);

      // Reset the cue stick's state
      resetCueStick();

      // Reset the cue ball and prompt for manual placement
      resetCueBallPosition();

      // Remove existing maze walls to prevent residual collisions
      removeMazeWalls();

      // Additional setup for specific modes
      if (selectedMode >= 1 && selectedMode <= 3) {
          // For Modes 1-3, ensure the cue exists
          if (!cue) {
              cue = createCue();
          }
          console.log(`Switched to Mode ${selectedMode}`);
      } else if (selectedMode === 4) {
          // For Mode 4: MazeRunner Mode
          // Remove all 'ball' bodies except the cue ball from the world
          let bodiesToRemove = world.bodies.filter(
              (body) => body.label === "ball" && body !== cueBall
          );
          bodiesToRemove.forEach((ball) => {
              World.remove(world, ball);
              let index = balls.indexOf(ball);
              if (index > -1) {
                  balls.splice(index, 1);
              }
          });

          // Clear the balls array entirely (so cue ball is NOT in balls[])
          balls = [];

          // Choose a random target pocket each time Mode 4 is selected
          if (pockets.length > 0) {
              targetPocket = random(pockets); // Select a random pocket
              console.log(`Target Pocket assigned at (${targetPocket.x}, ${targetPocket.y})`);

              // Generate Maze Walls
              generateMazeWalls();

              console.log("Switched to Mode 4: MazeRunner");
          } else {
              console.error("Cannot switch to Mode 4: No pockets defined.");
          }
      } else if (selectedMode === 0) {
          // For Mode 0: Initial or Special Mode
          // Ensure that if Mode 0 has specific behavior, handle it here
          // For now, treat it similarly to other modes by prompting manual placement
          console.log("Switched to Mode 0");
      }
  }
}

// mouseMoved(event)
function mouseMoved(event) {
    if (controlMode === "mouse") {
      mousePosition.x = event.clientX;
      mousePosition.y = event.clientY;
    }
  }
  
// mousePressed()

function mousePressed() {
    if (placingCueBall) {
      // If placing the cue ball, on mouse press we confirm the placement
      let confinedPos = confinePointToD(mouseX, mouseY);
      placeCueBallAt(confinedPos.x, confinedPos.y);
    } else if (controlMode === "mouse" && !isCueBallInMotion && cueState === "rest") {
      // In mouse mode, clicking initiates pulling back
      cueState = "pullingBack";
    } else if (controlMode === "keyboard" && !isCueBallInMotion && cueState === "rest") {
      // In keyboard mode, handle pulling back
      isMousePressed = true;
      cueState = "pullingBack";
    }
  }
  
// mouseReleased()
function mouseReleased() {
    if (controlMode === "mouse" && cueState === "rest" && !placingCueBall) {
      isMousePressed = false; // Release mouse to shoot
    }
  }
// mouseWheel(event)

function mouseWheel(event) {
    if (controlMode === "mouse") {
      // Adjust cueForce
      if (event.delta > 0) {
        // Scrolled down => decrease
        cueForce = Math.max(cueForce - 0.005, 0.005);
      } else {
        // Scrolled up => increase
        cueForce = Math.min(cueForce + 0.005, 0.06);
      }
      console.log(`Cue Force: ${(cueForce * 100).toFixed(1)}%`);
      return false;
    }
  }
  

// handleCollision(event)
// Handles collisions involving the cue ball and logs the interactions
function handleCollision(event) {
  event.pairs.forEach((pair) => {
    const { bodyA, bodyB } = pair;

    let otherBody = null;
    if (bodyA.label === "cueBall") {
      otherBody = bodyB; // Identify the other body in collision
    } else if (bodyB.label === "cueBall") {
      otherBody = bodyA; // Identify the other body in collision
    } else {
      return; // Skip if cue ball is not involved
    }

    // Check collision type and log accordingly
    if (otherBody.label === "cushion") {
      console.log("cue-cushion");
    } else if (otherBody.label === "ball") {
      if (otherBody.color === "red") {
        console.log("cue-red");
      } else {
        console.log("cue-colour");
      }
    }
  });
}
