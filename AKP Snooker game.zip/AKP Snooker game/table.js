// createTable()
// Creates the table edges and adds them to the world
function createTable() {
  let edgeOptions = { isStatic: true, restitution: 1 }; // Static edges with full restitution
  let outerEdgeOffset = edgeOffset * 1.5; // Offset for outer edges
  const segments = 2; // Number of segments for top and bottom edges
  const segmentWidth = (tableWidth + outerEdgeOffset) / segments; // Width of each segment

  tableEdges = [
    // Top Edge (split into 2 segments)
    Bodies.rectangle(
      width / 2 - segmentWidth / 2,
      (height - tableHeight) / 2 - outerEdgeOffset / 2,
      segmentWidth,
      edgeOffset,
      edgeOptions
    ),
    Bodies.rectangle(
      width / 2 + segmentWidth / 2,
      (height - tableHeight) / 2 - outerEdgeOffset / 2,
      segmentWidth,
      edgeOffset,
      edgeOptions
    ),
    // Bottom Edge (split into 2 segments)
    Bodies.rectangle(
      width / 2 - segmentWidth / 2,
      (height + tableHeight) / 2 + outerEdgeOffset / 2,
      segmentWidth,
      edgeOffset,
      edgeOptions
    ),
    Bodies.rectangle(
      width / 2 + segmentWidth / 2,
      (height + tableHeight) / 2 + outerEdgeOffset / 2,
      segmentWidth,
      edgeOffset,
      edgeOptions
    ),
    // Left Edge
    Bodies.rectangle(
      (width - tableWidth) / 2 - outerEdgeOffset / 2,
      height / 2,
      edgeOffset,
      tableHeight + outerEdgeOffset,
      edgeOptions
    ),
    // Right Edge
    Bodies.rectangle(
      (width + tableWidth) / 2 + outerEdgeOffset / 2,
      height / 2,
      edgeOffset,
      tableHeight + outerEdgeOffset,
      edgeOptions
    ),
  ];

  // Add edges to the world
  tableEdges.forEach((edge) => {
    World.add(world, edge);
  });
}

  
// createCushions()
// Creates and adds cushions to the table for collision and bounce
function createCushions() {
  const cushionOptions = {
    isStatic: true, // Cushions are fixed
    restitution: 1.2, // Bounciness
    friction: 0.02, // Low friction
    label: "cushion", // Identifier for debugging
  };

  // Table boundaries and cushion dimensions
  var tableLeft = (width - tableWidth) / 2;
  var tableRight = (width + tableWidth) / 2;
  var tableTop = (height - tableHeight) / 2;
  var tableBottom = (height + tableHeight) / 2;
  var cushionThickness = edgeOffset / 3;
  var cornerRadius = 60;
  var cushionShift = 225;

  // Dimensions for extended and side cushions
  var extendedLengthBase = cornerRadius * 9;
  var extendedLengthTop = cornerRadius * 8;
  var sideCushionLengthBase = cornerRadius * 9;
  var sideCushionLengthTop = cornerRadius * 8;

  // Creates a trapezoidal cushion based on parameters
  function createTrapezoidalCushion(
    x, y, widthBase, widthTop, height, vertical, flip
  ) {
    let vertices;
    if (vertical) {
      vertices = flip
        ? [
            { x: x, y: y - widthBase / 2 },
            { x: x - height, y: y - widthTop / 2 },
            { x: x - height, y: y + widthTop / 2 },
            { x: x, y: y + widthBase / 2 },
          ]
        : [
            { x: x, y: y - widthBase / 2 },
            { x: x + height, y: y - widthTop / 2 },
            { x: x + height, y: y + widthTop / 2 },
            { x: x, y: y + widthBase / 2 },
          ];
    } else {
      vertices = [
        { x: x - widthBase / 2, y: y },
        { x: x + widthBase / 2, y: y },
        { x: x + widthTop / 2, y: y + height },
        { x: x - widthTop / 2, y: y + height },
      ];
    }
    return Bodies.fromVertices(x, y, [vertices], cushionOptions, true);
  }

  // Create individual cushions
  const topLeftCushion = createTrapezoidalCushion(
    tableLeft + cornerRadius + cushionShift, tableTop + 8,
    extendedLengthBase, extendedLengthTop, cushionThickness, false, false
  );

  const topRightCushion = createTrapezoidalCushion(
    tableRight - cornerRadius - cushionShift, tableTop + 8,
    extendedLengthBase, extendedLengthTop, cushionThickness, false, false
  );

  const bottomLeftCushion = createTrapezoidalCushion(
    tableLeft + cornerRadius + cushionShift, tableBottom - 8,
    extendedLengthTop, extendedLengthBase, cushionThickness, false, false
  );

  const bottomRightCushion = createTrapezoidalCushion(
    tableRight - cornerRadius - cushionShift, tableBottom - 8,
    extendedLengthTop, extendedLengthBase, cushionThickness, false, false
  );

  const leftCushion = createTrapezoidalCushion(
    tableLeft + 8, height / 2,
    sideCushionLengthBase, sideCushionLengthTop, cushionThickness, true, false
  );

  const rightCushion = createTrapezoidalCushion(
    tableRight - 8, height / 2,
    sideCushionLengthBase, sideCushionLengthTop, cushionThickness, true, true
  );

  // Collect and add all cushions to the world
  const allCushions = [
    topLeftCushion, topRightCushion, bottomLeftCushion,
    bottomRightCushion, leftCushion, rightCushion,
  ];

  allCushions.forEach(function (cushion) {
    if (cushion) {
      World.add(world, cushion);
      cushions.push(cushion);
    }
  });
}
// createPockets()
// Creates and defines the positions and sizes of the table pockets
function createPockets() {
  let pocketOffset = pocketDiameter / 4; // Offset to adjust pocket positions
  let pocketPositions = [
    {
      x: (width - tableWidth) / 2 + pocketOffset,
      y: (height - tableHeight) / 2 + pocketOffset,
    }, // Top-left
    {
      x: (width + tableWidth) / 2 - pocketOffset,
      y: (height - tableHeight) / 2 + pocketOffset,
    }, // Top-right
    {
      x: (width - tableWidth) / 2 + pocketOffset,
      y: (height + tableHeight) / 2 - pocketOffset,
    }, // Bottom-left
    {
      x: (width + tableWidth) / 2 - pocketOffset,
      y: (height + tableHeight) / 2 - pocketOffset,
    }, // Bottom-right
    {
      x: width / 2,
      y: (height - tableHeight) / 2 + pocketOffset / 2,
    }, // Top-center
    {
      x: width / 2,
      y: (height + tableHeight) / 2 - pocketOffset / 2,
    }, // Bottom-center
  ];

  // Add each pocket to the pockets array
  pocketPositions.forEach((pos) => {
    pockets.push({
      x: pos.x,
      y: pos.y,
      radius: pocketDiameter / 2,
    });
  });
}

// drawTable()
// Draws the table's outer edge and inner surface
function drawTable() {
  push(); // Save current styles
  // Draw outer brown edge
  fill(60, 30, 15); // Brown color
  noStroke(); // No border
  rectMode(CENTER);
  let outerCornerRadius = 50; // Rounded corners
  let borderThickness = edgeOffset * 0.5; // Edge border thickness
  rect(
    width / 2,
    height / 2,
    tableWidth + borderThickness * 2,
    tableHeight + borderThickness * 2,
    outerCornerRadius
  );

  // Draw inner green surface
  fill(0, 102, 0); // Green color
  let innerCornerRadius = 30; // Rounded corners
  rect(width / 2, height / 2, tableWidth, tableHeight, innerCornerRadius);
  pop(); // Restore styles
}

  
// drawDZone()
// Draws the D zone arc and vertical line
function drawDZone() {
  push(); // Save current styles
  noFill(); // No fill for the arc
  stroke(255); // White stroke
  strokeWeight(1); // Thin stroke

  // Draw the D zone arc
  arc(
    (width - tableWidth) / 2 + tableWidth / 4,
    height / 2,
    tableWidth / 6,
    tableWidth / 6,
    HALF_PI,
    -HALF_PI
  );

  // Draw the vertical line in the D zone
  let lineLength = tableHeight - 30;
  line(
    (width - tableWidth) / 2 + tableWidth / 4,
    height / 2 - lineLength / 2,
    (width - tableWidth) / 2 + tableWidth / 4,
    height / 2 + lineLength / 2
  );
  pop(); // Restore styles
}

// drawCushions()
// Draws the cushions as filled polygons
function drawCushions() {
  push(); // Save current styles
  fill(0, 0, 0, 150); // Semi-transparent black fill
  noStroke(); // No border

  // Draw each cushion as a closed shape
  cushions.forEach((cushion) => {
    beginShape();
    cushion.vertices.forEach((point) => {
      vertex(point.x, point.y); // Define the vertices
    });
    endShape(CLOSE); // Close the shape
  });
  pop(); // Restore styles
}

// drawPockets()
// Draws the pockets on the table
function drawPockets() {
  push(); // Save current styles
  pockets.forEach((pocket) => {
    fill(0); // Black fill for pockets
    stroke(255, 215, 0); // Gold stroke
    strokeWeight(3); // Stroke thickness
    ellipse(pocket.x, pocket.y, pocket.radius * 2); // Draw pocket
  });
  pop(); // Restore styles
}

