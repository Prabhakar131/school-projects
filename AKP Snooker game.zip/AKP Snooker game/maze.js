// generateMaze()
// Generates a random maze using a depth-first search algorithm
function generateMaze() {
  // Initialize the maze with walls and unvisited cells
  maze = [];
  for (let i = 0; i < rows; i++) {
    maze[i] = [];
    for (let j = 0; j < cols; j++) {
      maze[i][j] = {
        top: true,    // Top wall exists
        right: true,  // Right wall exists
        bottom: true, // Bottom wall exists
        left: true,   // Left wall exists
        visited: false, // Cell is unvisited
      };
    }
  }

  // Get unvisited neighbors of a cell
  function getUnvisitedNeighbors(cell) {
    let neighbors = [];
    let { i, j } = cell;

    if (i > 0 && !maze[i - 1][j].visited) neighbors.push({ i: i - 1, j: j, direction: "top" });
    if (j < cols - 1 && !maze[i][j + 1].visited) neighbors.push({ i: i, j: j + 1, direction: "right" });
    if (i < rows - 1 && !maze[i + 1][j].visited) neighbors.push({ i: i + 1, j: j, direction: "bottom" });
    if (j > 0 && !maze[i][j - 1].visited) neighbors.push({ i: i, j: j - 1, direction: "left" });

    return neighbors;
  }

  // Start generating the maze from a random cell
  let stack = [];
  let currentCell = { i: floor(random(rows)), j: floor(random(cols)) };
  maze[currentCell.i][currentCell.j].visited = true;
  stack.push(currentCell);

  // Perform depth-first search
  while (stack.length > 0) {
    let cell = stack[stack.length - 1]; // Current cell
    let neighbors = getUnvisitedNeighbors(cell);

    if (neighbors.length > 0) {
      let next = random(neighbors); // Choose a random neighbor
      let { i: ni, j: nj, direction } = next;

      // Remove walls between the current cell and the chosen neighbor
      if (direction === "top") {
        maze[cell.i][cell.j].top = false;
        maze[ni][nj].bottom = false;
      } else if (direction === "right") {
        maze[cell.i][cell.j].right = false;
        maze[ni][nj].left = false;
      } else if (direction === "bottom") {
        maze[cell.i][cell.j].bottom = false;
        maze[ni][nj].top = false;
      } else if (direction === "left") {
        maze[cell.i][cell.j].left = false;
        maze[ni][nj].right = false;
      }

      // Mark the neighbor as visited and push it onto the stack
      maze[ni][nj].visited = true;
      stack.push({ i: ni, j: nj });
    } else {
      stack.pop(); // Backtrack if no unvisited neighbors
    }
  }

  // Reset the visited flags for all cells
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      maze[i][j].visited = false;
    }
  }
}

// dynamicRearrangeMazeWalls()
// Randomly toggles maze walls and updates the maze dynamically
function dynamicRearrangeMazeWalls() {
  // Randomly modify walls in the maze
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      if (random() < 0.01) { // 1% chance to toggle a wall
        let walls = ["top", "right", "bottom", "left"];
        let randomWall = walls[floor(random(walls.length))];
        maze[i][j][randomWall] = !maze[i][j][randomWall]; // Toggle wall state

        // Find and remove the existing wall from the physics world
        let existingWall = mazeWalls.find((wall) => {
          return (
            (randomWall === "top" &&
              Math.abs(wall.position.x - (j * cellSize + cellSize / 2) - (width - cols * cellSize) / 2) < 1 &&
              Math.abs(wall.position.y - (i * cellSize) - (height - rows * cellSize) / 2) < 1) ||
            (randomWall === "right" &&
              Math.abs(wall.position.x - (j * cellSize + cellSize) - (width - cols * cellSize) / 2) < 1 &&
              Math.abs(wall.position.y - (i * cellSize + cellSize / 2) - (height - rows * cellSize) / 2) < 1) ||
            (randomWall === "bottom" &&
              Math.abs(wall.position.x - (j * cellSize + cellSize / 2) - (width - cols * cellSize) / 2) < 1 &&
              Math.abs(wall.position.y - (i * cellSize + cellSize) - (height - rows * cellSize) / 2) < 1) ||
            (randomWall === "left" &&
              Math.abs(wall.position.x - (j * cellSize) - (width - cols * cellSize) / 2) < 1 &&
              Math.abs(wall.position.y - (i * cellSize + cellSize / 2) - (height - rows * cellSize) / 2) < 1)
          );
        });

        if (existingWall) {
          World.remove(world, existingWall); // Remove wall from physics world
          mazeWalls = mazeWalls.filter((w) => w !== existingWall); // Remove from wall list
        }

        // Add a new wall if toggled back on
        if (maze[i][j][randomWall]) {
          let x = j * cellSize + (width - cols * cellSize) / 2;
          let y = i * cellSize + (height - rows * cellSize) / 2;

          let newWall;
          if (randomWall === "top") {
            newWall = Bodies.rectangle(x + cellSize / 2, y, cellSize, wallThickness, wallOptions);
          } else if (randomWall === "right") {
            newWall = Bodies.rectangle(x + cellSize, y + cellSize / 2, wallThickness, cellSize, wallOptions);
          } else if (randomWall === "bottom") {
            newWall = Bodies.rectangle(x + cellSize / 2, y + cellSize, cellSize, wallThickness, wallOptions);
          } else if (randomWall === "left") {
            newWall = Bodies.rectangle(x, y + cellSize / 2, wallThickness, cellSize, wallOptions);
          }

          if (newWall) {
            mazeWalls.push(newWall); // Add new wall to the list
            World.add(world, newWall); // Add new wall to the physics world
          }
        }
      }
    }
  }

  // Ensure the maze is still solvable, regenerate if not
  if (!ensureMazeSolvable()) {
    generateMazeWalls(); // Fallback to regenerate maze walls
  }
}

// drawMazeWalls()
// Draws all the maze walls with a red color and slight transparency
function drawMazeWalls() {
  push(); // Save current styles
  fill(200, 0, 0); // Red fill for walls
  stroke(150, 0, 0, 150); // Darker red stroke with transparency
  strokeWeight(wallThickness / 2); // Stroke thickness

  mazeWalls.forEach((wall) => {
    push(); // Save styles for each wall
    translate(wall.position.x, wall.position.y); // Move to wall position
    rotate(wall.angle); // Rotate to wall orientation
    rectMode(CENTER); // Center the rectangle
    let widthWall = wall.bounds.max.x - wall.bounds.min.x; // Calculate wall width
    let heightWall = wall.bounds.max.y - wall.bounds.min.y; // Calculate wall height
    rect(0, 0, widthWall, heightWall); // Draw the wall
    pop(); // Restore styles for next wall
  });

  pop(); // Restore global styles
}

// drawHaloAroundPockets()
// Draws a glowing green halo around the target pocket
function drawHaloAroundPockets() {
  if (!targetPocket) {
    console.error("drawHaloAroundPockets: targetPocket is undefined.");
    return; // Exit if no target pocket is defined
  }
  push(); // Save current styles
  noFill(); // No fill for the halo
  stroke(0, 255, 0, 150); // Semi-transparent green stroke
  strokeWeight(5); // Set halo thickness
  ellipse(targetPocket.x, targetPocket.y, targetPocket.radius * 4); // Draw the halo
  pop(); // Restore styles
}

// ensureMazeSolvable()
// Checks if there is a path from the start to the target pocket in the maze
function ensureMazeSolvable() {
  if (!targetPocket) {
    console.error("ensureMazeSolvable: targetPocket is undefined.");
    return false; // Target pocket not defined
  }

  // Create a graph representation of the maze
  let graph = Array(rows)
    .fill(null)
    .map(() => Array(cols).fill(null).map(() => []));

  // Add connections between cells based on maze walls
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      if (!maze[i][j].top && i > 0) graph[i][j].push({ i: i - 1, j: j }); // Connect top
      if (!maze[i][j].right && j < cols - 1) graph[i][j].push({ i: i, j: j + 1 }); // Connect right
      if (!maze[i][j].bottom && i < rows - 1) graph[i][j].push({ i: i + 1, j: j }); // Connect bottom
      if (!maze[i][j].left && j > 0) graph[i][j].push({ i: i, j: j - 1 }); // Connect left
    }
  }

  // Define start and end points
  let start = { i: 0, j: 0 };
  let endJ = floor((targetPocket.x - (width - tableWidth) / 2) / cellSize);
  let endI = floor((targetPocket.y - (height - tableHeight) / 2) / cellSize);
  let end = {
    i: constrain(endI, 0, rows - 1),
    j: constrain(endJ, 0, cols - 1),
  };

  // Breadth-first search (BFS) to find a path
  let visited = Array(rows)
    .fill(null)
    .map(() => Array(cols).fill(false));
  let queue = [start];
  visited[start.i][start.j] = true;

  while (queue.length > 0) {
    let current = queue.shift();
    if (current.i === end.i && current.j === end.j) {
      return true; // Path found
    }
    graph[current.i][current.j].forEach((neighbor) => {
      if (!visited[neighbor.i][neighbor.j]) {
        visited[neighbor.i][neighbor.j] = true;
        queue.push(neighbor);
      }
    });
  }
  return false; // No path found
}

// generateMazeWalls()
// Generates maze walls and ensures they don't overlap with pockets or make the maze unsolvable
function generateMazeWalls() {
  let attempts = 0; // Track attempts to generate a solvable maze
  const maxAttempts = 10; // Maximum attempts allowed

  do {
    generateMaze(); // Generate maze structure

    // Remove existing maze walls
    mazeWalls.forEach((wall) => World.remove(world, wall));
    mazeWalls = [];

    // Build new walls based on the maze structure
    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        let x = j * cellSize + (width - cols * cellSize) / 2 + cellSize / 2;
        let y = i * cellSize + (height - rows * cellSize) / 2 + cellSize / 2;

        // Top wall
        if (maze[i][j].top) {
          let wall = Bodies.rectangle(x, y - cellSize / 2, cellSize, wallThickness, wallOptions);
          if (!wallOverlapsAnyPocket(wall)) {
            mazeWalls.push(wall);
            World.add(world, wall);
          }
        }

        // Right wall
        if (maze[i][j].right) {
          let wall = Bodies.rectangle(x + cellSize / 2, y, wallThickness, cellSize, wallOptions);
          if (!wallOverlapsAnyPocket(wall)) {
            mazeWalls.push(wall);
            World.add(world, wall);
          }
        }

        // Bottom wall
        if (maze[i][j].bottom) {
          let wall = Bodies.rectangle(x, y + cellSize / 2, cellSize, wallThickness, wallOptions);
          if (!wallOverlapsAnyPocket(wall)) {
            mazeWalls.push(wall);
            World.add(world, wall);
          }
        }

        // Left wall
        if (maze[i][j].left) {
          let wall = Bodies.rectangle(x - cellSize / 2, y, wallThickness, cellSize, wallOptions);
          if (!wallOverlapsAnyPocket(wall)) {
            mazeWalls.push(wall);
            World.add(world, wall);
          }
        }
      }
    }

    attempts += 1; // Increment attempt counter
    if (attempts > maxAttempts) {
      console.error("Failed to generate a solvable maze after multiple attempts.");
      break;
    }
  } while (!ensureMazeSolvable()); // Ensure the maze is solvable
}

// Helper function to check overlap
function wallOverlapsAnyPocket(wallBody) {
  let wallBounds = wallBody.bounds;
  let wallCenter = wallBody.position;

  // A quick check: see if any pocket’s center is within some threshold
  // from the wall’s bounding box.
  for (let pocket of pockets) {
    // Quick bounding-box vs circle test:
    // 1) Find the closest point on the wall's bounding box to the pocket center
    let closestX = constrain(pocket.x, wallBounds.min.x, wallBounds.max.x);
    let closestY = constrain(pocket.y, wallBounds.min.y, wallBounds.max.y);
    
    // 2) Compute distance from that point to the pocket center
    let dx = pocket.x - closestX;
    let dy = pocket.y - closestY;
    let distanceSquared = dx * dx + dy * dy;

    // If distance < (pocketRadius + smallBuffer)^2 => overlap
    // You can tune the buffer to ensure no partial blocking
    let buffer = 5; 
    let maxAllowed = (pocket.radius + buffer) * (pocket.radius + buffer);
    if (distanceSquared < maxAllowed) {
      return true; // Overlaps => skip adding this wall
    }
  }
  return false;
}

function resetModeComplete() {
  console.log("Resetting MazeRunner Mode.");

  // Remove existing maze walls
  mazeWalls.forEach((wall) => {
      World.remove(world, wall);
      console.log("Removed a maze wall.");
  });
  mazeWalls = [];

  // Reset flags
  isModeComplete = false;
  showWrongPocketMessage = false;
  console.log("Flags reset.");

  // Reinitialize maze walls
  generateMazeWalls();
  resetCueBallPosition();

  // Reset other game variables as needed
  coloredPottedCount = 0;
  console.log("MazeRunner Mode has been reset.");
}
