// The FaceGame class orchestrates a mini driving game that uses
// face detection (to steer) and hand detection (to control gear/speed).
// It handles state transitions (start screen, gameplay, game over),
// spawning enemy vehicles, detecting collisions, and level progression.

class FaceGame {
  constructor(capture, detectedFaces, handposePredictions) {
    console.log("FaceGame constructor called.");

    // 'capture' is the video capture from the player's webcam.
    // 'detectedFaces' references global face detections updated by ml5 face API.
    // 'handposePredictions' references global hand landmarks from ml5 Handpose.

    // We'll track these to draw overlays on the live feed.
    this.capture = capture;
    this.detectedFaces = detectedFaces;
    this.handposePredictions = handposePredictions;

    // High-level game state flags.
    this.startScreen = true;     // Shows initial instructions until player starts.
    this.gameOver = false;       // Set to true upon collision.
    this.gameFinished = false;   // True if player reaches the end condition (score threshold).
    this.score = 0;             // Tracks how many enemies the player has passed.
    this.level = 1;             // Current difficulty level (1, 2, or 3).
    this.maxLevel = 3;          // Maximum possible level.
    this.levelOver = false;     // Flag used to detect when the level is completed.
    this.levelOverTimer = 0;    // Timer to manage transitions between levels.

    // Background scrolling properties.
    this.bgImage = loadImage("assets/road.png"); // A road image that scrolls vertically.
    this.bgY = 0;                                // Current vertical offset of the background.
    this.bgSpeed = 7;                            // Base speed for background scroll.

    // Protagonist's car properties (position, image, size, speed).
    // The 'protagonistImg' is assumed to have been loaded globally.
    this.protagonist = {
      x: width / 2,
      y: 530,
      image: protagonistImg,
      width: protagonistImg.width * 0.3,
      height: protagonistImg.height * 0.3,
      speed: 0
    };

    // All the enemy vehicles (their positions, velocities, images) go in this array.
    this.enemies = [];

    // Vehicle images for each level, loaded from assets.
    // Each key in 'vehicleImages' corresponds to a level number.
    this.vehicleImages = {
      1: [
        loadImage("assets/blueCar.png"),
        loadImage("assets/greenCar.png"),
        loadImage("assets/whiteCar.png")
      ],
      2: [
        loadImage("assets/white_pickup_truck.png"),
        loadImage("assets/yellow_pickup_truck.png")
      ],
      3: [
        loadImage("assets/blue_container_truck.png"),
        loadImage("assets/white_container_truck.png"),
        loadImage("assets/yellow_dump_truck.png")
      ]
    };

    // Gear control variables used for interpreting hand pose as gear selection.
    this.lastGear = 1;             // The gear we're currently using.
    this.pendingGear = null;       // Potential new gear we haven't confirmed yet.
    this.pendingGearCounter = 0;   // Counts frames to avoid gear flickers.
    this.gearDebounceThreshold = 10; // Wait time before finalizing a gear change.

    // Spawning logic for enemy vehicles.
    this.lastSpawnTime = 0;   // The last time we spawned a vehicle.
    this.spawnInterval = 1000; // We attempt to spawn a new vehicle every 1000 ms.

    // Reference to a restart button, which might appear on game over.
    this.restartButton = null;

    // Set initial protagonist position (redundant, but clarifies usage).
    this.protagonist.x = width / 2;
    this.protagonist.y = 530;
  }

  /*========================================
    Helper: Count Extended Fingers
  ========================================*/
  countExtendedFingers(hand) {
    // We count how many fingers are extended by looking at the hand landmark coordinates.
    // For the thumb, we compare x-coordinates differently for left vs. right hands.
    let landmarks = hand.landmarks;
    let count = 0;
    if (hand.handedness === "Right") {
      if (landmarks[4][0] > landmarks[3][0]) {
        count++;
      }
    } else {
      if (landmarks[4][0] < landmarks[3][0]) {
        count++;
      }
    }
    // For the other fingers, we check if the fingertip is above the PIP joint in y-coordinates.
    let fingertipIndices = [8, 12, 16, 20];
    let pipIndices = [6, 10, 14, 18];
    for (let i = 0; i < fingertipIndices.length; i++) {
      if (landmarks[fingertipIndices[i]][1] < landmarks[pipIndices[i]][1]) {
        count++;
      }
    }
    return count;
  }

  /*========================================
    Update Protagonist Position based on face
  ========================================*/
  updateProtagonistX(faceCenterX, panelX, panelW, rightW) {
    // The protagonist car's x-position is controlled by the player's face position (faceCenterX).
    // We map the face's x from the left panel to the region on the right where the car can move.
    if (faceCenterX !== null) {
      let margin = 20;
      let newXRelative = map(faceCenterX, panelX, panelX + panelW, margin, rightW - margin);
      let targetX = panelX + panelW + newXRelative;
      // Lerp for smoother movement instead of a direct jump.
      this.protagonist.x = lerp(this.protagonist.x, targetX, 0.9);
    }
  }

  /*========================================
    Update Gear based on hand pose
  ========================================*/
  updateGear() {
    // Gear is determined by how many fingers are extended (1-5).
    // We filter quick changes using a 'debounce' approach so that gear doesn't flicker.
    let gear = this.lastGear;
    if (handposePredictions && handposePredictions.length > 0) {
      let hand = handposePredictions[0];
      if (hand.landmarks && hand.landmarks.length >= 21) {
        let fingerCount = max(1, this.countExtendedFingers(hand));
        if (this.pendingGear === null || this.pendingGear !== fingerCount) {
          // If we detect a new gear different from the last one, reset counter.
          this.pendingGear = fingerCount;
          this.pendingGearCounter = 1;
        } else {
          // Continue counting frames with same gear guess.
          this.pendingGearCounter++;
          if (this.pendingGearCounter > this.gearDebounceThreshold) {
            // Confirm gear change if we see the same finger count for enough frames.
            gear = this.pendingGear;
            this.lastGear = gear;
            this.pendingGearCounter = 0;
            console.log("Gear changed to: " + gear);
          }
        }
      }
    }
    return gear;
  }

  /*========================================
    Main Face Game Mode Drawing
  ========================================*/
  drawFaceGameMode(x, y, w, h) {
    push();
    if (this.startScreen) {
      this.drawStartScreen(x, y, w, h);
      pop();
      return;
    }
    if (this.gameOver) {
      this.drawGameOverScreen(x, y, w, h);
      pop();
      return;
    }
    if (this.gameFinished) {
      this.drawGameFinishedScreen(x, y, w, h);
      pop();
      return;
    }

    // Split the space into a left panel (for face & hand overlays) and right panel (for game).
    let leftW = w * 0.6;
    let rightW = w - leftW;

    // Draw the left panel (camera feed + detection overlays).
    let faceCenterX = this.drawLeftPanel(x, y, leftW, h);
    // Update protagonist x-position based on face location.
    this.updateProtagonistX(faceCenterX, x, leftW, rightW);

    // Decide gear (speed multiplier) from hand pose.
    let gear = this.updateGear();
    this.protagonist.speed = gear * 2;

    // We'll use gear-based speed for background scrolling.
    let dynamicBgSpeed = this.protagonist.speed;

    // Actually draw the right side where the game action happens.
    let localProtagonistX = this.drawCarGameArea(x + leftW, y, rightW, h, dynamicBgSpeed);

    // Check collisions if we are still in gameplay.
    if (!this.gameOver) {
      this.checkCollisions(localProtagonistX, this.protagonist.y, this.protagonist.width, this.protagonist.height);
    }

    // Draw the on-screen HUD (score, gear, level).
    this.drawHUD();

    // Check if we've reached next level or finished condition.
    this.checkLevelUp();
    pop();
  }



  /*========================================
    Face Detection & Hand Overlay Methods
  ========================================*/
  drawLeftPanel(x, y, panelW, panelH) {
    // Draw a rectangle, then place the live camera feed inside.
    // We also overlay face detection boxes and hand keypoints.
    noFill();
    rect(x, y, panelW, panelH);
    let liveFrame = this.capture.get();
    image(liveFrame, x, y, panelW, panelH);
    let faceCenterX = this.drawFaceDetectionBoxAt(x, y, panelW, panelH);
    this.drawHandKeypoints(x, y, panelW, panelH);
    return faceCenterX;
  }

  // We use the global 'detectedFaces' for bounding box data from ml5 face API.
  drawFaceDetectionBoxAt(x, y, panelW, panelH) {
    let detections = detectedFaces;
    if (!detections || detections.length < 1) return null;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    let faceCenterX = null;
    let scaleX = panelW / this.capture.width;
    let scaleY = panelH / this.capture.height;
    // For each detected face, draw a rectangle at the scaled position.
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      if (face.alignedRect && face.alignedRect._box) {
        let box = face.alignedRect._box;
        let fx = x + box._x * scaleX;
        let fy = y + box._y * scaleY;
        let fw = box._width * scaleX;
        let fh = box._height * scaleY;
        rect(fx, fy, fw, fh);
        if (faceCenterX === null) {
          faceCenterX = fx + fw / 2;
        }
      }
    }
    pop();
    return faceCenterX;
  }

  // We also overlay hand landmarks from 'handposePredictions' to show the player's hand in real-time.
  drawHandKeypoints(x, y, panelW, panelH) {
    let scaleX = panelW / this.capture.width;
    let scaleY = panelH / this.capture.height;
    if (handposePredictions && handposePredictions.length > 0) {
      for (let hand of handposePredictions) {
        if (hand.landmarks) {
          for (let keypoint of hand.landmarks) {
            let hx = x + keypoint[0] * scaleX;
            let hy = y + keypoint[1] * scaleY;
            fill(255, 255, 0);
            noStroke();
            ellipse(hx, hy, 8, 8);
          }
        }
      }
    }
  }

  /*========================================
    Car Game Area & Vehicle Methods
  ========================================*/
  drawCarGameArea(x, y, areaW, areaH, dynamicBgSpeed) {
    // This region shows the scrolling background, the protagonist's car, and enemy vehicles.
    fill(200);
    rect(x, y, areaW, areaH);
    if (frameCount % 60 === 0) {
      console.log("60 frames have passed. Attempting to spawn vehicle.");
      // Potentially spawn a new vehicle once per second, depending on spawn logic.
      this.spawnVehicle(areaW);
    }
    let gameArea = createGraphics(areaW, areaH);
    gameArea.clear();
    gameArea.push();
    // Update background scroll position.
    this.bgY += dynamicBgSpeed;
    if (this.bgY > areaH) {
      this.bgY = 0;
    }

    // We draw the road image twice, so the second seamlessly follows the first as we scroll.
    let offsetX = -350;
    gameArea.image(this.bgImage, offsetX, this.bgY - areaH + 30, areaW * 4, areaH);
    gameArea.image(this.bgImage, offsetX, this.bgY, areaW * 4, areaH);

    // Draw the protagonist car in the 'gameArea' context.
    let localProtagonistX = this.protagonist.x - x;
    let localProtagonistY = this.protagonist.y - y;
    gameArea.image(
      this.protagonist.image,
      localProtagonistX,
      localProtagonistY,
      this.protagonist.width,
      this.protagonist.height
    );

    // Update and draw enemy vehicles in the same context.
    this.updateAndRenderVehicles(gameArea, areaW, areaH, 0);
    gameArea.pop();

    // We create a mask so the top portion (like a scoreboard area) is hidden.
    let maskGraphics = createGraphics(areaW, areaH);
    maskGraphics.background(0);
    maskGraphics.fill(255);
    maskGraphics.noStroke();
    maskGraphics.rect(0, 50, areaW, areaH - 50);

    let gameAreaImage = gameArea.get();
    // Mask out the top portion, so only the region below 50px is visible.
    gameAreaImage.mask(maskGraphics);
    // Finally, we place the masked 'gameAreaImage' onto the main canvas.
    image(gameAreaImage, x, y);

    // Return the protagonist's local x so we can check collisions.
    return localProtagonistX;
  }

  spawnVehicle(regionWidth) {
    console.log("Spawning new vehicle attempt. Current level: " + this.level);

    // Chooses a random image from the current level's vehicle images and spawns it offscreen.
    if (this.gameOver) return;
    let vehicleSet;
    if (this.level === 1) {
      vehicleSet = this.vehicleImages[1];
    } else if (this.level === 2) {
      vehicleSet = this.vehicleImages[2];
    } else if (this.level === 3) {
      vehicleSet = this.vehicleImages[3];
    }
    let vehicleImg = random(vehicleSet);
    if (!vehicleImg) {
      console.error("No valid vehicle image found for level", this.level);
      return;
    }

    // Depending on level, we scale the enemy vehicles to appropriate sizes.
    let originalWidth = vehicleImg.width;
    let originalHeight = vehicleImg.height;
    let vehicleWidth, vehicleHeight;
    if (this.level === 1) {
      vehicleWidth = 30;
      vehicleHeight = 60;
    } else if (this.level === 2) {
      let maxWidth = 80;
      let maxHeight = 80;
      let wScale = maxWidth / originalWidth;
      let hScale = maxHeight / originalHeight;
      let scaleFactor = min(wScale, hScale, 1.0);
      vehicleWidth = originalWidth * scaleFactor;
      vehicleHeight = originalHeight * scaleFactor;
    } else if (this.level === 3) {
      let maxWidth = 150;
      let maxHeight = 150;
      let wScale = maxWidth / originalWidth;
      let hScale = maxHeight / originalHeight;
      let scaleFactor = min(wScale, hScale, 1.0);
      vehicleWidth = originalWidth * scaleFactor;
      vehicleHeight = originalHeight * scaleFactor;
    }

    // We attempt to place the new vehicle at a random x, ensuring no overlap with others.
    let margin = 20;
    let attempts = 0;
    const maxAttempts = 10;
    let xPos, newVehicle, collides;
    do {
      xPos = random(margin, regionWidth - margin - vehicleWidth);
      newVehicle = {
        x: xPos,
        y: -vehicleHeight,     // Start slightly above the visible region.
        velocityY: random(3, 7),
        velocityX: 0,
        image: vehicleImg,
        width: vehicleWidth,
        height: vehicleHeight
      };
      collides = this.isCollidingWithEnemies(newVehicle);
      attempts++;
    } while (collides && attempts < maxAttempts);

    // If we don't collide, push the new vehicle into 'enemies'.
    if (!collides) {
      this.enemies.push(newVehicle);
    }
  }

  updateAndRenderVehicles(pg, regionWidth, regionHeight, offsetX) {
    // Move each enemy vehicle, and handle collisions among them horizontally.
    for (let i = 0; i < this.enemies.length; i++) {
      this.enemies[i].x += this.enemies[i].velocityX;
      this.enemies[i].y += this.enemies[i].velocityY;
    }

    // Check collision between vehicles to keep them from overlapping too much.
    for (let i = 0; i < this.enemies.length; i++) {
      for (let j = i + 1; j < this.enemies.length; j++) {
        if (
          this.rectsIntersect(
            this.enemies[i].x,
            this.enemies[i].y,
            this.enemies[i].width,
            this.enemies[i].height,
            this.enemies[j].x,
            this.enemies[j].y,
            this.enemies[j].width,
            this.enemies[j].height
          )
        ) {
          let leftEdge = max(this.enemies[i].x, this.enemies[j].x);
          let rightEdge = min(
            this.enemies[i].x + this.enemies[i].width,
            this.enemies[j].x + this.enemies[j].width
          );
          let overlap = rightEdge - leftEdge;
          if (overlap > 0) {
            // Push them apart horizontally by half the overlap each.
            if (this.enemies[i].x < this.enemies[j].x) {
              this.enemies[i].x -= overlap / 2;
              this.enemies[j].x += overlap / 2;
            } else {
              this.enemies[i].x += overlap / 2;
              this.enemies[j].x -= overlap / 2;
            }
            // Constrain so they don't go outside the game region.
            this.enemies[i].x = constrain(this.enemies[i].x, 0, regionWidth - this.enemies[i].width);
            this.enemies[j].x = constrain(this.enemies[j].x, 0, regionWidth - this.enemies[j].width);
          }
        }
      }
    }

    // Remove vehicles that move off-screen (below regionHeight+100).
    // Increase score for each vehicle that passes off screen.
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      if (this.enemies[i].y > regionHeight + 100) {
        this.score++;
        console.log("Vehicle passed offscreen. Score incremented to: " + this.score);
        this.enemies.splice(i, 1);
      } else {
        // Otherwise, draw the vehicle onto the provided pGraphics object.
        pg.image(
          this.enemies[i].image,
          this.enemies[i].x - offsetX,
          this.enemies[i].y,
          this.enemies[i].width,
          this.enemies[i].height
        );
      }
    }
  }

  /*========================================
    Collision & Utility Methods
  ========================================*/
  checkCollisions(pX, pY, pW, pH) {
    // If the game isn't over, check if the protagonist collides with any enemies.
    if (this.gameOver) return;
    for (let vehicle of this.enemies) {
      if (this.rectsIntersect(pX, pY, pW, pH, vehicle.x, vehicle.y, vehicle.width, vehicle.height)) {
        console.log("Collision detected! Game Over.");
        this.gameOver = true;
        return;
      }
    }
  }

  isCollidingWithEnemies(newVehicle) {
    // Checks if 'newVehicle' overlaps with any existing vehicles in 'enemies'.
    for (let enemy of this.enemies) {
      if (
        this.rectsIntersect(
          newVehicle.x,
          newVehicle.y,
          newVehicle.width,
          newVehicle.height,
          enemy.x,
          enemy.y,
          enemy.width,
          enemy.height
        )
      ) {
        return true;
      }
    }
    return false;
  }

  rectsIntersect(x1, y1, w1, h1, x2, y2, w2, h2) {
    // Basic rectangle intersection check with a small margin to avoid too-sensitive collisions.
    let margin = 10;
    return !(
      (x2 > x1 + w1 - margin) ||
      (x2 + w2 < x1 + margin) ||
      (y2 > y1 + h1 - margin) ||
      (y2 + h2 < y1 + margin)
    );
  }

  /*========================================
    Level-Up Logic
  ========================================*/
  checkLevelUp() {
    // Score thresholds: 5 points moves to Level 2, 40 points to Level 3, 20 points finishes game.
    if (this.score >= 20) {
      this.gameFinished = true;
      console.log("Game Finished! Final Score: " + this.score);
    } else if (this.level === 1 && this.score >= 5) {
      this.level = 2;
      this.levelOver = true;
      this.levelOverTimer = millis();
      console.log("Level 1 complete! Now at Level 2.");
    } else if (this.level === 2 && this.score >= 40) {
      this.level = 3;
      this.levelOver = true;
      this.levelOverTimer = millis();
      console.log("Level 2 complete! Now at Level 3.");
    }
    if (this.level > this.maxLevel) {
      // If we surpass the max level, clamp it.
      this.level = this.maxLevel;
    }
  }

  /*========================================
    HUD and Label Drawing
  ========================================*/
  drawHUD() {
    // Renders a small overlay to display score, gear, and level in the top-left.
    let hudWidth = 150, hudHeight = 70, hudX = 10, hudY = 10;
    fill(50, 50, 50, 200);
    rect(hudX, hudY, hudWidth, hudHeight, 5);
    fill(255);
    textSize(14);
    textAlign(LEFT, TOP);
    text("Score: " + this.score, hudX + 10, hudY + 5);
    text("Gear: " + this.lastGear, hudX + 10, hudY + 25);
    text("Level: " + this.level, hudX + 10, hudY + 45);
  }

  /*========================================
    Start & Game Over Screens
  ========================================*/
  drawStartScreen(x, y, w, h) {
    console.log("Start screen displayed.");
    // Also used in drawFaceGameMode if 'startScreen' is true.
    push();
    background(0);
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Welcome to the Face Game!", width / 2, height / 2 - 120);
    textSize(20);
    text("How to Play:", width / 2, height / 2 - 80);
    text("• Use your hand gestures to control the gear/speed", width / 2, height / 2 - 50);
    text("• Move your face to steer left/right", width / 2, height / 2 - 20);
    textSize(24);
    text("Level 1: Antique Cars", width / 2, height / 2 + 20);
    text("Level 2: Pickup Trucks", width / 2, height / 2 + 50);
    text("Level 3: Heavy Vehicles", width / 2, height / 2 + 80);
    textSize(18);
    text("Press 'S' to start", width / 2, height / 2 + 130);
    pop();
  }

  drawGameOverScreen(x, y, w, h) {
    console.log("Game over screen displayed.");
    // Also used in drawFaceGameMode if 'gameOver' is true.
    push();
    background(0);
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 60);

    let btnW = 120, btnH = 40;
    let btnX = width / 2 - btnW / 2;
    let btnY = height / 2;
    fill(255);
    rect(btnX, btnY, btnW, btnH, 5);
    fill(0);
    textSize(20);
    text("Restart", btnX + btnW / 2, btnY + btnH / 2);
    pop();
  }

  /*========================================
    NEW: Game Finished Screen
  ========================================*/
  drawGameFinishedScreen(x, y, w, h) {
    console.log("Game finished screen displayed.");
    // Shown in drawFaceGameMode if the player hits the final score.
    push();
    background(0, 150, 0);
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("CONGRATULATIONS!", width / 2, height / 2 - 60);
    textSize(24);
    text("You finished the game!", width / 2, height / 2 - 20);
    text("Final Score: " + this.score, width / 2, height / 2 + 10);
    textSize(18);
    text("Press 'R' to restart", width / 2, height / 2 + 50);
    pop();
  }

  /*========================================
    Game Restart & Mouse Handling
  ========================================*/
  restartGame() {
    // Resets all relevant variables to start the game fresh.
    this.gameOver = false;
    this.gameFinished = false;
    this.score = 0;
    this.level = 1;
    this.levelOver = false;
    this.protagonist.x = width / 2;
    this.protagonist.y = 530;
    this.enemies = [];
    if (this.restartButton) {
      // If a restart button was used, remove it from the DOM.
      this.restartButton.remove();
      this.restartButton = null;
    }
  }

  handleMousePressed() {
    // Called on each mouse press. If the game is over/finished,
    // we check if the user clicked the 'Restart' area and handle it.
    if (this.gameOver || this.gameFinished) {
      let btnW = 120;
      let btnH = 40;
      let btnX = width / 2 - btnW / 2;
      let btnY = height / 2;
      if (
        mouseX > btnX &&
        mouseX < btnX + btnW &&
        mouseY > btnY &&
        mouseY < btnY + btnH
      ) {
        this.restartGame();
      }
    }
  }
}
