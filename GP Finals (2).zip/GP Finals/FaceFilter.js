// FaceFilter class is responsible for performing various image processing tasks,
// including channel isolation, thresholding, color space conversions, and
// snapshot-based face detection. It stores and operates on processed images used by the UI.

class FaceFilter {
  constructor(capture, faceDetector) {
    // 'capture' is the p5 video capture object (live video feed).
    // 'faceDetector' is an object that detects faces in an image (e.g., objectdetect).

    this.capture = capture; 
    this.faceDetector = faceDetector;

    // Variables to store snapshots and processed versions of the camera feed.
    this.faceFilterSnapshot = null;     // Full-sized snapshot of the capture feed.
    this.snapshotScaled = null;         // Scaled-down version (160x120) for quicker processing.
    this.snapshotTaken = false;         // Flag to check if a snapshot has been taken.

    // Various processed images (grayscale, channel splits, thresholded images, etc.).
    this.grayBrightImg = null;
    this.redChannelImg = null;
    this.greenChannelImg = null;
    this.blueChannelImg = null;
    this.threshRImg = null;
    this.threshGImg = null;
    this.threshBImg = null;
    this.colorSpace1Img = null;        // For one of the color spaces, typically HSV.
    this.colorSpace2Img = null;        // For another color space, typically YCbCr.
    this.threshColorSpace1Img = null;  // Thresholded version of the first color space image.
    this.threshColorSpace2Img = null;  // Thresholded version of the second color space image.

    // Used for face detection: we draw the scaled snapshot onto an offscreen buffer,
    // then pass its underlying canvas to the faceDetector.
    this.faceCanvas = createGraphics(160, 120);
    this.detections = []; // Holds face detection results (array of face regions).

    // Layout constants that might be used when drawing bounding boxes to the screen.
    this.cellW = 200;
    this.cellH = 150;
  }

  // =====================================================
  // Channel Isolation & Thresholding Methods
  // =====================================================

  isolateChannel(img, channelIndex) {
    // Creates a new image with only one channel (R, G, or B) present.
    // channelIndex 0 = Red, 1 = Green, 2 = Blue.
    let cImg = createImage(img.width, img.height);
    cImg.loadPixels();
    img.loadPixels();
    for (let y = 0; y < img.height; y++) {
      for (let x = 0; x < img.width; x++) {
        let i = (x + y * img.width) * 4;
        // 'val' is the intensity of the chosen channel at pixel (x,y).
        let val = img.pixels[i + channelIndex];
        // Copy only that channel's value, setting the others to zero.
        cImg.pixels[i + 0] = (channelIndex === 0) ? val : 0;
        cImg.pixels[i + 1] = (channelIndex === 1) ? val : 0;
        cImg.pixels[i + 2] = (channelIndex === 2) ? val : 0;
        cImg.pixels[i + 3] = 255;
      }
    }
    cImg.updatePixels();
    return cImg;
  }

  thresholdSingleChannel(srcImg, outImg, tValue, channelIndex) {
    // Thresholds a single color channel in srcImg, placing the result into outImg.
    // If the channel's value > tValue, we set that channel to 255 (white),
    // otherwise 0 (black). The other channels are set to 0.
    srcImg.loadPixels();
    outImg.loadPixels();
    for (let y = 0; y < srcImg.height; y++) {
      for (let x = 0; x < srcImg.width; x++) {
        let i = (x + y * srcImg.width) * 4;
        let channelVal = srcImg.pixels[i + channelIndex];
        let val = (channelVal > tValue) ? 255 : 0;
        if (channelIndex === 0) {
          // Red channel threshold.
          outImg.pixels[i + 0] = val;
          outImg.pixels[i + 1] = 0;
          outImg.pixels[i + 2] = 0;
        } else if (channelIndex === 1) {
          // Green channel threshold.
          outImg.pixels[i + 0] = 0;
          outImg.pixels[i + 1] = val;
          outImg.pixels[i + 2] = 0;
        } else if (channelIndex === 2) {
          // Blue channel threshold.
          outImg.pixels[i + 0] = 0;
          outImg.pixels[i + 1] = 0;
          outImg.pixels[i + 2] = val;
        }
        outImg.pixels[i + 3] = 255;
      }
    }
    outImg.updatePixels();
  }

  thresholdFullImage(srcImg, outImg, tValue) {
    // Thresholds based on total pixel intensity (R + G + B).
    // If the sum > tValue, pixel becomes white, otherwise black.
    srcImg.loadPixels();
    outImg.loadPixels();
    for (let y = 0; y < srcImg.height; y++) {
      for (let x = 0; x < srcImg.width; x++) {
        let i = (x + y * srcImg.width) * 4;
        let r = srcImg.pixels[i + 0];
        let g = srcImg.pixels[i + 1];
        let b = srcImg.pixels[i + 2];
        let intensity = r + g + b;
        let val = (intensity > tValue) ? 255 : 0;
        outImg.pixels[i + 0] = val;
        outImg.pixels[i + 1] = val;
        outImg.pixels[i + 2] = val;
        outImg.pixels[i + 3] = 255;
      }
    }
    outImg.updatePixels();
  }

  thresholdHSVImage(srcImg, outImg, tValue) {
    // Thresholds based on the V channel in the HSV color space
    // (assuming the input image is already in HSV form).
    srcImg.loadPixels();
    outImg.loadPixels();
    for (let i = 0; i < srcImg.pixels.length; i += 4) {
      let v = srcImg.pixels[i + 2]; // V channel is stored in pixels[i+2].
      if (v > tValue) {
        // Keep the original HSV values if above threshold.
        outImg.pixels[i + 0] = srcImg.pixels[i + 0];
        outImg.pixels[i + 1] = srcImg.pixels[i + 1];
        outImg.pixels[i + 2] = srcImg.pixels[i + 2];
        outImg.pixels[i + 3] = 255;
      } else {
        // Otherwise, set the pixel to black.
        outImg.pixels[i + 0] = 0;
        outImg.pixels[i + 1] = 0;
        outImg.pixels[i + 2] = 0;
        outImg.pixels[i + 3] = 255;
      }
    }
    outImg.updatePixels();
  }

  thresholdYCbCrImage(srcImg, outImg, tValue) {
    // Thresholds based on the Y channel in the YCbCr color space
    // (assuming the input image is already in YCbCr form).
    srcImg.loadPixels();
    outImg.loadPixels();
    for (let i = 0; i < srcImg.pixels.length; i += 4) {
      let Y = srcImg.pixels[i + 0]; // Y channel is stored in pixels[i].
      if (Y > tValue) {
        // Keep the original color values if above threshold.
        outImg.pixels[i + 0] = srcImg.pixels[i + 0];
        outImg.pixels[i + 1] = srcImg.pixels[i + 1];
        outImg.pixels[i + 2] = srcImg.pixels[i + 2];
        outImg.pixels[i + 3] = 255;
      } else {
        // Otherwise, set pixel to black.
        outImg.pixels[i + 0] = 0;
        outImg.pixels[i + 1] = 0;
        outImg.pixels[i + 2] = 0;
        outImg.pixels[i + 3] = 255;
      }
    }
    outImg.updatePixels();
  }

  // =====================================================
  // Colour Space Conversions
  // =====================================================

  convertToHSV(img) {
    // Converts an RGB image to HSV space, storing the result in a new image.
    // H (0-360) is mapped to 0-255, S (0-1) -> 0-255, V (0-1) -> 0-255.
    let hsvImg = createImage(img.width, img.height);
    hsvImg.loadPixels();
    img.loadPixels();
    for (let y = 0; y < img.height; y++) {
      for (let x = 0; x < img.width; x++) {
        let i = (x + y * img.width) * 4;
        // Normalize RGB components to [0,1].
        let r = img.pixels[i + 0] / 255;
        let g = img.pixels[i + 1] / 255;
        let b = img.pixels[i + 2] / 255;

        // Compute max and min to figure out saturation and hue.
        let maxVal = max(r, g, b);
        let minVal = min(r, g, b);
        let d = maxVal - minVal;
        let h = 0;

        // Hue computation based on which channel is the max.
        if (d !== 0) {
          if (maxVal === r) {
            h = 60 * (((g - b) / d) % 6);
          } else if (maxVal === g) {
            h = 60 * ((b - r) / d + 2);
          } else if (maxVal === b) {
            h = 60 * ((r - g) / d + 4);
          }
        }
        if (h < 0) h += 360;

        // Saturation is zero if maxVal is zero, else ratio.
        let s = (maxVal === 0) ? 0 : d / maxVal;
        let v = maxVal; // Value is the max channel.

        // Map and store in the HSV image (0-255 range).
        hsvImg.pixels[i + 0] = h * (255 / 360);
        hsvImg.pixels[i + 1] = s * 255;
        hsvImg.pixels[i + 2] = v * 255;
        hsvImg.pixels[i + 3] = 255;
      }
    }
    hsvImg.updatePixels();
    return hsvImg;
  }

  convertToYCbCr(img) {
    // Converts an RGB image to YCbCr color space.
    // Formula:
    // Y  = 0.299R + 0.587G + 0.114B
    // Cb = -0.1687R - 0.3313G + 0.5B + 128
    // Cr = 0.5R - 0.4187G - 0.0813B + 128
    let ycbcrImg = createImage(img.width, img.height);
    ycbcrImg.loadPixels();
    img.loadPixels();
    for (let y = 0; y < img.height; y++) {
      for (let x = 0; x < img.width; x++) {
        let i = (x + y * img.width) * 4;
        let r = img.pixels[i + 0];
        let g = img.pixels[i + 1];
        let b = img.pixels[i + 2];

        let Y  =  0.299 * r + 0.587 * g + 0.114 * b;
        let Cb = -0.1687 * r - 0.3313 * g + 0.5 * b + 128;
        let Cr =  0.5 * r - 0.4187 * g - 0.0813 * b + 128;

        ycbcrImg.pixels[i + 0] = Y;
        ycbcrImg.pixels[i + 1] = Cb;
        ycbcrImg.pixels[i + 2] = Cr;
        ycbcrImg.pixels[i + 3] = 255;
      }
    }
    ycbcrImg.updatePixels();
    return ycbcrImg;
  }

  // =====================================================
  // Face Detection Box Drawing
  // =====================================================

  drawFaceDetectionBox(detections) {
    // Draws bounding boxes for faces onto the canvas (for a particular region).
    // Maps the detection coords from 160x120 scale to the UI's cell dimensions.
    if (detections.length < 1) return;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      let sx = face[0];
      let sy = face[1];
      let sw = face[2];
      let sh = face[3];
      // Map from the 160x120 detection scale to the desired UI scale.
      let xMap = map(sx, 0, 160, 0, this.cellW);
      let yMap = map(sy, 0, 120, 3 * this.cellH, 4 * this.cellH);
      let wMap = map(sw, 0, 160, 0, this.cellW);
      let hMap = map(sh, 0, 120, 0, this.cellH);
      rect(xMap, yMap, wMap, hMap);
    }
    pop();
  }

  drawFaceDetectionBoxComposite(detections) {
    // Similar to drawFaceDetectionBox but designed for a composite image scale.
    // Draws bounding boxes in a different region (like for a row/column offset).
    if (detections.length < 1) return;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      let sx = face[0];
      let sy = face[1];
      let sw = face[2];
      let sh = face[3];
      let xMap = map(sx, 0, 160, 0, this.cellW);
      let yMap = map(sy, 0, 120, 0, this.cellH);
      let wMap = map(sw, 0, 160, 0, this.cellW);
      let hMap = map(sh, 0, 120, 0, this.cellH);
      rect(xMap, yMap, wMap, hMap);
    }
    pop();
  }

  // =====================================================
  // Image Processing Filters
  // =====================================================

  makeGrayscale(imgIn) {
    // Converts an image to grayscale by computing the luminance of each pixel.
    let out = createImage(imgIn.width, imgIn.height);
    out.loadPixels();
    imgIn.loadPixels();
    for (let y = 0; y < imgIn.height; y++) {
      for (let x = 0; x < imgIn.width; x++) {
        let i = (x + y * imgIn.width) * 4;
        let r = imgIn.pixels[i + 0];
        let g = imgIn.pixels[i + 1];
        let b = imgIn.pixels[i + 2];
        // Weighted average for grayscale.
        let gray = 0.299 * r + 0.587 * g + 0.114 * b;
        out.pixels[i + 0] = gray;
        out.pixels[i + 1] = gray;
        out.pixels[i + 2] = gray;
        out.pixels[i + 3] = 255;
      }
    }
    out.updatePixels();
    return out;
  }

  makeBlur(imgIn, blurSize) {
    // Performs a simple box blur by averaging pixel values within a (2*blurSize+1) kernel.
    let out = createImage(imgIn.width, imgIn.height);
    imgIn.loadPixels();
    out.loadPixels();
    for (let y = 0; y < imgIn.height; y++) {
      for (let x = 0; x < imgIn.width; x++) {
        let sumR = 0, sumG = 0, sumB = 0, count = 0;
        // Loop over the kernel region to accumulate color values.
        for (let ky = -blurSize; ky <= blurSize; ky++) {
          for (let kx = -blurSize; kx <= blurSize; kx++) {
            let nx = x + kx;
            let ny = y + ky;
            // Only accumulate if the neighbor is within image bounds.
            if (nx >= 0 && nx < imgIn.width && ny >= 0 && ny < imgIn.height) {
              let idx = (nx + ny * imgIn.width) * 4;
              sumR += imgIn.pixels[idx + 0];
              sumG += imgIn.pixels[idx + 1];
              sumB += imgIn.pixels[idx + 2];
              count++;
            }
          }
        }
        // Average the sums and write to the output image.
        let i = (x + y * imgIn.width) * 4;
        out.pixels[i + 0] = sumR / count;
        out.pixels[i + 1] = sumG / count;
        out.pixels[i + 2] = sumB / count;
        out.pixels[i + 3] = 255;
      }
    }
    out.updatePixels();
    return out;
  }

  pixelate(imgIn, blockW, blockH) {
    // Pixelates the image by dividing it into blocks of (blockW x blockH).
    // Each block is filled with the average brightness of its pixels.
    let out = createImage(imgIn.width, imgIn.height);
    out.loadPixels();
    imgIn.loadPixels();
    for (let by = 0; by < imgIn.height; by += blockH) {
      for (let bx = 0; bx < imgIn.width; bx += blockW) {
        let sum = 0, count = 0;
        // Accumulate brightness values within the block.
        for (let y = 0; y < blockH; y++) {
          for (let x = 0; x < blockW; x++) {
            let cx = bx + x;
            let cy = by + y;
            if (cx < imgIn.width && cy < imgIn.height) {
              let i = (cx + cy * imgIn.width) * 4;
              sum += imgIn.pixels[i + 0]; // Here we only use the red channel for brightness.
              count++;
            }
          }
        }
        // Compute the average brightness of the block.
        let ave = sum / count;
        // Fill the block in the output with that average value.
        for (let y = 0; y < blockH; y++) {
          for (let x = 0; x < blockW; x++) {
            let cx = bx + x;
            let cy = by + y;
            if (cx < imgIn.width && cy < imgIn.height) {
              let i = (cx + cy * imgIn.width) * 4;
              out.pixels[i + 0] = ave;
              out.pixels[i + 1] = ave;
              out.pixels[i + 2] = ave;
              out.pixels[i + 3] = 255;
            }
          }
        }
      }
    }
    out.updatePixels();
    return out;
  }

  createGrayBrightImage(srcImg) {
    // Creates a grayscale image from 'srcImg' and increases brightness by 20%.
    let output = createImage(srcImg.width, srcImg.height);
    output.loadPixels();
    srcImg.loadPixels();
    for (let y = 0; y < srcImg.height; y++) {
      for (let x = 0; x < srcImg.width; x++) {
        let index = (x + y * srcImg.width) * 4;
        let r = srcImg.pixels[index + 0];
        let g = srcImg.pixels[index + 1];
        let b = srcImg.pixels[index + 2];
        // Compute the grayscale value.
        let gray = 0.299 * r + 0.587 * g + 0.114 * b;
        // Increase brightness by 20%, cap at 255 if overflow.
        gray *= 1.2;
        if (gray > 255) gray = 255;
        output.pixels[index + 0] = gray;
        output.pixels[index + 1] = gray;
        output.pixels[index + 2] = gray;
        output.pixels[index + 3] = 255;
      }
    }
    output.updatePixels();
    return output;
  }

  // =====================================================
  // Snapshot and Processing
  // =====================================================

  takeSnapshot() {
    // Captures a frame from the live video and processes it for subsequent filters.
    // This snapshot is used to detect faces and create specialized versions (channels, color spaces, etc.).
    this.capture.loadPixels(); // Ensure we have the latest frame data.
    let snapshotBuffer = createGraphics(this.capture.width, this.capture.height);
    snapshotBuffer.image(this.capture, 0, 0, this.capture.width, this.capture.height);
    this.faceFilterSnapshot = snapshotBuffer.get(); 
    this.snapshotTaken = true; // Mark that a snapshot is captured.

    // Scale the snapshot down to 160x120 for faster processing (esp. face detection).
    this.snapshotScaled = createImage(160, 120);
    this.snapshotScaled.copy(
      this.faceFilterSnapshot,
      0,
      0,
      this.faceFilterSnapshot.width,
      this.faceFilterSnapshot.height,
      0,
      0,
      160,
      120
    );

    // Create a grayscale + brightened version of the scaled snapshot.
    this.grayBrightImg = this.createGrayBrightImage(this.snapshotScaled);

    // Isolate each color channel (R, G, B) from the scaled snapshot.
    this.redChannelImg = this.isolateChannel(this.snapshotScaled, 0);
    this.greenChannelImg = this.isolateChannel(this.snapshotScaled, 1);
    this.blueChannelImg = this.isolateChannel(this.snapshotScaled, 2);

    // Prepare threshold images for each channel.
    this.threshRImg = createImage(160, 120);
    this.threshGImg = createImage(160, 120);
    this.threshBImg = createImage(160, 120);

    // Convert the scaled snapshot to two different color spaces (HSV & YCbCr).
    this.colorSpace1Img = this.convertToHSV(this.snapshotScaled);
    this.colorSpace2Img = this.convertToYCbCr(this.snapshotScaled);

    // Prepare threshold images for these converted color spaces.
    this.threshColorSpace1Img = createImage(160, 120);
    this.threshColorSpace2Img = createImage(160, 120);

    console.log("Snapshot taken and processed.");

    // Perform face detection on the scaled snapshot using the faceDetector.
    // The faceCanvas is used as an offscreen buffer for detection.
    this.faceCanvas.image(this.snapshotScaled, 0, 0, 160, 120);
    this.detections = this.faceDetector.detect(this.faceCanvas.canvas);
    console.log("Detected faces:", this.detections);
  }
}
