class FaceFilterUI {
  constructor(cnv, capture) {
    // 'cnv' is the p5 canvas reference, and 'capture' is the video feed.
    this.cnv = cnv;
    this.capture = capture;
    
    // 'mode' determines whether we're in the grid view (0) or the Snap/phone UI (1).
    this.mode = 0;
    // 'currentSnapFilter' holds the name of the selected Snapchat-style filter.
    this.currentSnapFilter = "none";
    
    // Dimensions used for drawing processed images in a grid format.
    this.cellW = 200;
    this.cellH = 150;
    
    // References to DOM elements for the control panel, sliders, and buttons.
    this.controlPanel = null;
    this.faceFilterControls = null;
    this.snapModeControls = null;
    this.modeButton = null;
    this.threshRSlider = null;
    this.threshGSlider = null;
    this.threshBSlider = null;
    this.threshCS1Slider = null;
    this.threshCS2Slider = null;
    
    // Initialize everything: control panel, filter controls, Snap mode controls.
    this.setupControlPanel();
    this.setupFaceFilterControls();
    this.setupSnapModeControls();
  }
  
  // -------------------------------------------------------
  // Setup Methods
  // -------------------------------------------------------
  
  setupControlPanel() {
    this.controlPanel = createDiv();
    this.controlPanel.position(this.cnv.x + width + 30, 20);
    this.controlPanel.style('width', '220px');
    this.controlPanel.style('padding', '10px');
    this.controlPanel.style('background', '#f0f0f0');
    this.controlPanel.style('border', '1px solid #ccc');
    this.controlPanel.style('border-radius', '5px');
    this.controlPanel.style('font-family', 'sans-serif');
  }
  
  setupFaceFilterControls() {
    // Button to switch to Snap mode.
    this.modeButton = createButton('Snap');
    this.modeButton.parent(this.controlPanel);
    this.modeButton.mousePressed(() => {
      console.log("Mode button pressed.");
      this.toggleMode();
    });
    this.modeButton.style('width', '100%');
    this.modeButton.style('margin-bottom', '10px');
    
    this.faceFilterControls = createDiv();
    this.faceFilterControls.parent(this.controlPanel);
    
    // Button to capture a snapshot from the live video feed.
    let snapButton = createButton('Take Snapshot');
    snapButton.parent(this.faceFilterControls);
    snapButton.mousePressed(() => {
      console.log("Take Snapshot button pressed.");
      faceFilter.takeSnapshot();
    });
    snapButton.style('width', '100%');
    snapButton.style('margin-bottom', '10px');
    
    // Add sliders for thresholding each channel and color space.
    this.createSliderControl(
      this.faceFilterControls,
      'Threshold Red:',
      0, 255, 128,
      (slider) => { this.threshRSlider = slider; },
      "Threshold Red"
    );
    this.createSliderControl(
      this.faceFilterControls,
      'Threshold Green:',
      0, 255, 128,
      (slider) => { this.threshGSlider = slider; },
      "Threshold Green"
    );
    this.createSliderControl(
      this.faceFilterControls,
      'Threshold Blue:',
      0, 255, 128,
      (slider) => { this.threshBSlider = slider; },
      "Threshold Blue"
    );
    this.createSliderControl(
      this.faceFilterControls,
      'Threshold HSV (V):',
      0, 255, 128,
      (slider) => { this.threshCS1Slider = slider; },
      "Threshold HSV (V)"
    );
    this.createSliderControl(
      this.faceFilterControls,
      'Threshold YCbCr (Y):',
      0, 255, 128,
      (slider) => { this.threshCS2Slider = slider; },
      "Threshold YCbCr (Y)"
    );
  }
  
  createSliderControl(parent, labelText, min, max, initial, assignCallback, logLabel) {
    createP(labelText).parent(parent);
    let slider = createSlider(min, max, initial);
    slider.parent(parent);
    slider.style('width', '100%');
    // Log when the slider value changes
    slider.input(() => {
      console.log(`${logLabel} slider changed to: ${slider.value()}`);
    });
    assignCallback(slider);
  }
  
  setupSnapModeControls() {
    this.snapModeControls = createDiv();
    this.snapModeControls.parent(this.controlPanel);
    this.snapModeControls.style('margin-top', '10px');
    this.snapModeControls.style('text-align', 'center');
    
    createP("Snapchat Mode Filters:").parent(this.snapModeControls);
    
    this.createFilterButton(this.snapModeControls, "None", "none");
    this.createFilterButton(this.snapModeControls, "ASCII Filter", "ascii");
    this.createFilterButton(this.snapModeControls, "Thermal Vision", "thermal");
    this.createFilterButton(this.snapModeControls, "Insect Vision", "insect");
    this.createFilterButton(this.snapModeControls, "Kaleidoscope Filter", "kaleidoscope");
    this.createFilterButton(this.snapModeControls, "Fisheye Filter", "fisheye");
    this.createFilterButton(this.snapModeControls, "Timed Delay Lens", "timedDelay");
    this.createFilterButton(this.snapModeControls, "Face Game Mode", "faceGame");
    
    this.snapModeControls.hide();
  }
  
  createFilterButton(parent, buttonText, filterName) {
    let btn = createButton(buttonText);
    btn.parent(parent);
    btn.style('width', '100%');
    btn.style('margin-bottom', '5px');
    btn.mousePressed(() => {
      console.log(`"${buttonText}" filter button pressed.`);
      this.currentSnapFilter = filterName;
    });
  }
  
  // -------------------------------------------------------
  // Drawing Methods
  // -------------------------------------------------------
  
  drawSnapMode() {
    background(220);
    this.drawPhoneInterface(0, 0, width, height);
  }
  
  drawInstructions() {
    background(240);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(32);
    text("Welcome to the Face Filter App", width / 2, height / 2 - 100);
    textSize(20);
    text("Instructions:", width / 2, height / 2 - 50);
    textSize(16);
    text("1. Click 'Take Snapshot' in the control panel to capture your face.", width / 2, height / 2 - 20);
    text("2. Adjust the threshold sliders as desired.", width / 2, height / 2 + 10);
    text("3. Press keys 1-4 to apply different filters on the detected face(s).", width / 2, height / 2 + 40);
    text("4. Enjoy the results!", width / 2, height / 2 + 70);
  }
  
  drawFaceFilterGrid() {
    background(220);
    this.drawRow0();
    this.drawRow1();
    this.drawRow2();
    this.drawRow3();
    this.drawRow4();
  }
  
  drawRow0() {
    image(faceFilter.faceFilterSnapshot, 0, 0, this.cellW, this.cellH);
    image(faceFilter.grayBrightImg, this.cellW, 0, this.cellW, this.cellH);
    this.drawLabel("Original Snapshot", 5, 5);
    this.drawLabel("Grayscale + Bright", this.cellW + 5, 5);
  }
  
  drawRow1() {
    image(faceFilter.redChannelImg, 0, this.cellH, this.cellW, this.cellH);
    image(faceFilter.greenChannelImg, this.cellW, this.cellH, this.cellW, this.cellH);
    image(faceFilter.blueChannelImg, 2 * this.cellW, this.cellH, this.cellW, this.cellH);
    this.drawLabel("Red Channel", 5, this.cellH + 5);
    this.drawLabel("Green Channel", this.cellW + 5, this.cellH + 5);
    this.drawLabel("Blue Channel", 2 * this.cellW + 5, this.cellH + 5);
  }
  
  drawRow2() {
    faceFilter.thresholdSingleChannel(faceFilter.redChannelImg, faceFilter.threshRImg, this.threshRSlider.value(), 0);
    faceFilter.thresholdSingleChannel(faceFilter.greenChannelImg, faceFilter.threshGImg, this.threshGSlider.value(), 1);
    faceFilter.thresholdSingleChannel(faceFilter.blueChannelImg, faceFilter.threshBImg, this.threshBSlider.value(), 2);
    image(faceFilter.threshRImg, 0, 2 * this.cellH, this.cellW, this.cellH);
    image(faceFilter.threshGImg, this.cellW, 2 * this.cellH, this.cellW, this.cellH);
    image(faceFilter.threshBImg, 2 * this.cellW, 2 * this.cellH, this.cellW, this.cellH);
    this.drawLabel("Thresholded Red", 5, 2 * this.cellH + 5);
    this.drawLabel("Thresholded Green", this.cellW + 5, 2 * this.cellH + 5);
    this.drawLabel("Thresholded Blue", 2 * this.cellW + 5, 2 * this.cellH + 5);
  }
  
  drawRow3() {
    let boundingBoxImg = faceFilter.faceFilterSnapshot.get();
    image(boundingBoxImg, 0, 3 * this.cellH, this.cellW, this.cellH);
    image(faceFilter.colorSpace1Img, this.cellW, 3 * this.cellH, this.cellW, this.cellH);
    image(faceFilter.colorSpace2Img, 2 * this.cellW, 3 * this.cellH, this.cellW, this.cellH);
    this.drawLabel("Face Detection Box", 5, 3 * this.cellH + 5);
    this.drawLabel("HSV Color Space", this.cellW + 5, 3 * this.cellH + 5);
    this.drawLabel("YCbCr Color Space", 2 * this.cellW + 5, 3 * this.cellH + 5);
  }
  
  drawRow4() {
    if (faceFilter.filteredFaceImg) {
      image(faceFilter.filteredFaceImg, 0, 4 * this.cellH, this.cellW, this.cellH);
      push();
      translate(0, 4 * this.cellH);
      this.drawFaceDetectionBoxComposite();
      pop();
    } else {
      fill(0);
      textSize(13);
      text("No face replaced. (Press 1-4)", 95, 4 * this.cellH + 45);
    }
    faceFilter.thresholdHSVImage(faceFilter.colorSpace1Img, faceFilter.threshColorSpace1Img, this.threshCS1Slider.value());
    faceFilter.thresholdYCbCrImage(faceFilter.colorSpace2Img, faceFilter.threshColorSpace2Img, this.threshCS2Slider.value());
    image(faceFilter.threshColorSpace1Img, this.cellW, 4 * this.cellH, this.cellW, this.cellH);
    image(faceFilter.threshColorSpace2Img, 2 * this.cellW, 4 * this.cellH, this.cellW, this.cellH);
    this.drawLabel("Filtered Face", 5, 4 * this.cellH + 5);
    this.drawLabel("Thresholded HSV", this.cellW + 5, 4 * this.cellH + 5);
    this.drawLabel("Thresholded YCbCr", 2 * this.cellW + 5, 4 * this.cellH + 5);
  }
  
  toggleMode() {
    if (this.mode === 0) {
      this.mode = 1;
      this.modeButton.html("Face Filter");
      this.faceFilterControls.hide();
      this.snapModeControls.show();
      console.log("Switched to Snap Mode (mode=1).");
      if (this.capture && this.capture.elt && typeof this.capture.elt.play === 'function') {
        this.capture.elt.play();
      }
    } else {
      this.mode = 0;
      this.modeButton.html("Snapchat Filter Mode");
      this.faceFilterControls.show();
      this.snapModeControls.hide();
      console.log("Switched to Face Filter Mode (mode=0).");
    }
  }
  
  drawStartScreen() {
    background(0);
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Welcome to my Game!", width / 2, height / 2 - 120);
    textSize(20);
    text("How to Play:", width / 2, height / 2 - 80);
    text("• Use your hand gestures to control the gear/speed", width / 2, height / 2 - 50);
    text("• Move your face to steer left/right", width / 2, height / 2 - 20);
    textSize(24);
    text("Level 1: Antique Cars", width / 2, height / 2 + 20);
    text("Level 2: Pickup Trucks", width / 2, height / 2 + 50);
    text("Level 3: Heavy Vehicles", width / 2, height / 2 + 80);
    textSize(18);
    text("Press 'S' to start", width / 2, height / 2 + 130);
  }
  
  drawGameOverScreen() {
    background(0);
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 60);
    let btnW = 120, btnH = 40;
    let btnX = width / 2 - btnW / 2;
    let btnY = height / 2;
    fill(255);
    rect(btnX, btnY, btnW, btnH, 5);
    fill(0);
    textSize(20);
    text("Restart", btnX + btnW / 2, btnY + btnH / 2);
  }
  
  // -------------------------------------------------------
  // Helper Methods for Face & Hand Drawing
  // -------------------------------------------------------
  
  drawFaceDetectionBox(bboxImg) {
    let detections = faceFilter.detections;
    if (detections.length < 1) return;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      let sx = face[0];
      let sy = face[1];
      let sw = face[2];
      let sh = face[3];
      let xMap = map(sx, 0, 160, 0, this.cellW);
      let yMap = map(sy, 0, 120, 0, this.cellH);
      let wMap = map(sw, 0, 160, 0, this.cellW);
      let hMap = map(sh, 0, 120, 0, this.cellH);
      rect(xMap, yMap, wMap, hMap);
    }
    pop();
  }
  
  drawFaceDetectionBoxAt(x, y, panelW, panelH) {
    let detections = faceFilter.detections;
    if (detections.length < 1) return null;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    let faceCenterX = null;
    let scaleX = panelW / this.capture.width;
    let scaleY = panelH / this.capture.height;
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      if (face.alignedRect && face.alignedRect._box) {
        let box = face.alignedRect._box;
        let fx = x + box._x * scaleX;
        let fy = y + box._y * scaleY;
        let fw = box._width * scaleX;
        let fh = box._height * scaleY;
        rect(fx, fy, fw, fh);
        if (faceCenterX === null) {
          faceCenterX = fx + fw / 2;
        }
      }
    }
    pop();
    return faceCenterX;
  }
  
  drawHandKeypoints(x, y, panelW, panelH) {
    let scaleX = panelW / this.capture.width;
    let scaleY = panelW / this.capture.height;
    if (handposePredictions && handposePredictions.length > 0) {
      for (let hand of handposePredictions) {
        if (hand.landmarks) {
          for (let keypoint of hand.landmarks) {
            let hx = x + keypoint[0] * scaleX;
            let hy = y + keypoint[1] * scaleY;
            fill(255, 255, 0);
            noStroke();
            ellipse(hx, hy, 8, 8);
          }
        }
      }
    }
  }
  
  drawFaceDetectionBoxComposite() {
    let detections = faceFilter.detections;
    if (detections.length < 1) return;
    push();
    noFill();
    stroke(255, 0, 0);
    strokeWeight(2);
    for (let i = 0; i < detections.length; i++) {
      let face = detections[i];
      let sx = face[0];
      let sy = face[1];
      let sw = face[2];
      let sh = face[3];
      let xMap = map(sx, 0, 160, 0, this.cellW);
      let yMap = map(sy, 0, 120, 0, this.cellH);
      let wMap = map(sw, 0, 160, 0, this.cellW);
      let hMap = map(sh, 0, 120, 0, this.cellH);
      rect(xMap, yMap, wMap, hMap);
    }
    pop();
  }
  
  // -------------------------------------------------------
  // drawLeftPanel
  // -------------------------------------------------------
  
  drawLeftPanel(x, y, panelW, panelH) {
    noFill();
    rect(x, y, panelW, panelH);
    let liveFrame = this.capture.get();
    image(liveFrame, x, y, panelW, panelH);
    let faceCenterX = this.drawFaceDetectionBoxAt(x, y, panelW, panelH);
    this.drawHandKeypoints(x, y, panelW, panelH);
    return faceCenterX;
  }
  
  // -------------------------------------------------------
  // HUD and Label Drawing
  // -------------------------------------------------------
  
  drawHUD() {
    let hudWidth = 150, hudHeight = 70, hudX = 10, hudY = 10;
    fill(50, 50, 50, 200);
    rect(hudX, hudY, hudWidth, hudHeight, 5);
    fill(255);
    textSize(14);
    textAlign(LEFT, TOP);
    text("Score: " + faceGame.score, hudX + 10, hudY + 5);
    text("Gear: " + faceGame.lastGear, hudX + 10, hudY + 25);
    text("Level: " + faceGame.level, hudX + 10, hudY + 45);
  }
  
  drawLabel(label, posX, posY) {
    push();
    textSize(12);
    textAlign(LEFT, TOP);
    let w = textWidth(label) + 10;
    noStroke();
    fill(0, 150);
    rect(posX - 5, posY - 3, w, 20, 5);
    fill(255);
    text(label, posX, posY);
    pop();
  }
  
  // -------------------------------------------------------
  // Phone Interface
  // -------------------------------------------------------
  
  drawPhoneInterface(x, y, w, h) {
    push();
    if (this.capture && this.capture.elt && this.capture.elt.paused) {
      this.capture.elt.play();
    }
    stroke(51);
    fill(255);
    rect(x, y, w, h, 30);
    let inset = 10;
    let screenX = x + inset;
    let screenY = y + inset;
    let screenW = w - 2 * inset;
    let screenH = h - 2 * inset - 30;
    fill(0);
    rect(screenX, screenY, screenW, screenH, 15);

    this.capture.loadPixels();
    let vidFrame = this.capture.get();
    let filteredFrame;
    
    if (this.currentSnapFilter === "ascii") {
      filteredFrame = snapFilters.applyAsciiFilter(vidFrame);
    } else if (this.currentSnapFilter === "thermal") {
      filteredFrame = snapFilters.applyThermalFilter(vidFrame);
    } else if (this.currentSnapFilter === "insect") {
      filteredFrame = snapFilters.applyInsectFilter(vidFrame);
    } else if (this.currentSnapFilter === "fisheye") {
      filteredFrame = snapFilters.applyFisheyeFilter(vidFrame);
    } else if (this.currentSnapFilter === "kaleidoscope") {
      filteredFrame = snapFilters.applyKaleidoscopeFilter(vidFrame);
    } else if (this.currentSnapFilter === "timedDelay") {
      filteredFrame = snapFilters.applyTimedDelayLens(vidFrame);
    } else if (this.currentSnapFilter === "faceGame") {
      this.drawFaceGameMode(screenX, screenY, screenW, screenH);
      pop();
      return;
    } else {
      filteredFrame = vidFrame;
    }
    
    image(filteredFrame, screenX, screenY, screenW, screenH);
    
    fill(0);
    let homeButtonSize = 20;
    let homeButtonX = x + w / 2;
    let homeButtonY = y + h - 15;
    ellipse(homeButtonX, homeButtonY, homeButtonSize);
    
    fill(0);
    let cameraSize = 8;
    let cameraX = x + w / 2;
    let cameraY = y + 10;
    ellipse(cameraX, cameraY, cameraSize);
    pop();
  }
  
  drawFaceGameMode(x, y, w, h) {
    if (faceGame && typeof faceGame.drawFaceGameMode === 'function') {
      faceGame.drawFaceGameMode(x, y, w, h);
    } else {
      fill(100);
      rect(x, y, w, h);
      fill(255);
      textSize(24);
      textAlign(CENTER, CENTER);
      text("Face Game Mode", x + w / 2, y + h / 2);
    }
  }
}
