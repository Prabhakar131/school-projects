
// =====================================================
// Global Variables  
// =====================================================
let capture, cnv;
let faceapi, handposeModel;
let faceDetector;
let detectedFaces = [];        // Will store the results of face detection
let handposePredictions = [];  // Will store the results of hand (pose) detection

// Class instances for different parts of our app
let faceFilter, faceFilterUI, faceGame, snapFilters;

// ml5 FaceAPI options determining which features we want (landmarks, expressions, etc.)
const faceapiOptions = {
  withLandmarks: true,
  withExpressions: true,
  withDescriptors: false
};

// =====================================================
// preload() – load images and assets used in game & filters
// =====================================================
let bgImage, protagonistImg;
let AntiqueBlueCarImg, AntiqueGreenCarImg, AntiqueWhiteCarImg;
let whiteContainerTruckImg, whitePickupTruckImg, yellowDumpTruckImg, yellowPickupTruckImg, blueContainerTruckImg;

function preload() {
  // Load background image for the car game
  bgImage = loadImage("assets/road.png");

  // Load main character's car image
  protagonistImg = loadImage("assets/redCar.png");

  // Load antique car images for Level 1
  AntiqueBlueCarImg = loadImage("assets/blueCar.png");
  AntiqueGreenCarImg = loadImage("assets/greenCar.png");
  AntiqueWhiteCarImg = loadImage("assets/whiteCar.png");

  // Load enemy vehicle images for Levels 2 & 3
  whiteContainerTruckImg = loadImage("assets/white_container_truck.png");
  whitePickupTruckImg = loadImage("assets/white_pickup_truck.png");
  yellowDumpTruckImg = loadImage("assets/yellow_dump_truck.png");
  yellowPickupTruckImg = loadImage("assets/yellow_pickup_truck.png");
  blueContainerTruckImg = loadImage("assets/blue_container_truck.png");
}

// =====================================================
// ml5 Callback Functions
// =====================================================
function faceReady() {
  // This callback fires when the ml5 FaceAPI model finishes loading.
  console.log("ml5 FaceAPI model is ready!");
  // Initiate first detection; subsequent calls happen inside gotFaces.
  faceapi.detect(gotFaces);
}

function gotFaces(error, result) {
  // Called whenever face detection completes or errors out.
  if (error) {
    console.error(error);
    return;
  }
  // Store detection results and trigger a new detection to keep it continuous.
  detectedFaces = result;
  faceapi.detect(gotFaces);
}

function handposeReady() {
  // This callback fires when the ml5 Handpose model finishes loading.
  console.log("ml5 Handpose model is ready!");
  // The model emits "predict" events whenever it has new hand data.
  handposeModel.on("predict", results => {
    handposePredictions = results;
  });
}

// =====================================================
// setup() – create canvas, video capture, and initialize classes
// =====================================================
function setup() {
  // Create a p5 canvas for drawing; position it on the screen.
  cnv = createCanvas(600, 750);
  cnv.position(20, 20);

  // Setup the live video capture at 640x480 and hide the raw feed.
  capture = createCapture(VIDEO);
  capture.size(640, 480);
  capture.hide();
  capture.elt.autoplay = true;
  capture.elt.muted = true;
  capture.elt.loop = true;

  // Initialize the faceApi and handpose models with their respective callbacks.
  faceapi = ml5.faceApi(capture, faceapiOptions, faceReady);
  handposeModel = ml5.handpose(capture, handposeReady);

  // Setup a face detector used specifically for snapshot-based face detection.
  faceDetector = new objectdetect.detector(160, 120, 1.1, objectdetect.frontalface);

  // Instantiate our main class objects for filtering, UI, game logic, and snap filters.
  faceFilter = new FaceFilter(capture, faceDetector);
  faceFilterUI = new FaceFilterUI(cnv, capture);
  faceGame = new FaceGame(capture, detectedFaces, handposePredictions);
  snapFilters = new SnapFilters();

  // Pass the preloaded images into the faceGame instance for usage.
  faceGame.bgImage = bgImage;
  faceGame.protagonist.image = protagonistImg;
  // This object includes arrays of vehicle images for each level.
  faceGame.vehicleImages = {
    1: [AntiqueBlueCarImg, AntiqueGreenCarImg, AntiqueWhiteCarImg],
    2: [whitePickupTruckImg, yellowPickupTruckImg],
    3: [blueContainerTruckImg, whiteContainerTruckImg, yellowDumpTruckImg]
  };

  console.log("Setup complete.");
}

// =====================================================
// draw() – main drawing loop
// =====================================================
function draw() {
  // If the FaceFilterUI is in Snap mode, let it handle all drawing (phone interface).
  if (faceFilterUI.mode === 1) {
    faceFilterUI.drawSnapMode();
    return;
  }
  
  // If no snapshot has been taken yet, show instructions to prompt the user.
  if (!faceFilter.snapshotTaken) {
    faceFilterUI.drawInstructions();
    return;
  }
  
  // If a snapshot is taken, display the Face Filter grid view with all processed images.
  faceFilterUI.drawFaceFilterGrid();

  // If "faceGame" mode is triggered in the Snap interface, that call is handled inside faceFilterUI.
}

// =====================================================
// Global Key & Mouse Handling
// =====================================================
function keyPressed() {
  // The keys '1' to '4' are for face region filters; anything else might be for the game mode.
  if (!(key === '1' || key === '2' || key === '3' || key === '4')) {
    // If the user is on the faceGame start screen, pressing 'S' transitions to the game.
    if (faceGame.startScreen) {
      if (key === 's' || key === 'S') {
        faceGame.startScreen = false;
        console.log("Face game mode started.");
      } else {
        console.log("Press 'S' to start the face game mode.");
      }
      return;
    }
  }
  
  // If we haven't taken a snapshot or haven't detected faces in that snapshot, we cannot apply filters.
  if (!faceFilter.snapshotTaken || faceFilter.detections.length < 1) {
    console.log("No snapshot taken or no faces detected yet.");
    return;
  }
  
  // We'll create a new composite image from the scaled snapshot to apply region-specific filters on faces.
  let compositeImg = faceFilter.snapshotScaled.get();
  for (let i = 0; i < faceFilter.detections.length; i++) {
    // Each detection is in the format [x, y, width, height].
    let face = faceFilter.detections[i];
    let faceX = floor(face[0]);
    let faceY = floor(face[1]);
    let faceW = floor(face[2]);
    let faceH = floor(face[3]);
    // Clamp the face region so it doesn't exceed the image boundaries.
    faceX = max(0, faceX);
    faceY = max(0, faceY);
    if (faceX + faceW > faceFilter.snapshotScaled.width) 
      faceW = faceFilter.snapshotScaled.width - faceX;
    if (faceY + faceH > faceFilter.snapshotScaled.height) 
      faceH = faceFilter.snapshotScaled.height - faceY;
    console.log("Calculated face region (x, y, w, h):", faceX, faceY, faceW, faceH);
    
    // Extract that face region from the snapshot.
    let faceRegion = faceFilter.snapshotScaled.get(faceX, faceY, faceW, faceH);
    
    // Apply a filter depending on which key was pressed (1-4).
    switch (key) {
      case '1':
        console.log("Applying grayscale filter on face region.");
        faceRegion = faceFilter.makeGrayscale(faceRegion);
        break;
      case '2':
        console.log("Applying blur filter on face region.");
        faceRegion = faceFilter.makeBlur(faceRegion, 10);
        break;
      case '3':
        console.log("Converting face region to HSV.");
        faceRegion = faceFilter.convertToHSV(faceRegion);
        break;
      case '4':
        console.log("Applying pixelation on face region.");
        faceRegion = faceFilter.makeGrayscale(faceRegion);
        faceRegion = faceFilter.pixelate(faceRegion, 5, 5);
        break;
      default:
        // If the user pressed something else, we don't apply a filter.
        console.log("No valid key pressed for face replacement.");
        return;
    }
    
    // Copy the processed face region back onto compositeImg at the correct location.
    compositeImg.copy(
      faceRegion, 0, 0, faceRegion.width, faceRegion.height,
      faceX, faceY, faceRegion.width, faceRegion.height
    );
  }
  
  // Store the composite image as 'filteredFaceImg' so it can be displayed in row 4 of the grid.
  faceFilter.filteredFaceImg = compositeImg;
  console.log("Face replacement updated.");
}

function mousePressed() {
  // Pass mouse click handling to faceGame so it can check for restarts.
  faceGame.handleMousePressed();
}
