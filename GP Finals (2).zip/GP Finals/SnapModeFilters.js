// The SnapFilters class contains a collection of custom image filters,
// intended for "Snapchat-style" effects (e.g., ASCII art, kaleidoscope, fisheye).
// Each method takes a p5.js Image (srcImg) and returns a processed version.

class SnapFilters {
  constructor() {
    // The 'delayBuffer' stores a sequence of past frames for the timed delay lens.
    this.delayBuffer = [];
    // 'maxDelay' controls how many frames we keep in memory for the delayed effect.
    this.maxDelay = 10;
  }

  // ====================================================
  // Timed Delay Lens Filter
  // ====================================================
  applyTimedDelayLens(srcImg) {
    // This filter overlays the current frame on top of a buffer of past frames.
    // The oldest frames eventually get dropped once we exceed 'maxDelay'.
    let w = srcImg.width;
    let h = srcImg.height;

    // 'pg' is an offscreen graphics buffer we use to store the current frame.
    let pg = createGraphics(w, h);
    pg.image(srcImg, 0, 0, w, h);

    // We push the new frame into our array, removing the oldest if we exceed maxDelay.
    this.delayBuffer.push(pg.get());
    if (this.delayBuffer.length > this.maxDelay) {
      this.delayBuffer.shift();
    }

    // Create a 'composite' buffer that will combine all these frames.
    let composite = createGraphics(w, h);
    composite.background(0);

    // Blend each stored frame with decreasing opacity to achieve a fading trail effect.
    for (let i = 0; i < this.delayBuffer.length; i++) {
      let alpha = map(i, 0, this.delayBuffer.length - 1, 255, 50);
      composite.tint(255, alpha);
      composite.image(this.delayBuffer[i], 0, 0, w, h);
    }

    return composite;
  }

  // ====================================================
  // Kaleidoscope Filter
  // ====================================================
  applyKaleidoscopeFilter(srcImg) {
    // This creates a kaleidoscopic effect by reflecting angles within a circular region.
    let w = srcImg.width;
    let h = srcImg.height;
    let centerX = w / 2;
    let centerY = h / 2;
    let segments = 6; // We define how many mirrored slices we want.
    let angleStep = TWO_PI / segments;
    let newImg = createImage(w, h);

    srcImg.loadPixels();
    newImg.loadPixels();

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        // Convert pixel (x, y) to polar coordinates (r, theta) around the center.
        let dx = x - centerX;
        let dy = y - centerY;
        let r = sqrt(dx * dx + dy * dy);
        let theta = atan2(dy, dx);
        if (theta < 0) {
          theta += TWO_PI;
        }

        // Reflect the angle within one wedge to replicate it around the circle.
        let newTheta = abs((theta % (angleStep * 2)) - angleStep);

        // Convert back to Cartesian coordinates to sample from the source image.
        let srcX = centerX + r * cos(newTheta);
        let srcY = centerY + r * sin(newTheta);
        let srcXi = floor(srcX);
        let srcYi = floor(srcY);
        let destIndex = (x + y * w) * 4;

        // If it's a valid coordinate, copy that pixel from srcImg; else fill with black.
        if (srcXi >= 0 && srcXi < w && srcYi >= 0 && srcYi < h) {
          let srcIndex = (srcXi + srcYi * w) * 4;
          newImg.pixels[destIndex + 0] = srcImg.pixels[srcIndex + 0];
          newImg.pixels[destIndex + 1] = srcImg.pixels[srcIndex + 1];
          newImg.pixels[destIndex + 2] = srcImg.pixels[srcIndex + 2];
          newImg.pixels[destIndex + 3] = srcImg.pixels[srcIndex + 3];
        } else {
          newImg.pixels[destIndex + 0] = 0;
          newImg.pixels[destIndex + 1] = 0;
          newImg.pixels[destIndex + 2] = 0;
          newImg.pixels[destIndex + 3] = 255;
        }
      }
    }

    newImg.updatePixels();
    return newImg;
  }

  // ====================================================
  // Fisheye Filter
  // ====================================================
  applyFisheyeFilter(srcImg) {
    // This mimics the distortion of a fisheye lens,
    // bending pixels radially outward from the center.
    let w = srcImg.width;
    let h = srcImg.height;
    let centerX = w / 2;
    let centerY = h / 2;
    let newImg = createImage(w, h);

    srcImg.loadPixels();
    newImg.loadPixels();

    // 'k' is a factor controlling how intense the fisheye effect is.
    let k = 0.00001;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let dx = x - centerX;
        let dy = y - centerY;
        let r = sqrt(dx * dx + dy * dy);
        // 'factor' modifies how far we sample from the center based on r.
        let factor = 1 + k * r * r;
        let srcX = centerX + dx / factor;
        let srcY = centerY + dy / factor;
        let srcXi = floor(srcX);
        let srcYi = floor(srcY);
        let index = (x + y * w) * 4;

        // If valid, copy the pixel; otherwise fill black.
        if (srcXi >= 0 && srcXi < w && srcYi >= 0 && srcYi < h) {
          let srcIndex = (srcXi + srcYi * w) * 4;
          newImg.pixels[index + 0] = srcImg.pixels[srcIndex + 0];
          newImg.pixels[index + 1] = srcImg.pixels[srcIndex + 1];
          newImg.pixels[index + 2] = srcImg.pixels[srcIndex + 2];
          newImg.pixels[index + 3] = srcImg.pixels[srcIndex + 3];
        } else {
          newImg.pixels[index + 0] = 0;
          newImg.pixels[index + 1] = 0;
          newImg.pixels[index + 2] = 0;
          newImg.pixels[index + 3] = 255;
        }
      }
    }
    newImg.updatePixels();
    return newImg;
  }

  // ====================================================
  // ASCII Filter
  // ====================================================
  applyAsciiFilter(srcImg) {
    // This filter converts the image into ASCII art,
    // sampling blocks of pixels and mapping brightness to characters.
    let blockSize = 10;
    let asciiChars = ["@", "#", "S", "%", "?", "*", "+", ";", ":", ",", "."];
    let pg = createGraphics(srcImg.width, srcImg.height);
    pg.background(0);
    pg.fill(255);
    pg.textAlign(CENTER, CENTER);
    pg.textSize(blockSize);
    srcImg.loadPixels();

    // We iterate through the image in steps of 'blockSize'.
    for (let y = 0; y < srcImg.height; y += blockSize) {
      for (let x = 0; x < srcImg.width; x += blockSize) {
        let sum = 0, count = 0;
        // Compute average brightness within this block.
        for (let j = 0; j < blockSize; j++) {
          for (let i = 0; i < blockSize; i++) {
            let px = x + i;
            let py = y + j;
            if (px < srcImg.width && py < srcImg.height) {
              let idx = (px + py * srcImg.width) * 4;
              // Weighted brightness for each pixel (luma).
              let lum = 0.299 * srcImg.pixels[idx] +
                        0.587 * srcImg.pixels[idx + 1] +
                        0.114 * srcImg.pixels[idx + 2];
              sum += lum;
              count++;
            }
          }
        }
        let avg = sum / count;
        // Map average brightness to an ASCII character from darkest to brightest.
        let charIndex = floor(map(avg, 0, 255, asciiChars.length - 1, 0));
        let c = asciiChars[charIndex];
        // Draw that character in the center of the block on the pGraphics.
        pg.text(c, x + blockSize / 2, y + blockSize / 2);
      }
    }
    return pg;
  }

  // ====================================================
  // Thermal Filter
  // ====================================================
  applyThermalFilter(srcImg) {
    // This filter recolors the image based on brightness,
    // mimicking a thermal camera palette: from dark blues to bright yellows.
    let thermalImg = createImage(srcImg.width, srcImg.height);
    srcImg.loadPixels();
    thermalImg.loadPixels();
    for (let i = 0; i < srcImg.pixels.length; i += 4) {
      let r = srcImg.pixels[i];
      let g = srcImg.pixels[i + 1];
      let b = srcImg.pixels[i + 2];
      // Approximate brightness by averaging the RGB channels.
      let brightness = (r + g + b) / 3;
      let col;
      // Assign color ranges based on brightness thresholds.
      if (brightness < 64) {
        col = color(0, 0, 128);        // Dark blue
      } else if (brightness < 128) {
        col = color(0, 0, 255);        // Bright blue
      } else if (brightness < 192) {
        col = color(255, 140, 0);      // Orange
      } else {
        col = color(255, 255, 0);      // Yellow
      }
      thermalImg.pixels[i] = red(col);
      thermalImg.pixels[i + 1] = green(col);
      thermalImg.pixels[i + 2] = blue(col);
      thermalImg.pixels[i + 3] = 255;
    }
    thermalImg.updatePixels();
    return thermalImg;
  }

  // ====================================================
  // Insect Filter
  // ====================================================
  applyInsectFilter(srcImg) {
    // Simulates an "insect-like" vision by sampling color blocks
    // and rendering them as circles on a new pGraphics canvas.
    let blockSize = 12;
    let pg = createGraphics(srcImg.width, srcImg.height);
    srcImg.loadPixels();
    pg.noStroke();

    // We process the image in blocks, computing the average RGB for each block.
    for (let y = 0; y < srcImg.height; y += blockSize) {
      for (let x = 0; x < srcImg.width; x += blockSize) {
        let sumR = 0, sumG = 0, sumB = 0, count = 0;
        for (let j = 0; j < blockSize; j++) {
          for (let i = 0; i < blockSize; i++) {
            let px = x + i;
            let py = y + j;
            if (px < srcImg.width && py < srcImg.height) {
              let idx = (px + py * srcImg.width) * 4;
              sumR += srcImg.pixels[idx];
              sumG += srcImg.pixels[idx + 1];
              sumB += srcImg.pixels[idx + 2];
              count++;
            }
          }
        }
        let avgR = sumR / count;
        let avgG = sumG / count;
        let avgB = sumB / count;
        let avgColor = color(avgR, avgG, avgB);
        // Draw each block as a filled ellipse with the block's average color.
        pg.fill(avgColor);
        pg.ellipse(x + blockSize / 2, y + blockSize / 2, blockSize, blockSize);
      }
    }
    return pg;
  }
}
