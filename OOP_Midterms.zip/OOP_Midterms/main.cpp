#include "WeatherApp.h"
#include <iostream>

int main() {
    // Path to the weather data file.
    const std::string dataFilePath = "weather_data_EU_1980-2019_temp_only.csv";

    // Create a WeatherApp object with the data file.
    WeatherApp app(dataFilePath);

    // Run the main application.
    app.run();

    return 0; // Exit the program.
}

