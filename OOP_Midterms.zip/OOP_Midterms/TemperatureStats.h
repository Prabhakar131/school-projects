#pragma once
#include <string>

// Struct to store minimum and maximum temperatures.
struct TemperatureStats {
    double minTemp; // Minimum temperature recorded.
    double maxTemp; // Maximum temperature recorded.
};

// Computes temperature statistics (min and max) for a given country within a date range.
TemperatureStats computeTemperatureStatsInRange(
    const std::string& country,      // Country name for filtering data.
    const std::string& filepath,    // Path to the weather data file.
    const std::string& startDate,   // Start date of the range ("YYYY-MM-DD").
    const std::string& endDate);    // End date of the range ("YYYY-MM-DD").
