// CandlestickComputation.cpp
#include "CandlestickComputation.h"
#include "CSVReader.h"
#include "TemperatureStats.h"
#include <map>
#include <limits>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <iomanip>
#include <sstream>


// Start of my own work //
// Function to compute yearly candlestick data 
std::vector<Candlestick> computeCandlestickData(
    const std::string& country,
    const std::string& filepath,
    const std::string& startDate,
    const std::string& endDate,
    double minTemp, // Represents the full range; no early filtering
    double maxTemp) {
    
    auto data = CSVReader::readCSV(filepath);

    if (data.empty()) {
        std::cerr << "Error: Failed to read data from file: " << filepath << "\n";
        return {};
    }

    // Extract header and identify the column index for the country
    const auto& header = data.front();
    int countryIndex = -1;
    std::string tempColumn = country + "_temperature";
    for (size_t i = 0; i < header.size(); ++i) {
        if (header[i] == tempColumn) {
            countryIndex = static_cast<int>(i);
            break;
        }
    }

    if (countryIndex == -1) {
        std::cerr << "Error: Temperature column for country " << country << " not found.\n";
        return {};
    }

    // Adjust startDate to include the previous year
    std::string adjustedStartDate = startDate;
    if (!startDate.empty()) {
        try {
            int year = std::stoi(startDate.substr(0, 4));
            adjustedStartDate = std::to_string(year - 1); // Include previous year
        } catch (...) {
            std::cerr << "Error: Invalid start year format.\n";
            return {};
        }
    }

    // Sort data chronologically 
    std::sort(data.begin() + 1, data.end(), [](const std::vector<std::string>& a, const std::vector<std::string>& b) -> bool {
        return a[0] < b[0];
    });

    // Process data rows and group temperatures by year
    std::map<int, std::vector<double>> filteredData; 
    for (size_t i = 1; i < data.size(); ++i) { 
        const auto& row = data[i];
        if (row.size() <= static_cast<size_t>(countryIndex)) {
            std::cerr << "Warning: Incomplete data at row " << i + 1 << ". Skipping.\n";
            continue;
        }

        std::string date = row[0];
        if (date.size() < 10) { // Ensure full date format YYYY-MM-DD
            std::cerr << "Warning: Invalid date format at row " << i + 1 << ". Skipping.\n";
            continue;
        }
        std::string yearStr = date.substr(0, 4); // Extract YYYY
        int year = 0;

        // Convert year string to integer
        try {
            year = std::stoi(yearStr);
        } catch (...) {
            std::cerr << "Warning: Invalid year value at row " << i + 1 << ": " << yearStr << ". Skipping.\n";
            continue;
        }

        double temperature = 0.0;

        // Parse temperature with error handling
        try {
            temperature = std::stod(row[countryIndex]);
        } catch (...) {
            std::cerr << "Warning: Invalid temperature value at row " << i + 1 << ". Skipping.\n";
            continue;
        }

        // Apply date filters
        if (!adjustedStartDate.empty()) {
            int startYear = 0;
            try {
                startYear = std::stoi(adjustedStartDate);
            } catch (...) {
                std::cerr << "Error: Invalid adjusted start year format.\n";
                return {};
            }
            if (year < startYear) continue;
        }
        if (!endDate.empty()) {
            int endYear = 0;
            try {
                endYear = std::stoi(endDate.substr(0, 4));
            } catch (...) {
                std::cerr << "Error: Invalid end year format.\n";
                return {};
            }
            if (year > endYear) continue; 
        }

        // Group data by year
        filteredData[year].push_back(temperature);
    }

    // Compute yearly candlesticks
    std::vector<Candlestick> candlesticks;
    double previousClose = 0.0;

    // Extract and sort years in chronological order
    std::vector<int> sortedYears;
    for (const auto& [year, temps] : filteredData) {
        sortedYears.emplace_back(year);
    }
    std::sort(sortedYears.begin(), sortedYears.end());

    for (const auto& year : sortedYears) {
        const auto& temperatures = filteredData[year];
        if (temperatures.empty()) continue;

        double high = *std::max_element(temperatures.begin(), temperatures.end());
        double low = *std::min_element(temperatures.begin(), temperatures.end());
        double close = std::accumulate(temperatures.begin(), temperatures.end(), 0.0) / temperatures.size();

        // Set open to the previous year's close if available, otherwise default to 0.0
        double open = (previousClose != 0.0) ? previousClose : 0.0;

        Candlestick candle(std::to_string(year), open, high, low, close);
        candlesticks.emplace_back(candle);

        // Update previousClose to the current year's close
        previousClose = close;
    }

    // Filter out the extra year added for previousClose computation
    std::vector<Candlestick> filteredCandlesticks;
    for (const auto& candle : candlesticks) {
        if (candle.date >= startDate) {
            filteredCandlesticks.push_back(candle);
        }
    }

    // No temperature filtering here

    return filteredCandlesticks;
}
// End of my own work



// Helper function to parse date strings
std::tm parseDate(const std::string& dateStr) {
    std::tm tm_date = {};
    std::istringstream ss(dateStr);
    ss >> std::get_time(&tm_date, "%Y-%m-%d");
    if (ss.fail()) {
        throw std::invalid_argument("Invalid date format: " + dateStr);
    }
    tm_date.tm_isdst = -1; // Not considering daylight saving time
    return tm_date;
}

// Helper function to add days to a date
std::tm addDays(const std::tm& date, int days) {
    std::tm tm_new = date;
    std::time_t time = std::mktime(&tm_new);
    if (time == -1) {
        throw std::invalid_argument("Failed to convert date to time_t");
    }
    time += days * 24 * 60 * 60; // Add days in seconds
    std::tm* new_tm = std::localtime(&time);
    if (!new_tm) {
        throw std::invalid_argument("Failed to convert time_t back to std::tm");
    }
    return *new_tm;
}

std::vector<Candlestick> computeWeeklyCandlestickData(
    const std::string& country,
    const std::string& filepath,
    const std::string& startWeek, // Expected format: "YYYY-WW"
    const std::string& endWeek,   // Expected format: "YYYY-WW"
    double minTemp, 
    double maxTemp) {
    
    auto data = CSVReader::readCSV(filepath);
    std::vector<Candlestick> weeklyCandlesticks;
    double previousClose = 0.0;
    bool previousCloseSet = false;
    std::string currentWeekStr = "";
    std::vector<double> currentWeekTemps;
    int weekCounter = 1; // Sequential week number within the year

    if (data.empty()) {
        std::cerr << "Error: Failed to read data from file: " << filepath << "\n";
        return weeklyCandlesticks;
    }

    // Extract header and find the temperature column
    const auto& header = data.front();
    int tempIndex = -1;
    std::string tempColumn = country + "_temperature";
    for (size_t i = 0; i < header.size(); ++i) {
        if (header[i] == tempColumn) {
            tempIndex = static_cast<int>(i);
            break;
        }
    }

    if (tempIndex == -1) {
        std::cerr << "Error: Temperature column for country " << country << " not found.\n";
        return weeklyCandlesticks;
    }

    // Sort data chronologically
    std::sort(data.begin() + 1, data.end(), [](const std::vector<std::string>& a, const std::vector<std::string>& b) -> bool {
        return a[0] < b[0];
    });

    // Initialize variables for week grouping
    for (size_t i = 1; i < data.size(); ++i) { // Skip header
        const auto& row = data[i];
        if (row.size() <= static_cast<size_t>(tempIndex)) {
            continue; 
        }

        std::string dateStr = row[0];
        double temp = 0.0;

        // Parse temperature with error handling
        try {
            temp = std::stod(row[tempIndex]);
        } catch (...) {
            continue; // Invalid temperature, skip
        }

        // No early temperature filtering here

        // Parse the date
        std::tm dateTm;
        try {
            dateTm = parseDate(dateStr);
        }
        catch (...) {
            continue; // Invalid date, skip
        }

        // Compute day of year
        int dayOfYear = dateTm.tm_yday + 1; // tm_yday is 0-based

        // Compute week number
        int weekNum = (dayOfYear - 1) / 7 + 1;

        // Assign week identifier as "YYYY-WW"
        std::ostringstream oss;
        oss << (dateTm.tm_year + 1900) << "-";
        if (weekNum < 10) oss << "0";
        oss << weekNum;
        std::string weekStr = oss.str();

        if (currentWeekStr.empty()) {
            // Initialize first week
            currentWeekStr = weekStr;
            currentWeekTemps.push_back(temp);
            continue;
        }

        if (weekStr == currentWeekStr) {
            // Same week, accumulate temperature
            currentWeekTemps.push_back(temp);
        }
        else {
            // New week, process the previous week
            if (!currentWeekTemps.empty()) {
                // Compute weekly statistics
                double sum = std::accumulate(currentWeekTemps.begin(), currentWeekTemps.end(), 0.0);
                double mean = sum / currentWeekTemps.size();
                double high = *std::max_element(currentWeekTemps.begin(), currentWeekTemps.end());
                double low = *std::min_element(currentWeekTemps.begin(), currentWeekTemps.end());

                // Assign open value
                double open = (previousCloseSet) ? previousClose : 0.0;

                // Create candlestick
                Candlestick candle(currentWeekStr, open, high, low, mean);
                weeklyCandlesticks.emplace_back(candle);

                // Update previousClose
                previousClose = mean;
                previousCloseSet = true;
            }

            // Reset for the new week
            currentWeekStr = weekStr;
            currentWeekTemps.clear();
            currentWeekTemps.push_back(temp);
        }
    }

    // Handle the last week after the loop ends
    if (!currentWeekTemps.empty()) {
        double sum = std::accumulate(currentWeekTemps.begin(), currentWeekTemps.end(), 0.0);
        double mean = sum / currentWeekTemps.size();
        double high = *std::max_element(currentWeekTemps.begin(), currentWeekTemps.end());
        double low = *std::min_element(currentWeekTemps.begin(), currentWeekTemps.end());

        // Assign open value
        double open = (previousCloseSet) ? previousClose : 0.0;

        // Create candlestick
        Candlestick candle(currentWeekStr, open, high, low, mean);
        weeklyCandlesticks.emplace_back(candle);

        // Update previousClose
        previousClose = mean;
        previousCloseSet = true;
    }

    // Filter candlesticks based on startWeek and endWeek if provided
    std::vector<Candlestick> filteredCandlesticks;
    for (const auto& candle : weeklyCandlesticks) {
        bool withinStart = startWeek.empty() || candle.date >= startWeek;
        bool withinEnd = endWeek.empty() || candle.date <= endWeek;
        if (withinStart && withinEnd) {
            filteredCandlesticks.emplace_back(candle);
        }
    }

    return filteredCandlesticks; 
}

std::vector<Candlestick> computeMonthlyCandlestickData(
    const std::string& country,
    const std::string& filepath,
    const std::string& startDate, 
    const std::string& endDate,   
    double minTemp, 
    double maxTemp) {
    
    auto data = CSVReader::readCSV(filepath);
    std::vector<Candlestick> monthlyCandlesticks;
    double previousClose = 0.0;
    std::string currentMonth = "";
    std::vector<double> temps;

    if (data.empty()) {
        std::cerr << "Error: Failed to read data from file: " << filepath << "\n";
        return {};
    }

    // Extract header and identify the temperature column (dynamic indexing)
    const auto& header = data.front();
    int tempIndex = -1;
    std::string tempColumn = country + "_temperature";
    for (size_t i = 0; i < header.size(); ++i) {
        if (header[i] == tempColumn) {
            tempIndex = static_cast<int>(i);
            break;
        }
    }

    if (tempIndex == -1) {
        std::cerr << "Error: Temperature column for country " << country << " not found.\n";
        return {};
    }

    // Adjust startDate to include the previous month
    std::string adjustedStartDate = startDate;
    if (!startDate.empty()) {
        try {
            int year = std::stoi(startDate.substr(0, 4));
            int month = std::stoi(startDate.substr(5, 2));
            if (--month == 0) { // Handle January edge case
                month = 12;
                year--;
            }
            adjustedStartDate = std::to_string(year) + "-" + (month < 10 ? "0" : "") + std::to_string(month);
        } catch (...) {
            std::cerr << "Error: Invalid start date format.\n";
            return {};
        }
    }

    // Sort data chronologically (assuming date is in YYYY-MM-DD format)
    std::sort(data.begin() + 1, data.end(), [](const std::vector<std::string>& a, const std::vector<std::string>& b) -> bool {
        return a[0] < b[0];
    });

    for (size_t i = 1; i < data.size(); ++i) { // Start from 1 to skip header
        const auto& row = data[i];
        if (row.size() <= static_cast<size_t>(tempIndex)) {
            std::cerr << "Warning: Incomplete data at row " << i + 1 << ". Skipping.\n";
            continue;
        }

        std::string date = row[0];
        if (date.size() < 7) { // Ensure date has at least YYYY-MM
            std::cerr << "Warning: Invalid date format at row " << i + 1 << ". Skipping.\n";
            continue;
        }
        std::string monthStr = date.substr(0, 7); // Extract YYYY-MM
        int month = 0;

        // Convert month string to integer (e.g., 2012-05 to 201205)
        try {
            std::string combined = date.substr(0, 4) + date.substr(5, 2);
            month = std::stoi(combined);
        } catch (...) {
            std::cerr << "Warning: Invalid month value at row " << i + 1 << ": " << date.substr(0, 7) << ". Skipping.\n";
            continue;
        }

        double temp = 0.0;

        // Parse temperature with error handling
        try {
            temp = std::stod(row[tempIndex]);
        } catch (...) {
            std::cerr << "Warning: Invalid temperature value at row " << i + 1 << ". Skipping.\n";
            continue;
        }

        // Apply date filters
        if (!adjustedStartDate.empty() && monthStr < adjustedStartDate) continue;
        if (!endDate.empty() && monthStr > endDate) continue;
        // No early temperature filtering here

        // Check if we've moved to a new month
        if (monthStr != currentMonth && currentMonth != "") {
            if (!temps.empty()) {
                // Compute high, low, and close for the previous month
                double high = *std::max_element(temps.begin(), temps.end());
                double low = *std::min_element(temps.begin(), temps.end());
                double close = std::accumulate(temps.begin(), temps.end(), 0.0) / temps.size();

                // Set open to previousClose if it's been set; otherwise, use 0.0
                double open = (previousClose != 0.0) ? previousClose : 0.0;
                Candlestick candle(currentMonth, open, high, low, close);
                monthlyCandlesticks.emplace_back(candle);

                // Update previousClose
                previousClose = close;
            }
            temps.clear();
        }

        currentMonth = monthStr;
        temps.push_back(temp);
    }

    // Handle the last month after the loop ends
    if (currentMonth != "" && !temps.empty()) {
        double high = *std::max_element(temps.begin(), temps.end());
        double low = *std::min_element(temps.begin(), temps.end());
        double close = std::accumulate(temps.begin(), temps.end(), 0.0) / temps.size();

        // Set open to previousClose if it's been set; otherwise, use 0.0
        double open = (previousClose != 0.0) ? previousClose : 0.0;
        Candlestick candle(currentMonth, open, high, low, close);
        monthlyCandlesticks.emplace_back(candle);

        // Update previousClose
        previousClose = close;
    }

    // Filter out the extra month added for previousClose computation
    std::vector<Candlestick> filteredCandlesticks;
    for (const auto& candle : monthlyCandlesticks) {
        if (candle.date >= startDate) {
            filteredCandlesticks.push_back(candle);
        }
    }

    return filteredCandlesticks;
}

