#include "TemperatureStats.h"
#include "Candlestick.h"
#include "CSVReader.h"
#include <algorithm>
#include <iostream>
#include <vector>
#include <map>
#include <numeric>
#include <iomanip>
#include <sstream>
#include <ctime>
#include <limits>


// Filters candlesticks based on a temperature range.
// Returns candlesticks where all temperatures (high and low) fall within the range.
std::vector<Candlestick> filterCandlesticksByTemperature(
    const std::vector<Candlestick>& candlesticks, // Input list of candlesticks.
    double minTemp,                               // Minimum temperature threshold.
    double maxTemp) {                             // Maximum temperature threshold.
    
    std::vector<Candlestick> filteredCandlesticks; // Stores the filtered candlesticks.
    
    // Iterate through the candlesticks and filter by temperature range.
    for (const auto& candle : candlesticks) {
        if (candle.high <= maxTemp && candle.low >= minTemp) {
            filteredCandlesticks.emplace_back(candle); // Add valid candlestick to results.
        }
    }
    
    return filteredCandlesticks; // Return the filtered candlesticks.
}


// Start of my own work 
// Computes min and max temperature stats for a given country within a date range.
TemperatureStats computeTemperatureStatsInRange(
    const std::string& country,      // Country name for filtering data.
    const std::string& filepath,    // Path to the weather data CSV file.
    const std::string& startDate,   // Start date of the range ("YYYY-MM-DD").
    const std::string& endDate) {   // End date of the range ("YYYY-MM-DD").
    
    // Read the CSV data.
    auto data = CSVReader::readCSV(filepath);
    TemperatureStats stats;
    stats.minTemp = std::numeric_limits<double>::max();    // Initialize min temperature.
    stats.maxTemp = std::numeric_limits<double>::lowest(); // Initialize max temperature.

    if (data.empty()) { // Handle empty data.
        std::cerr << "Error: CSV data is empty.\n";
        return stats;
    }

    // Extract header to find the column index for the country's temperature data.
    const auto& header = data.front();
    int countryIndex = -1;
    std::string tempColumn = country + "_temperature";
    for (size_t i = 0; i < header.size(); ++i) {
        if (header[i] == tempColumn) {
            countryIndex = static_cast<int>(i);
            break;
        }
    }

    // If the column is not found, log an error and return.
    if (countryIndex == -1) {
        std::cerr << "Error: Temperature column for country " << country << " not found.\n";
        return stats;
    }

    // Sort the data chronologically (skipping the header).
    std::sort(data.begin() + 1, data.end(), [&](const std::vector<std::string>& a, const std::vector<std::string>& b) -> bool {
        return a[0] < b[0];
    });

    // Process each row in the CSV.
    for (size_t i = 1; i < data.size(); ++i) { // Skip the header row.
        const auto& row = data[i];
        if (row.size() <= static_cast<size_t>(countryIndex)) continue; // Skip invalid rows.

        std::string date = row[0];
        std::string tempStr = row[countryIndex];
        double temp = 0.0;

        // Parse temperature safely.
        try {
            temp = std::stod(tempStr);
        } catch (...) {
            continue; // Skip rows with invalid temperature values.
        }

        // Check if the date falls within the specified range.
        if (!startDate.empty() && date < startDate) continue;
        if (!endDate.empty() && date > endDate) continue;

        // Update min and max temperatures.
        stats.minTemp = std::min(stats.minTemp, temp);
        stats.maxTemp = std::max(stats.maxTemp, temp);
    }

    // Handle cases where no valid temperature data was found.
    if (stats.minTemp == std::numeric_limits<double>::max() ||
        stats.maxTemp == std::numeric_limits<double>::lowest()) {
        std::cerr << "Warning: No valid temperature data found for country " << country 
                  << " within the specified date range.\n";
        stats.minTemp = 0.0;
        stats.maxTemp = 0.0;
    }

    return stats; // Return the computed temperature statistics.
}

// Predicts temperatures for a range of years using a linear regression model.
// Returns candlesticks with predicted temperature values.
std::vector<Candlestick> predictTemperatures(
    const std::vector<int>& predictionYears, // List of years to predict temperatures for.
    double slope,                            // Slope of the linear regression model.
    double intercept) {                      // Intercept of the linear regression model.
    
    std::vector<Candlestick> predictedCandlesticks;

    // Generate predicted candlesticks for each year.
    for (int year : predictionYears) {
        double predictedTemp = slope * year + intercept; // Linear prediction.
        Candlestick predictedCandle(                    // Create a candlestick with the same temp for all fields.
            std::to_string(year), predictedTemp, predictedTemp, predictedTemp, predictedTemp);
        predictedCandlesticks.push_back(predictedCandle);
    }

    return predictedCandlesticks; // Return the list of predicted candlesticks.
}
// End of my own work