#include "Candlestick.h"
#include "TemperatureStats.h"
#include <vector>
#include <string>
#include <limits> 

// Computes yearly candlestick data for a given country and date range.
// Filters data based on start date, end date, and temperature range.
std::vector<Candlestick> computeCandlestickData(
    const std::string& country,              // Country name for filtering data.
    const std::string& filepath,            // Path to the weather data file.
    const std::string& startDate = "",      // start date ("YYYY-MM-DD").
    const std::string& endDate = "",        // end date ("YYYY-MM-DD").
    double minTemp = std::numeric_limits<double>::lowest(), // Minimum temperature filter.
    double maxTemp = std::numeric_limits<double>::max());   // Maximum temperature filter.

// Computes weekly candlestick data for a specific country.
// Filters data by date range and temperature limits.
std::vector<Candlestick> computeWeeklyCandlestickData(
    const std::string& country,              // Country name for filtering data.
    const std::string& filepath,            // Path to the weather data file.
    const std::string& startDate = "",      // start date ("YYYY-MM-DD").
    const std::string& endDate = "",        // end date ("YYYY-MM-DD").
    double minTemp = std::numeric_limits<double>::lowest(), // Minimum temperature filter.
    double maxTemp = std::numeric_limits<double>::max());   // Maximum temperature filter.

// Computes monthly candlestick data for a specific country.
// Filters data by date range and temperature limits.
std::vector<Candlestick> computeMonthlyCandlestickData(
    const std::string& country,              // Country name for filtering data.
    const std::string& filepath,            // Path to the weather data file.
    const std::string& startDate = "",      // start date ("YYYY-MM-DD").
    const std::string& endDate = "",        // end date ("YYYY-MM-DD").
    double minTemp = std::numeric_limits<double>::lowest(), // Minimum temperature filter.
    double maxTemp = std::numeric_limits<double>::max());   // Maximum temperature filter.

// Filters candlesticks by temperature range.
// Returns candlesticks with temperatures within the specified range.
std::vector<Candlestick> filterCandlesticksByTemperature(
    const std::vector<Candlestick>& candlesticks, // Input candlesticks to filter.
    double minTemp,                               // Minimum temperature threshold.
    double maxTemp);                              // Maximum temperature threshold.

// Computes temperature statistics (min and max) within a specified date range for a given country.
TemperatureStats computeTemperatureStatsInRange(
    const std::string& country,      // Country name for filtering data.
    const std::string& filepath,    // Path to the weather data file.
    const std::string& startDate,   // Start date of the range ("YYYY-MM-DD").
    const std::string& endDate);    // End date of the range ("YYYY-MM-DD").
