#include <string>
#include <vector>

// A utility class for reading CSV files.
class CSVReader {
public:
    // Reads a CSV file and returns its content as a 2D vector of strings.
    static std::vector<std::vector<std::string>> readCSV(const std::string& filepath); // File path to the CSV file.
};
