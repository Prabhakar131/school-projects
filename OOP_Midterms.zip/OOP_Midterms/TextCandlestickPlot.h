#pragma once
#include "Candlestick.h"
#include <vector>
#include <string>

class TextCandlestickPlot {
public:
    // Constructor
    TextCandlestickPlot(const std::vector<Candlestick>& data, int plotHeight = 20);

    // Method to plot candlestick data
    void plotCandlestickData() const;
    void displayLegend() const;

private:
    std::vector<Candlestick> candlesticks;
    int height;

    // Helper method to clamp values within a range
    int clamp_custom(int value, int min, int max) const;

    // Helper method to extract labels based on date format
    std::string extractLabel(const std::string& date) const;
};
