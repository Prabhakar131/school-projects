#include "WeatherApp.h"
#include "CandlestickComputation.h"
#include "TextCandlestickPlot.h"
#include "TemperatureStats.h"
#include "CSVReader.h"
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>      
#include <limits>      
#include <algorithm>    
#include <numeric>
#include <cmath>
#include <sstream>



// Computes the slope and intercept of a linear regression model.
// Uses the least-squares method on input data vectors x and y.
RegressionParams linearRegression(
    const std::vector<double>& x, // Independent variable data points.
    const std::vector<double>& y  // Dependent variable data points.
) {
    RegressionParams params = {0.0, 0.0}; // Initialize slope and intercept.
    size_t n = x.size();
    
    // Return default params if input vectors are empty or mismatched.
    if (n == 0 || y.size() != n) return params;

    // Calculate sums required for the regression formula.
    double sum_x = std::accumulate(x.begin(), x.end(), 0.0);
    double sum_y = std::accumulate(y.begin(), y.end(), 0.0);
    double sum_xy = 0.0;
    double sum_x2 = 0.0;

    // Compute the sum of products and squares.
    for (size_t i = 0; i < n; ++i) {
        sum_xy += x[i] * y[i];
        sum_x2 += x[i] * x[i];
    }

    // Calculate the denominator for the slope formula.
    double denominator = (n * sum_x2 - sum_x * sum_x);
    
    // Handle case where denominator is zero (vertical line case).
    if (denominator == 0) {
        params.slope = 0.0;
        params.intercept = sum_y / n; // Set intercept as the mean of y.
        return params;
    }

    // Calculate slope and intercept using the regression formula.
    params.slope = (n * sum_xy - sum_x * sum_y) / denominator;
    params.intercept = (sum_y - params.slope * sum_x) / n;

    return params; // Return the regression parameters.
}


// Computes accuracy metrics (MAE and RMSE) for model predictions.
// Compares actual values with predicted values.
AccuracyMetrics computeAccuracyMetrics(
    const std::vector<double>& actual,    // Actual observed values.
    const std::vector<double>& predicted // Predicted values from the model.
) {
    AccuracyMetrics metrics = {0.0, 0.0}; // Initialize metrics to zero.
    size_t n = actual.size();

    // Return default metrics if input vectors are empty or mismatched.
    if (n == 0 || predicted.size() != n) return metrics;

    double sum_abs_error = 0.0;      // Sum of absolute errors for MAE.
    double sum_squared_error = 0.0; // Sum of squared errors for RMSE.

    // Calculate absolute and squared errors for each data point.
    for (size_t i = 0; i < n; ++i) {
        double error = actual[i] - predicted[i];
        sum_abs_error += std::abs(error);
        sum_squared_error += error * error;
    }

    // Compute the final metrics.
    metrics.mae = sum_abs_error / n;               // Mean Absolute Error (MAE).
    metrics.rmse = std::sqrt(sum_squared_error / n); // Root Mean Squared Error (RMSE).

    return metrics; // Return the calculated accuracy metrics.
}


// Converts date strings into sequential numbers for indexing in linear regression.
// Supports conversion for yearly, monthly, and weekly candlestick types.
int dateToSequential(const std::string& dateStr, const std::string& candlestickType) {
    if (candlestickType == "year") {
        // Extract and return the year as an integer.
        try {
            return std::stoi(dateStr.substr(0, 4));
        } catch (...) {
            return 0; // Return 0 for invalid date formats.
        }
    }
    else if (candlestickType == "month") {
        // Convert year and month to a sequential number (e.g., "YYYY-MM").
        try {
            int year = std::stoi(dateStr.substr(0, 4));
            int month = std::stoi(dateStr.substr(5, 2));
            return year * 12 + month;
        } catch (...) {
            return 0; // Return 0 for invalid date formats.
        }
    }
    else if (candlestickType == "week") {
        // Convert year and week to a sequential number (e.g., "YYYY-WW").
        try {
            int year = std::stoi(dateStr.substr(0, 4));
            int week = std::stoi(dateStr.substr(5, 2));
            return year * 53 + week; // Assuming up to 53 weeks in a year.
        } catch (...) {
            return 0; // Return 0 for invalid date formats.
        }
    }
    return 0; // Return 0 for unsupported candlestick types.
}


// Prints a comparison table of actual vs. predicted candlestick data.
void printComparison(
    const std::vector<Candlestick>& actual,    // Vector of actual candlestick data.
    const std::vector<Candlestick>& predicted // Vector of predicted candlestick data.
) {
    std::cout << std::fixed << std::setprecision(5); // Set decimal precision for output.
    std::cout << "\nComparison of Actual vs Predicted Candlestick Data:\n";

    // Print the table header.
    std::cout << std::left << std::setw(12) << "Date"
              << std::right << std::setw(12) << "Actual_Open"
              << std::setw(12) << "Pred_Open"
              << std::setw(12) << "Actual_High"
              << std::setw(12) << "Pred_High"
              << std::setw(12) << "Actual_Low"
              << std::setw(12) << "Pred_Low"
              << std::setw(12) << "Actual_Close"
              << std::setw(12) << "Pred_Close" << "\n";

    // Print a separator line.
    std::cout << std::left << std::setw(12) << "------------"
              << std::right << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------"
              << std::setw(12) << "------------" << "\n";

    // Iterate over candlestick data and print each comparison row.
    size_t n = actual.size();
    for (size_t i = 0; i < n; ++i) {
        std::cout << std::left << std::setw(12) << actual[i].date
                  << std::right << std::setw(12) << actual[i].open
                  << std::setw(12) << predicted[i].open
                  << std::setw(12) << actual[i].high
                  << std::setw(12) << predicted[i].high
                  << std::setw(12) << actual[i].low
                  << std::setw(12) << predicted[i].low
                  << std::setw(12) << actual[i].close
                  << std::setw(12) << predicted[i].close << "\n";
    }
}


// WeatherApp Class Implementation

// Constructor
WeatherApp::WeatherApp(const std::string& dataFilePath)
    : m_dataFilePath(dataFilePath)
{
}

// Main loop
void WeatherApp::run() {
    while (true) {
        // Display task menu
        std::cout << "\nSelect a task to perform:\n";
        std::cout << "1. Compute candlestick data (Task 1)\n";
        std::cout << "2. Create text-based plot of candlestick data (Task 2)\n";
        std::cout << "3. Filter data and plot using text (Task 3)\n";
        std::cout << "4. Predict data and plot (Task 4)\n";
        std::cout << "5. Exit\n";
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice;

        // Validate user input
        if (std::cin.fail() || choice < 1 || choice > 5) {
            std::cerr << "Invalid input. Please enter a number between 1 and 5.\n";
            std::cin.clear(); // Clear error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
            continue;
        }

        // Perform selected task
        switch (choice) {
            case 1:
                task1();
                break;
            case 2:
                task2();
                break;
            case 3:
                task3();
                break;
            case 4:
                task4();
                break;
            case 5:
                std::cout << "Exiting program. Goodbye!\n";
                return;
            default:
                std::cerr << "Unexpected error.\n";
        }
    }
}

// Helper Methods 

// Computes the minimum and maximum temperatures for a given country using a CSV file.
TemperatureStats WeatherApp::computeTemperatureStats(
    const std::string& country,      // Country name for filtering data.
    const std::string& filepath) {  // Path to the CSV file containing weather data.
    
    // Read the CSV data.
    auto data = CSVReader::readCSV(filepath);
    TemperatureStats stats;
    stats.minTemp = std::numeric_limits<double>::max();    // Initialize min temperature.
    stats.maxTemp = std::numeric_limits<double>::lowest(); // Initialize max temperature.

    // Return default stats if the data is empty.
    if (data.empty()) {
        std::cerr << "Error: CSV data is empty.\n";
        return stats;
    }

    // Extract header and locate the temperature column for the specified country.
    const auto& header = data.front();
    int countryIndex = -1;
    std::string tempColumn = country + "_temperature";
    for (size_t i = 0; i < header.size(); ++i) {
        if (header[i] == tempColumn) {
            countryIndex = static_cast<int>(i);
            break;
        }
    }

    // If the temperature column is not found, log an error and return.
    if (countryIndex == -1) {
        std::cerr << "Error: Temperature column for country " << country << " not found.\n";
        return stats;
    }

    // Traverse the data to find the minimum and maximum temperatures.
    for (size_t i = 1; i < data.size(); ++i) { // Skip the header row.
        const auto& row = data[i];
        
        // Skip rows with missing or incomplete data.
        if (row.size() <= static_cast<size_t>(countryIndex)) continue;

        std::string tempStr = row[countryIndex];
        try {
            double temp = std::stod(tempStr); // Convert the temperature string to a double.
            stats.minTemp = std::min(stats.minTemp, temp);
            stats.maxTemp = std::max(stats.maxTemp, temp);
        } catch (const std::invalid_argument&) {
            // Handle invalid temperature values (non-numeric).
            continue;
        } catch (const std::out_of_range&) {
            // Handle temperature values that are out of range.
            continue;
        }
    }

    // Handle cases where no valid temperatures were found.
    if (stats.minTemp == std::numeric_limits<double>::max() ||
        stats.maxTemp == std::numeric_limits<double>::lowest()) {
        std::cerr << "Warning: No valid temperature data found for country " << country << ".\n";
        stats.minTemp = 0.0;
        stats.maxTemp = 0.0;
    }

    return stats; // Return the computed temperature statistics.
}

// Helper function to print candlestick data with consistent formatting
void WeatherApp::printCandlestickData(const std::vector<Candlestick>& candlesticks, int precision) {
    // Set fixed-point notation and precision
    std::cout << std::fixed << std::setprecision(precision);

    // Print headers with left alignment for "Date" and right alignment for numerical columns
    std::cout << std::left << std::setw(12) << "Date"
              << std::right << std::setw(12) << "Open"
              << std::setw(12) << "High"
              << std::setw(12) << "Low"
              << std::setw(12) << "Close" << "\n";

    // Print separator line for better readability
    std::cout << std::left << std::setw(12) << "-------------"
              << std::right << std::setw(12) << "-------------"
              << std::setw(12) << "-------------"
              << std::setw(12) << "-------------"
              << std::setw(12) << "-------------" << "\n";

    // Iterate through each candlestick and print the data with proper alignment
    for (const auto& candle : candlesticks) {
        std::cout << std::left << std::setw(12) << candle.date << " "    // Left-align "Date"
                  << std::right << std::setw(12) << candle.open << " "    // Right-align numerical data
                  << std::setw(12) << candle.high << " "
                  << std::setw(12) << candle.low << " "
                  << std::setw(12) << candle.close << "\n";
    }
}

// Task Implementations 

/**
 * Task 1: Compute candlestick data and print it.
 */
void WeatherApp::task1() {
    // You can change the file path if desired:
    // If you prefer using the path passed to the constructor, replace with m_dataFilePath
    const std::string filepath = m_dataFilePath;

    // List of countries
    std::vector<std::string> countries = {
        "AT", "BE", "BG", "CH", "CZ", "DE", "DK", "EE", "ES", "FI",
        "FR", "GB", "GR", "HR", "HU", "IE", "IT", "LT", "LU", "LV",
        "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK"
    };

    // Print available countries
    std::cout << "Available Countries:\n";
    for (size_t i = 0; i < countries.size(); ++i) {
        std::cout << i + 1 << ". " << countries[i] << "\n";
    }

    // Prompt the user to select a country
    int choice;
    std::cout << "Enter the number corresponding to your choice: ";
    std::cin >> choice;

    // Validate user input
    if (std::cin.fail() || choice < 1 || choice > static_cast<int>(countries.size())) {
        std::cerr << "Invalid selection. Exiting.\n";
        // Clear the error flag and ignore the rest of the input buffer
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    std::string country = countries[choice - 1];

    // Compute candlestick data without any filters (use the full temperature range)
    std::vector<Candlestick> candlesticks = computeCandlestickData(
        country,
        filepath,
        "", // startDate
        "", // endDate
        std::numeric_limits<double>::lowest(), // minTemp (no filter)
        std::numeric_limits<double>::max()     // maxTemp (no filter)
    );

    if (candlesticks.empty()) {
        std::cerr << "Failed to compute candlestick data for country: " << country << ". Exiting.\n";
        return;
    }

    // Print candlestick data with proper alignment using the helper function
    std::cout << "\nCandlestick Data:\n";
    printCandlestickData(candlesticks, 5); // Precision set to 5 decimal places
}

/**
 * Task 2: Create text-based plot of candlestick data
 */
void WeatherApp::task2() {
    const std::string filepath = m_dataFilePath;

    // List of countries
    std::vector<std::string> countries = {
        "AT", "BE", "BG", "CH", "CZ", "DE", "DK", "EE", "ES", "FI",
        "FR", "GB", "GR", "HR", "HU", "IE", "IT", "LT", "LU", "LV",
        "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK"
    };

    // Print available countries
    std::cout << "\nAvailable Countries:\n";
    for (size_t i = 0; i < countries.size(); ++i) {
        std::cout << i + 1 << ". " << countries[i] << "\n";
    }

    // Prompt the user to select a country
    int countryChoice;
    std::cout << "Enter the number corresponding to your choice: ";
    std::cin >> countryChoice;

    // Validate country choice
    if (std::cin.fail() || countryChoice < 1 || countryChoice > static_cast<int>(countries.size())) {
        std::cerr << "Invalid input. Please select a valid country.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    std::string selectedCountry = countries[countryChoice - 1];
    std::cout << "\nYou selected: " << selectedCountry << "\n";

    // Compute candlestick data without any filters (use the full temperature range)
    std::vector<Candlestick> candlesticks = computeCandlestickData(
        selectedCountry,
        filepath,
        "", // startDate
        "", // endDate
        std::numeric_limits<double>::lowest(), // minTemp (no filter)
        std::numeric_limits<double>::max()     // maxTemp (no filter)
    );

    if (candlesticks.empty()) {
        std::cerr << "Failed to compute candlestick data for the selected country.\n";
        return;
    }

    // Create a TextCandlestickPlot instance and draw the plot
    TextCandlestickPlot plotter(candlesticks);
    plotter.plotCandlestickData();

    // Print candlestick data with proper alignment using the helper function
    std::cout << "\nCandlestick Data:\n";
    printCandlestickData(candlesticks, 5); // Precision set to 5 decimal places
}

/**
 * Task 3: Filter data by date range and/or temperature range, then create text-based plot.
 */
void WeatherApp::task3() {
    const std::string filepath = m_dataFilePath;

    // List of countries
    std::vector<std::string> countries = {
        "AT", "BE", "BG", "CH", "CZ", "DE", "DK", "EE", "ES", "FI",
        "FR", "GB", "GR", "HR", "HU", "IE", "IT", "LT", "LU", "LV",
        "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK"
    };

    // Print available countries
    std::cout << "\nAvailable Countries:\n";
    for (size_t i = 0; i < countries.size(); ++i) {
        std::cout << i + 1 << ". " << countries[i] << "\n";
    }

    // Prompt the user to select a country
    int countryChoice;
    std::cout << "Enter the number corresponding to your choice: ";
    std::cin >> countryChoice;

    // Validate country choice
    if (std::cin.fail() || countryChoice < 1 || countryChoice > static_cast<int>(countries.size())) {
        std::cerr << "Invalid input. Please select a valid country.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    std::string selectedCountry = countries[countryChoice - 1];
    std::cout << "\nYou selected: " << selectedCountry << "\n";

    // Compute temperature stats (entire dataset) but do not display
    TemperatureStats stats = computeTemperatureStats(selectedCountry, filepath);
    if (stats.minTemp > stats.maxTemp) {
        std::cerr << "Error computing temperature statistics.\n";
        return;
    }

    // Select candlestick type: Weekly, Monthly, Yearly
    std::cout << "\nSelect candlestick type:\n";
    std::cout << "1. Weekly Candlestick Data\n";
    std::cout << "2. Monthly Candlestick Data\n";
    std::cout << "3. Yearly Candlestick Data\n";
    std::cout << "Enter your choice: ";
    int typeChoice;
    std::cin >> typeChoice;

    // Validate candlestick type choice
    if (std::cin.fail() || typeChoice < 1 || typeChoice > 3) {
        std::cerr << "Invalid input. Please select a valid candlestick type.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    // Determine the date type for filtering based on candlestick type
    std::string dateType;
    switch (typeChoice) {
        case 1:
            dateType = "week";
            break;
        case 2:
            dateType = "month";
            break;
        case 3:
            dateType = "year";
            break;
        default:
            std::cerr << "Unexpected candlestick type selection.\n";
            return;
    }

    // Prompt for filtering options
    std::cout << "\nSelect filter options:\n";
    std::cout << "1. Solely " 
              << (dateType == "week" ? "Weekly Range (YYYY-WW to YYYY-WW)" :
                 (dateType == "month" ? "Monthly Range (YYYY-MM to YYYY-MM)" :
                 "Yearly Range (YYYY to YYYY)")) << "\n";
    std::cout << "2. Solely Temperature Filtering\n";
    std::cout << "3. Both " 
              << (dateType == "week" ? "Weekly Range and Temperature Filtering" :
                 (dateType == "month" ? "Monthly Range and Temperature Filtering" :
                 "Yearly Range and Temperature Filtering")) << "\n";
    std::cout << "Enter your choice: ";
    int filterChoice;
    std::cin >> filterChoice;

    // Validate filter choice
    if (std::cin.fail() || filterChoice < 1 || filterChoice > 3) {
        std::cerr << "Invalid input. Please select a valid filter option.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    // Initialize filter parameters
    std::string startDate = "", endDate = "";
    double minTemp = stats.minTemp;
    double maxTemp = stats.maxTemp;

    try {
        if (filterChoice == 1 || filterChoice == 3) {
            // Date range filtering
            if (dateType == "week") {
                std::cout << "Enter start week (YYYY-WW): ";
                std::cin >> startDate;
                std::cout << "Enter end week (YYYY-WW): ";
                std::cin >> endDate;
            } else if (dateType == "month") {
                std::cout << "Enter start month (YYYY-MM): ";
                std::cin >> startDate;
                std::cout << "Enter end month (YYYY-MM): ";
                std::cin >> endDate;
            } else if (dateType == "year") {
                std::cout << "Enter start year (YYYY): ";
                std::cin >> startDate;
                std::cout << "Enter end year (YYYY): ";
                std::cin >> endDate;
            }
        }

        if (filterChoice == 2 || filterChoice == 3) {
            // Temperature filtering
            if (filterChoice == 3) {
                // Both date and temperature filtering selected
                // Compute temperature stats within the specified date range
                TemperatureStats rangeStats = computeTemperatureStatsInRange(selectedCountry, filepath, startDate, endDate);
                
                if (rangeStats.minTemp > rangeStats.maxTemp) {
                    std::cerr << "Error computing temperature statistics within the specified date range.\n";
                    return;
                }

                // Display the available temperature range within the date range
                std::cout << "\nAvailable Temperature Range within the specified dates for " 
                          << selectedCountry << ": " 
                          << rangeStats.minTemp << " to " << rangeStats.maxTemp << " degrees.\n";

                // Prompt the user to input temperature filters within this range
                std::cout << "Enter minimum temperature (" << rangeStats.minTemp << " to " << rangeStats.maxTemp << "): ";
                std::cin >> minTemp;
                std::cout << "Enter maximum temperature (" << rangeStats.minTemp << " to " << rangeStats.maxTemp << "): ";
                std::cin >> maxTemp;

                // Validate temperature inputs
                if (minTemp < rangeStats.minTemp || maxTemp > rangeStats.maxTemp || minTemp > maxTemp) {
                    std::cerr << "Invalid temperature range. Please ensure minTemp <= maxTemp and both are within the available range.\n";
                    return;
                }
            }
            else if (filterChoice == 2) {
                // Solely Temperature Filtering
                // Display the overall temperature range
                std::cout << "\nAvailable Temperature Range for " << selectedCountry << ": " 
                          << stats.minTemp << " to " << stats.maxTemp << " degrees.\n";

                // Prompt the user to input temperature filters within this range
                std::cout << "Enter minimum temperature (" << stats.minTemp << " to " << stats.maxTemp << "): ";
                std::cin >> minTemp;
                std::cout << "Enter maximum temperature (" << stats.minTemp << " to " << stats.maxTemp << "): ";
                std::cin >> maxTemp;

                // Validate temperature inputs
                if (minTemp < stats.minTemp || maxTemp > stats.maxTemp || minTemp > maxTemp) {
                    std::cerr << "Invalid temperature range. Please ensure minTemp <= maxTemp and both are within the available range.\n";
                    return;
                }
            }
        }
    } catch (...) {
        std::cerr << "Error processing filter inputs. Please ensure all inputs are in the correct format.\n";
        return;
    }

    // Inform the user that computation is starting
    std::cout << "\nComputing results, please wait while loading...\n";

    std::vector<Candlestick> candlesticks;

    // Call the appropriate function based on typeChoice
    switch (typeChoice) {
        case 1:
            candlesticks = computeWeeklyCandlestickData(selectedCountry, filepath, startDate, endDate, 
                                                       std::numeric_limits<double>::lowest(), 
                                                       std::numeric_limits<double>::max());
            break;
        case 2:
            candlesticks = computeMonthlyCandlestickData(selectedCountry, filepath, startDate, endDate, 
                                                        std::numeric_limits<double>::lowest(), 
                                                        std::numeric_limits<double>::max());
            break;
        case 3:
            candlesticks = computeCandlestickData(selectedCountry, filepath, startDate, endDate, 
                                                std::numeric_limits<double>::lowest(), 
                                                std::numeric_limits<double>::max());
            break;
        default:
            std::cerr << "Unexpected error with candlestick type selection.\n";
            return;
    }

    if (candlesticks.empty()) {
        std::cerr << "No data matches the filter criteria.\n";
        return;
    }

    // *** Apply Temperature Filtering Only If Required ***
    if (filterChoice == 2 || filterChoice == 3) {
        candlesticks = filterCandlesticksByTemperature(candlesticks, minTemp, maxTemp);
    }

    if (candlesticks.empty()) {
        std::cerr << "No candlesticks match the temperature filter criteria.\n";
        return;
    }

    // Print the candlestick data
    std::cout << "\nFiltered Candlestick Data:\n";
    printCandlestickData(candlesticks, 5); // Print with 5 decimal places precision

    // Plot text-based graph (optional visualization)
    TextCandlestickPlot plotter(candlesticks);
    plotter.plotCandlestickData();
}

/**
 * Task 4: Perform a linear regression to predict future candlestick data.
 */

void WeatherApp::task4() {
    const std::string filepath = m_dataFilePath;

    // List of countries
    std::vector<std::string> countries = {
        "AT", "BE", "BG", "CH", "CZ", "DE", "DK", "EE", "ES", "FI",
        "FR", "GB", "GR", "HR", "HU", "IE", "IT", "LT", "LU", "LV",
        "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK"
    };

    // Print available countries
    std::cout << "\nAvailable Countries:\n";
    for (size_t i = 0; i < countries.size(); ++i) {
        std::cout << i + 1 << ". " << countries[i] << "\n";
    }

    // Prompt the user to select a country
    int countryChoice;
    std::cout << "Enter the number corresponding to your choice: ";
    std::cin >> countryChoice;

    // Validate country choice
    if (std::cin.fail() || countryChoice < 1 || countryChoice > static_cast<int>(countries.size())) {
        std::cerr << "Invalid input. Please select a valid country.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    std::string selectedCountry = countries[countryChoice - 1];
    std::cout << "\nYou selected: " << selectedCountry << "\n";

    // Select candlestick type: Weekly, Monthly, Yearly
    std::cout << "\nSelect candlestick type:\n";
    std::cout << "1. Weekly Candlestick Data\n";
    std::cout << "2. Monthly Candlestick Data\n";
    std::cout << "3. Yearly Candlestick Data\n";
    std::cout << "Enter your choice: ";
    int typeChoice;
    std::cin >> typeChoice;

    if (std::cin.fail() || typeChoice < 1 || typeChoice > 3) {
        std::cerr << "Invalid input. Please select a valid candlestick type.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        return;
    }

    std::string candlestickType;
    switch (typeChoice) {
        case 1:
            candlestickType = "week";
            break;
        case 2:
            candlestickType = "month";
            break;
        case 3:
            candlestickType = "year";
            break;
        default:
            std::cerr << "Unexpected error with candlestick type selection.\n";
            return;
    }

    // Prompt for prediction date range
    std::string startDate, endDate;
    std::cout << "\nEnter the start date for prediction ";
    if (candlestickType == "week") {
        std::cout << "(Format: YYYY-WW): ";
    }
    else if (candlestickType == "month") {
        std::cout << "(Format: YYYY-MM): ";
    }
    else if (candlestickType == "year") {
        std::cout << "(Format: YYYY): ";
    }
    std::cin >> startDate;

    std::cout << "Enter the end date for prediction ";
    if (candlestickType == "week") {
        std::cout << "(Format: YYYY-WW): ";
    }
    else if (candlestickType == "month") {
        std::cout << "(Format: YYYY-MM): ";
    }
    else if (candlestickType == "year") {
        std::cout << "(Format: YYYY): ";
    }
    std::cin >> endDate;

    // 1) Compute candlestick data once, using the chosen type.
    std::vector<Candlestick> allCandlesticks;
    if (candlestickType == "week") {
        allCandlesticks = computeWeeklyCandlestickData(
            selectedCountry,
            filepath,
            "",  // No startWeek filter
            "",  // No endWeek filter
            std::numeric_limits<double>::lowest(), 
            std::numeric_limits<double>::max()
        );
    }
    else if (candlestickType == "month") {
        allCandlesticks = computeMonthlyCandlestickData(
            selectedCountry,
            filepath,
            "",  // No startMonth filter
            "",  // No endMonth filter
            std::numeric_limits<double>::lowest(),
            std::numeric_limits<double>::max()
        );
    }
    else { // "year"
        allCandlesticks = computeCandlestickData(
            selectedCountry,
            filepath,
            "",  // No startYear filter
            "",  // No endYear filter
            std::numeric_limits<double>::lowest(),
            std::numeric_limits<double>::max()
        );
    }

    if (allCandlesticks.empty()) {
        std::cerr << "Failed to compute candlestick data for the selected country and type.\n";
        return;
    }

    // 2) Split the candlestick data into training & testing sets based on the user-specified date range.
    std::vector<Candlestick> trainingCandlesticks;
    std::vector<Candlestick> testingCandlesticks;

    int seqStart = dateToSequential(startDate, candlestickType);
    int seqEnd   = dateToSequential(endDate, candlestickType);

    for (const auto& candle : allCandlesticks) {
        int seqValue = dateToSequential(candle.date, candlestickType);

        if (seqValue < seqStart) {
            trainingCandlesticks.push_back(candle);
        }
        else if (seqValue >= seqStart && seqValue <= seqEnd) {
            testingCandlesticks.push_back(candle);
        }
        // If the candlestick is after seqEnd, ignore for now
    }

    if (trainingCandlesticks.empty()) {
        std::cerr << "No training data available before the start date. Please choose an earlier start date.\n";
        return;
    }

    // 3) Prepare training data
    std::vector<double> x_train;
    std::vector<double> open_train, high_train, low_train, close_train;

    for (size_t i = 0; i < trainingCandlesticks.size(); ++i) {
        x_train.push_back(static_cast<double>(i + 1)); 
        open_train.push_back(trainingCandlesticks[i].open);
        high_train.push_back(trainingCandlesticks[i].high);
        low_train.push_back(trainingCandlesticks[i].low);
        close_train.push_back(trainingCandlesticks[i].close);
    }

    // 4) Perform linear regressions
    RegressionParams open_params  = linearRegression(x_train, open_train);
    RegressionParams high_params  = linearRegression(x_train, high_train);
    RegressionParams low_params   = linearRegression(x_train, low_train);
    RegressionParams close_params = linearRegression(x_train, close_train);

    // 5) Predict on testing data
    std::vector<double> open_pred, high_pred, low_pred, close_pred;

    for (size_t i = 0; i < testingCandlesticks.size(); ++i) {
        double xVal = static_cast<double>(trainingCandlesticks.size() + i + 1);

        open_pred.push_back(open_params.slope  * xVal + open_params.intercept);
        high_pred.push_back(high_params.slope  * xVal + high_params.intercept);
        low_pred.push_back(low_params.slope   * xVal + low_params.intercept);
        close_pred.push_back(close_params.slope * xVal + close_params.intercept);
    }

    // 6) Build predicted candlesticks
    std::vector<Candlestick> predictedCandlesticks;
    predictedCandlesticks.reserve(testingCandlesticks.size());
    for (size_t i = 0; i < testingCandlesticks.size(); ++i) {
        Candlestick pred(
            testingCandlesticks[i].date, 
            open_pred[i],
            high_pred[i],
            low_pred[i],
            close_pred[i]
        );
        predictedCandlesticks.push_back(pred);
    }

    // 7) Compute accuracy metrics
    std::vector<double> actual_open, actual_high, actual_low, actual_close;
    for (const auto& c : testingCandlesticks) {
        actual_open.push_back(c.open);
        actual_high.push_back(c.high);
        actual_low.push_back(c.low);
        actual_close.push_back(c.close);
    }

    AccuracyMetrics open_metrics  = computeAccuracyMetrics(actual_open,  open_pred);
    AccuracyMetrics high_metrics  = computeAccuracyMetrics(actual_high,  high_pred);
    AccuracyMetrics low_metrics   = computeAccuracyMetrics(actual_low,   low_pred);
    AccuracyMetrics close_metrics = computeAccuracyMetrics(actual_close, close_pred);

    // Print out the metrics
    std::cout << "\nAccuracy Metrics (trained on " << trainingCandlesticks.size() 
              << " recent " << candlestickType << " candlesticks):\n";
    std::cout << std::fixed << std::setprecision(5);
    std::cout << "Component\tMAE\t\tRMSE\n";
    std::cout << "------------------------------------------\n";
    std::cout << "Open\t\t"  << open_metrics.mae  << "\t" << open_metrics.rmse  << "\n";
    std::cout << "High\t\t"  << high_metrics.mae  << "\t" << high_metrics.rmse  << "\n";
    std::cout << "Low\t\t"   << low_metrics.mae   << "\t" << low_metrics.rmse   << "\n";
    std::cout << "Close\t\t" << close_metrics.mae << "\t" << close_metrics.rmse << "\n";

    // 8) Print comparison table
    printComparison(testingCandlesticks, predictedCandlesticks);

    // Visualize actual candlestick data
    std::cout << "\nActual Candlestick Data:\n";
    printCandlestickData(testingCandlesticks, 5);
    TextCandlestickPlot actualPlot(testingCandlesticks);
    actualPlot.plotCandlestickData();
    
    // Visualize predicted candlestick data
    std::cout << "\nPredicted Candlestick Data:\n";
    printCandlestickData(predictedCandlesticks, 5);
    TextCandlestickPlot predictedPlot(predictedCandlesticks);
    predictedPlot.plotCandlestickData();

    // ---------------------- EXTRAPOLATION FOR FUTURE YEARS ----------------------
    // Find the maximum year in the existing data
    int maxYear = 0;
    for (const auto& candle : allCandlesticks) {
        try {
            int year = std::stoi(candle.date.substr(0, 4));
            if (year > maxYear) {
                maxYear = year;
            }
        } catch (...) {
            continue; // Skip invalid date formats
        }
    }

    // Extract the end year from the user input
    int desiredEndYear = maxYear;
    try {
        if (candlestickType == "year") {
            desiredEndYear = std::stoi(endDate.substr(0, 4));
        }
        else if (candlestickType == "month") {
            desiredEndYear = std::stoi(endDate.substr(0, 4));
        }
        else if (candlestickType == "week") {
            desiredEndYear = std::stoi(endDate.substr(0, 4));
        }
    } catch (...) {
        std::cerr << "Invalid end date format. Unable to generate future predictions.\n";
        return;
    }

    if (desiredEndYear > maxYear) {
        int numFutureYears = desiredEndYear - maxYear;
        std::vector<std::string> futureDates;

        // Generate future dates based on candlestick type
        for (int year = maxYear + 1; year <= desiredEndYear; ++year) {
            if (candlestickType == "year") {
                futureDates.push_back(std::to_string(year));
            }
            else if (candlestickType == "month") {
                for (int month = 1; month <= 12; ++month) {
                    std::ostringstream oss;
                    oss << year << "-" << (month < 10 ? "0" : "") << month;
                    futureDates.push_back(oss.str());
                }
            }
            else if (candlestickType == "week") {
                for (int week = 1; week <= 53; ++week) { // Assuming 53 weeks max
                    std::ostringstream oss;
                    oss << year << "-" << (week < 10 ? "0" : "") << week;
                    futureDates.push_back(oss.str());
                }
            }
        }

        // Determine the starting xVal for future predictions
        double currentXVal = static_cast<double>(trainingCandlesticks.size() + testingCandlesticks.size() + 1);

        // Extrapolate predictions for future dates with incremented xVal
        for (const auto& futureDate : futureDates) {
            // Predict using regression parameters
            double open_forecast  = open_params.slope  * currentXVal + open_params.intercept;
            double high_forecast  = high_params.slope  * currentXVal + high_params.intercept;
            double low_forecast   = low_params.slope   * currentXVal + low_params.intercept;
            double close_forecast = close_params.slope * currentXVal + close_params.intercept;

            // Create a new predicted candlestick
            Candlestick futurePred(
                futureDate,
                open_forecast,
                high_forecast,
                low_forecast,
                close_forecast
            );

            // Append to predictedCandlesticks
            predictedCandlesticks.push_back(futurePred);

            // Increment xVal for the next prediction
            currentXVal += 1.0;
        }

        // Print and plot future predictions
        std::cout << "\nFuture Predictions Beyond Existing Data:\n";
        // Extract only the future predictions
        std::vector<Candlestick> futurePredictions(predictedCandlesticks.begin() + testingCandlesticks.size(), predictedCandlesticks.end());

        // Print future predicted candlestick data
        printCandlestickData(futurePredictions, 5);

        // Plot future predicted candlestick data using existing plotting function
        TextCandlestickPlot futurePlot(futurePredictions);
        futurePlot.plotCandlestickData();
    }
}