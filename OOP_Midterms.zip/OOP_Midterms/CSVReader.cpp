#include "CSVReader.h"
#include <fstream>
#include <sstream>
#include <iostream>

std::vector<std::vector<std::string>> CSVReader::readCSV(const std::string& filepath) {
    std::vector<std::vector<std::string>> data; // Stores the parsed CSV data.
    std::ifstream file(filepath);              // Open the CSV file for reading.

    // Check if the file was opened successfully.
    if (!file.is_open()) {
        std::cerr << "Error: Could not open file: " << filepath << "\n";
        return data; // Return empty data if file cannot be opened.
    }

    std::string line;
    // Read the file line by line.
    while (std::getline(file, line)) {
        std::vector<std::string> row;         // Stores a single row of the CSV.
        std::stringstream lineStream(line);  // Convert the line into a stream.
        std::string cell;

        // Split the line into cells by the comma delimiter.
        while (std::getline(lineStream, cell, ',')) {
            row.push_back(cell); // Add each cell to the row.
        }

        data.push_back(row); // Add the row to the data vector.
    }

    file.close(); // Close the file after reading.
    return data;  // Return the parsed CSV data.
}
