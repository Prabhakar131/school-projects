#pragma once
#include <string>
#include <vector>
#include "Candlestick.h"
#include "TemperatureStats.h"


// Struct to store parameters for a linear regression model.
struct RegressionParams {
    double slope;      // The slope of the regression line.
    double intercept;  // The intercept of the regression line.
};

// Struct to store accuracy metrics for model evaluation.
struct AccuracyMetrics {
    double mae;   // Mean Absolute Error (MAE).
    double rmse;  // Root Mean Squared Error (RMSE).
};



// Represents a weather analysis application with various tasks and utilities.
class WeatherApp {
public:
    // Constructor to initialize the WeatherApp with a data file path.
    WeatherApp(const std::string& dataFilePath);

    // Runs the main application loop.
    void run();

private:
    // Member variables
    std::string m_dataFilePath; // Path to the weather data file.

    // Private task methods
    void task1(); // Executes Task 1.
    void task2(); // Executes Task 2.
    void task3(); // Executes Task 3.
    void task4(); // Executes Task 4.

    // Computes temperature statistics (min and max) for a given country.
    TemperatureStats computeTemperatureStats(const std::string& country, const std::string& filepath);

    // Prints candlestick data with a specified precision for numerical values.
    void printCandlestickData(const std::vector<Candlestick>& candlesticks, int precision = 5);
};

