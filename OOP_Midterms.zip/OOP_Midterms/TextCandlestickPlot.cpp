// TextCandlestickPlot.cpp
#include "TextCandlestickPlot.h"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>

// Constructor implementation
TextCandlestickPlot::TextCandlestickPlot(const std::vector<Candlestick>& data, int plotHeight)
    : candlesticks(data), height(plotHeight) {}

// Helper method to clamp values within a range
int TextCandlestickPlot::clamp_custom(int value, int min, int max) const {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

// Helper method to extract labels based on date format
std::string TextCandlestickPlot::extractLabel(const std::string& date) const {
    if (date.length() == 4) { // Yearly data "YYYY"
        return date; // Use full year
    } else if (date.length() == 7) { // Monthly data "YYYY-MM"
        return date.substr(5, 2); // Extract "MM"
    } else if (date.length() >= 10) { // Daily data "YYYY-MM-DD"
        return date.substr(8, 2); // Extract "DD"
    }
    return "??"; // Unknown format
}

void TextCandlestickPlot::plotCandlestickData() const {
    if (candlesticks.empty()) {
        std::cout << "No data to plot." << std::endl;
        return;
    }

    // Determine the range of temperatures
    double minTemp = candlesticks[0].low;
    double maxTemp = candlesticks[0].high;
    for (const auto& candle : candlesticks) {
        if (candle.low < minTemp) minTemp = candle.low;
        if (candle.high > maxTemp) maxTemp = candle.high;
    }

    // Round minTemp and maxTemp to the nearest integers for a clear Y-axis
    int roundedMin = static_cast<int>(std::floor(minTemp));
    int roundedMax = static_cast<int>(std::ceil(maxTemp));

    // Adjust plot height based on data range
    int plotHeightAdjusted = roundedMax - roundedMin + 1; // One row for each integer increment

    // Create a 2D grid initialized with spaces
    // Each candlestick will occupy a fixed-width space to ensure alignment
    const int candlestickWidth = 6; // Width of each candlestick column
    std::vector<std::string> grid(plotHeightAdjusted, std::string(candlesticks.size() * candlestickWidth, ' '));

    // Populate the grid with candlestick data
    for (size_t i = 0; i < candlesticks.size(); ++i) {
        const Candlestick& candle = candlesticks[i];

        // Map temperatures to grid rows
        int highPos = roundedMax - static_cast<int>(std::round(candle.high));
        int lowPos = roundedMax - static_cast<int>(std::round(candle.low));
        int openPos = roundedMax - static_cast<int>(std::round(candle.open));
        int closePos = roundedMax - static_cast<int>(std::round(candle.close));

        // Ensure positions are within grid boundaries
        highPos = clamp_custom(highPos, 0, plotHeightAdjusted - 1);
        lowPos = clamp_custom(lowPos, 0, plotHeightAdjusted - 1);
        openPos = clamp_custom(openPos, 0, plotHeightAdjusted - 1);
        closePos = clamp_custom(closePos, 0, plotHeightAdjusted - 1);

        // Determine candle type
        bool isBullish = candle.close >= candle.open;

        // Draw the wick
        for (int y = highPos; y <= lowPos; ++y) {
            grid[y][i * candlestickWidth + 2] = '|';
        }

        // Draw the body (using "^" for bullish and "v" for bearish)
        int bodyTop = isBullish ? closePos : openPos;
        int bodyBottom = isBullish ? openPos : closePos;

        for (int y = bodyTop; y <= bodyBottom; ++y) {
            grid[y][i * candlestickWidth + 1] = isBullish ? '^' : 'v';
            grid[y][i * candlestickWidth + 2] = isBullish ? '^' : 'v';
            grid[y][i * candlestickWidth + 3] = isBullish ? '^' : 'v';
        }
    }

    // Print the grid with Y-axis labels
    for (int y = 0; y < plotHeightAdjusted; ++y) {
        // Calculate the temperature for this row
        int temp = roundedMax - y;

        // Print the Y-axis label with consistent width to fix spacing issues
        std::cout << std::setw(6) << temp << " | ";

        // Print the row
        std::cout << grid[y] << std::endl;
    }

    // Print the X-axis
    std::cout << "       ";
    for (size_t i = 0; i < candlesticks.size(); ++i) {
        std::cout << "------";
    }
    std::cout << std::endl;

    // Print the year/month/day labels
    std::cout << "        ";
    for (const auto& candle : candlesticks) {
        // Extract label based on date format
        std::string label = extractLabel(candle.date);

        // Adjust label based on its length
        if (label.length() == 4) { // Yearly data "YYYY"
            // No truncation; keep full year
            // Ensure it fits within 6 characters by right-aligning
            std::cout << std::setw(6) << label;
        }
        else { // Monthly or daily data "MM" or "DD"
            // Ensure label is 2 characters
            if (label.length() < 2) {
                label = "0" + label;
            }
            std::cout << std::setw(6) << label;
        }
    }
    std::cout << std::endl;
}
