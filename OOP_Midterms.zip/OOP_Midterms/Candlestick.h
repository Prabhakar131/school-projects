
#pragma once
#include <string>

// Represents a candlestick, summarizing weather data for a specific time period.
class Candlestick {
public:
    std::string date;   // Date in "YYYY-MM-DD" format.
    double open;        // Temperature at the start of the period.
    double high;        // Highest temperature in the period.
    double low;         // Lowest temperature in the period.
    double close;       // Temperature at the end of the period.

    // Constructor to initialize a Candlestick with date and temperature values.
    Candlestick(const std::string& date, double open, double high, double low, double close);
};
