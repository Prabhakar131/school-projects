#pragma once
#include <JuceHeader.h>
#include "DJAudioPlayer.h"

//==============================================================================
// Custom LookAndFeel Declaration
//==============================================================================
// This class customizes the appearance of various JUCE components.
// It inherits from juce::LookAndFeel_V4, which allows overriding default drawing methods.
class CustomLookAndFeel : public juce::LookAndFeel_V4
{
public:
    CustomLookAndFeel();  // Constructor: sets up the custom look and feel.
    ~CustomLookAndFeel() override;  // Destructor: cleans up resources if needed.

    // Overrides the default linear slider drawing routine.
    // Parameters:
    //   g           - the graphics context to draw on.
    //   x, y, width, height - dimensions and position of the slider.
    //   sliderPos   - current position of the slider thumb.
    //   minSliderPos, maxSliderPos - the minimum and maximum positions of the slider.
    //   style       - style type of the slider.
    //   slider      - reference to the slider being drawn.
    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
        float sliderPos, float minSliderPos, float maxSliderPos,
        const juce::Slider::SliderStyle style, juce::Slider& slider) override;

    // Overrides the default rotary slider drawing routine.
    // Parameters:
    //   g                    - the graphics context to draw on.
    //   x, y, width, height  - dimensions and position of the slider.
    //   sliderPosProportional- current position as a proportional value (0.0 to 1.0).
    //   rotaryStartAngle     - starting angle for the rotary slider.
    //   rotaryEndAngle       - ending angle for the rotary slider.
    //   slider               - reference to the slider being drawn.
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
        float sliderPosProportional, float rotaryStartAngle,
        float rotaryEndAngle, juce::Slider& slider) override;

    // Overrides the button background drawing routine.
    // Parameters:
    //   g                    - the graphics context to draw on.
    //   button               - the button whose background is to be drawn.
    //   backgroundColour     - the background colour to use.
    //   isMouseOverButton    - flag to indicate if the mouse is hovering over the button.
    //   isButtonDown         - flag to indicate if the button is being clicked.
    void drawButtonBackground(juce::Graphics& g, juce::Button& button,
        const juce::Colour& backgroundColour,
        bool isMouseOverButton, bool isButtonDown) override;
};

//==============================================================================
// DeckGUIControls Declaration
//==============================================================================
// This class represents the graphical user interface controls for a deck,
// including sliders, knobs (for EQ), and buttons. It interacts with a DJAudioPlayer.
class DeckGUIControls : public juce::Component
{
public:
    DeckGUIControls();  // Constructor: initializes the GUI controls.
    ~DeckGUIControls() override;  // Destructor: cleans up resources if necessary.

    // Sets the audio player that this GUI will control.
    // Parameter:
    //   newPlayer - pointer to a DJAudioPlayer instance.
    void setAudioPlayer(DJAudioPlayer* newPlayer);

    // Paint method for rendering the component.
    // Parameter:
    //   g - graphics context for drawing.
    void paint(juce::Graphics& g) override;

    // Called when the component's size changes.
    // Used for laying out subcomponents.
    void resized() override;

private:
    // Pointer to the DJAudioPlayer instance that this GUI controls.
    DJAudioPlayer* audioPlayer = nullptr;

    // Instance of the custom look and feel for applying visual styles.
    CustomLookAndFeel customLNF;

    // Sliders for controlling volume, speed, and position of the playback.
    juce::Slider volumeSlider, speedSlider, positionSlider;
    // Labels corresponding to the sliders.
    juce::Label volumeLabel, speedLabel, positionLabel;

    // Knobs for adjusting the EQ settings (low, mid, high frequencies).
    juce::Slider lowKnob, midKnob, highKnob;
    // Labels corresponding to the EQ knobs.
    juce::Label lowLabel, midLabel, highLabel;

    // Buttons for playback control: play, pause, and loop.
    juce::TextButton playButton, pauseButton, loopButton;
    // Labels corresponding to the buttons.
    juce::Label playLabel, pauseLabel, loopLabel;

    // Loop state: when true, looping is enabled for the current track.
    bool loopState = false;

    // JUCE macro to help detect memory leaks in this class.
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DeckGUIControls)
};


