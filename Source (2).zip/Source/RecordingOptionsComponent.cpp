#include "RecordingOptionsComponent.h"

RecordingOptionsComponent::RecordingOptionsComponent()
{
    setLookAndFeel(&customLookAndFeel);

    addAndMakeVisible(startRecordingButton);
    addAndMakeVisible(stopRecordingButton);
    addAndMakeVisible(saveRecordingButton);

    startRecordingButton.addListener(this);
    stopRecordingButton.addListener(this);
    saveRecordingButton.addListener(this);

    // Initially, only the Start button is enabled.
    startRecordingButton.setEnabled(true);
    stopRecordingButton.setEnabled(false);
    saveRecordingButton.setEnabled(false);
}

RecordingOptionsComponent::~RecordingOptionsComponent()
{
    startRecordingButton.removeListener(this);
    stopRecordingButton.removeListener(this);
    saveRecordingButton.removeListener(this);

    setLookAndFeel(nullptr);
}

void RecordingOptionsComponent::paint(juce::Graphics& g)
{
    // Fill with a darker navy blue background (less bright).
    g.fillAll(juce::Colours::navy.darker(1.0f));
}

void RecordingOptionsComponent::resized()
{
    auto area = getLocalBounds();
    int buttonWidth = area.getWidth() / 3;
    const int margin = 5;

    startRecordingButton.setBounds(area.removeFromLeft(buttonWidth).reduced(margin));
    stopRecordingButton.setBounds(area.removeFromLeft(buttonWidth).reduced(margin));
    saveRecordingButton.setBounds(area.reduced(margin));
}

void RecordingOptionsComponent::buttonClicked(juce::Button* button)
{
    if (button == &startRecordingButton)
    {
        if (!isRecording)
        {
            // Choose a temporary file in the system temp directory.
            recordedFile = juce::File::getSpecialLocation(juce::File::tempDirectory)
                .getChildFile("tempRecording.wav");
            if (recordedFile.existsAsFile())
                recordedFile.deleteFile();

            // Create an output stream.
            std::unique_ptr<juce::FileOutputStream> fileStream(recordedFile.createOutputStream());
            if (fileStream == nullptr)
                return; // Failed to create stream

            juce::WavAudioFormat wavFormat;
            // Create a writer for 44100 Hz, 2 channels, 16-bit samples.
            juce::AudioFormatWriter* writerRaw = wavFormat.createWriterFor(fileStream.release(),
                44100.0,
                2,
                16,
                {},
                0);
            if (writerRaw != nullptr)
            {
                recordThread.startThread();
                writer.reset(new juce::AudioFormatWriter::ThreadedWriter(writerRaw, recordThread, 32768));
                isRecording = true;
                recordStartTime = juce::Time::getCurrentTime();

                startRecordingButton.setEnabled(false);
                stopRecordingButton.setEnabled(true);
                saveRecordingButton.setEnabled(false);

                if (onStartRecording)
                    onStartRecording();

                DBG("Recording started. Temporary file: " << recordedFile.getFullPathName());
            }
        }
    }
    else if (button == &stopRecordingButton)
    {
        if (isRecording)
        {
            isRecording = false;
            writer.reset(); // Finalizes and closes the file.
            recordThread.stopThread(1000);

            startRecordingButton.setEnabled(true);
            stopRecordingButton.setEnabled(false);
            saveRecordingButton.setEnabled(true);

            if (onStopRecording)
                onStopRecording();

            DBG("Recording stopped. File saved to temp: " << recordedFile.getFullPathName());
        }
    }
    else if (button == &saveRecordingButton)
    {
        if (!isRecording && recordedFile.existsAsFile())
        {
            // Save directly to the user's desktop.
            juce::File desktop = juce::File::getSpecialLocation(juce::File::userDesktopDirectory);
            juce::File dest = desktop.getChildFile("RecordingSaved.wav");

            if (dest.existsAsFile())
                dest.deleteFile();

            bool copied = recordedFile.copyFileTo(dest);
            DBG("Attempting to copy from " << recordedFile.getFullPathName()
                << " to " << dest.getFullPathName());
            if (copied)
            {
                juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::InfoIcon,
                    "Save Successful",
                    "The recording was saved to your Desktop as 'RecordingSaved.wav'.");
                DBG("File successfully copied to desktop.");
            }
            else
            {
                juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon,
                    "Save Failed",
                    "The recording could not be saved.");
                DBG("File copy failed.");
            }

            if (onSaveRecording)
                onSaveRecording();
        }
    }
}

void RecordingOptionsComponent::writeBuffer(const juce::AudioSourceChannelInfo& bufferToFill)
{
    if (isRecording && writer != nullptr)
    {
        writer->write(bufferToFill.buffer->getArrayOfReadPointers(), bufferToFill.numSamples);
    }
}
