#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"
#include "DeckGUI.h"
#include "PlaylistComponent.h"
#include "DeckGUIControls.h"
#include "GlobalControls.h"
#include "RecordingOptionsComponent.h"

/**
    MainComponent is our top-level container that hosts:
    - A top RecordingOptionsComponent (recording buttons)
    - Middle row with:
        * Left column: DeckGUI (waveform/jogwheel/beatpad)
        * Center column: deckGuiControls1 + deckGuiControls2 + globalControls (custom GlobalControls)
        * Right column: DeckGUI (waveform/jogwheel/beatpad)
    - Bottom row: PlaylistComponent (Music Library)
*/
class MainComponent : public juce::AudioAppComponent,
    public juce::Timer
{
public:
    MainComponent();
    ~MainComponent() override;

    // AudioAppComponent overrides
    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    // Component overrides
    void paint(juce::Graphics& g) override;
    void resized() override;

    // Timer callback to update volume meters
    void timerCallback() override;

private:
    // Format manager & thumbnail cache
    juce::AudioFormatManager formatManager;
    juce::AudioThumbnailCache thumbCache{ 100 };

    // Two DJAudioPlayers
    DJAudioPlayer player1{ formatManager };
    DJAudioPlayer player2{ formatManager };

    // DeckGUI objects for the left & right columns
    DeckGUI deckGuiVisualsLeft{ &player1, formatManager, thumbCache };
    DeckGUI deckGuiVisualsRight{ &player2, formatManager, thumbCache };

    // Center column components:
    DeckGUIControls deckGuiControls1;  // Replaces the old placeholder
    DeckGUIControls deckGuiControls2;  // Replaces the old placeholder
    GlobalControls globalControls;     // Custom GlobalControls component

    // The top row: RecordingOptionsComponent
    RecordingOptionsComponent recordingOptionsComponent;

    // The bottom row for the music library
    PlaylistComponent playlistComponent;

    // Mixer to combine audio from players
    juce::MixerAudioSource mixerSource;

    // Atomic variables to store measured RMS levels for left and right channels.
    std::atomic<float> measuredLeftLevel{ 0.0f };
    std::atomic<float> measuredRightLevel{ 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};
