#pragma once

#include <JuceHeader.h>

/**
    BeatPadComponent loads 6 audio files from a "beats" folder (in the same
    directory as your source file). It expects the files to be named exactly as:
       beat_1, beat_2, beat_3, beat_4, beat_5, and beat_6,
    with an allowed audio extension (e.g. .mp3, .wav, .aif, or .aiff).
    Each file is assigned to a "pad" button.
    Clicking a pad re-triggers the sample from the start.

    This component is also an AudioSource so you can add it to your mixer.
*/
class BeatPadComponent : public juce::Component,
    public juce::AudioSource,
    public juce::Button::Listener,
    public juce::Timer
{
public:
    // Constructor: Initializes the BeatPadComponent, loads beats, and sets up buttons.
    BeatPadComponent();
    // Destructor: Cleans up any allocated resources.
    ~BeatPadComponent() override;

    // AudioSource overrides

    // Called before playback starts; prepares each transport source.
    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    // Called repeatedly to supply the next block of audio samples from the mixer.
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    // Called when playback stops, to release any allocated resources.
    void releaseResources() override;

    // Component overrides

    // Custom paint method to draw the BeatPadComponent.
    void paint(juce::Graphics& g) override;
    // Called when the component is resized; lays out the beat pad buttons.
    void resized() override;

    // Button::Listener override

    // Callback for button clicks: determines which pad was clicked and triggers playback.
    void buttonClicked(juce::Button* button) override;

    // Timer override

    // Timer callback that can be used to update visual effects on the pads periodically.
    void timerCallback() override;

private:
    //==============================================================================
    // A nested LookAndFeel class for drawing "glowing" rectangular pads.
    // This custom LookAndFeel modifies the appearance of the buttons to have a neon/glow effect.
    class BeatPadLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        // Default constructor.
        BeatPadLookAndFeel() = default;
        // Default destructor.
        ~BeatPadLookAndFeel() override = default;

        // Override to draw the background for a button with a glowing effect.
        void drawButtonBackground(juce::Graphics& g,
            juce::Button& button,
            const juce::Colour& /*backgroundColour*/,
            bool isMouseOverButton,
            bool isButtonDown) override
        {
            // Get the button's bounds as a floating point rectangle.
            auto bounds = button.getLocalBounds().toFloat();

            // Determine a corner radius based on the smallest dimension of the button.
            float cornerRadius = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.25f;

            // Retrieve the base colour from the button's colour ID.
            auto baseColour = button.findColour(juce::TextButton::buttonColourId);

            // Modify the base colour if the button is pressed or hovered.
            if (isButtonDown)
                baseColour = baseColour.brighter(0.2f);
            else if (isMouseOverButton)
                baseColour = baseColour.brighter(0.1f);

            // Create a vertical gradient fill from top (bright) to bottom (darker).
            juce::Colour topColour = baseColour.withAlpha(0.9f);
            juce::Colour bottomColour = baseColour.darker(0.2f).withAlpha(0.9f);

            juce::ColourGradient gradient(topColour,
                bounds.getX(), bounds.getY(),
                bottomColour,
                bounds.getX(), bounds.getBottom(),
                false);
            gradient.addColour(0.5, baseColour);

            // Set the gradient fill and fill a rounded rectangle.
            g.setGradientFill(gradient);
            g.fillRoundedRectangle(bounds, cornerRadius);

            // Draw an outer rounded rectangle stroke to simulate a glow/neon edge.
            g.setColour(baseColour.brighter(0.8f));
            float strokeThickness = isButtonDown ? 5.0f
                : (isMouseOverButton ? 4.0f : 3.0f);
            g.drawRoundedRectangle(bounds, cornerRadius, strokeThickness);
        }
    };

    static const int numPads = 6; // fixed to 6 pads

    // Our custom LookAndFeel instance used to style the beat pad buttons.
    BeatPadLookAndFeel padLookAndFeel;

    // Array of beat pad buttons (owned by this component).
    juce::OwnedArray<juce::TextButton> pads;

    // Array to store the original, unlit colours for each pad button.
    juce::Array<juce::Colour> originalPadColours;

    // File paths for each pad's audio file; holds the paths as strings.
    juce::StringArray filePaths;

    // A mixer that mixes the audio output from the 6 AudioTransportSources.
    juce::MixerAudioSource mixerSource;

    // Array of AudioTransportSources, one per pad, to handle audio playback.
    juce::AudioTransportSource transportSources[numPads];

    // Array of underlying reader sources for the transport sources, managing audio file reading.
    std::unique_ptr<juce::AudioFormatReaderSource> readerSources[numPads];

    // Manages audio formats (e.g. mp3, wav) to load the beat files.
    juce::AudioFormatManager formatManager;

    // Loads the 6 audio files (beat_1 to beat_6) from the "beats" folder.
    void loadBeatsFromFolder();

    // Macro to help catch any potential memory leaks.
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BeatPadComponent)
};
