#pragma once

#include <JuceHeader.h>
#include "DJAudioPlayer.h"

/**
    JogWheelComponent is a UI component that displays a jog wheel, which consists of:
      - An outer ring with progress marker dots.
      - A rotating inner disc that can display album art.
    It handles mouse drag events to rotate the wheel, and notifies external code of the rotation (in degrees)
    via a callback. The drawing of the jog wheel is fully handled by a custom LookAndFeel class defined as an inner class.
*/
class JogWheelComponent : public juce::Component
{
public:
    //==============================================================================
    // Constructor: Initializes the jog wheel component.
    JogWheelComponent();
    // Destructor: Cleans up any allocated resources.
    ~JogWheelComponent() override;

    /**
        setJogWheelCallback:
        Sets a callback function that is invoked with a delta (in degrees)
        representing how far the jog wheel has been rotated by user interaction.
    */
    void setJogWheelCallback(std::function<void(float)> callback);

    /**
        setAngle:
        Sets the current playback angle of the wheel (in degrees, range 0..360).
        This angle is used to update both the progress markers (dots) and the inner disc rotation.
    */
    void setAngle(float angleDegrees);

    /**
        setAlbumArt:
        Loads an album-art image to be displayed in the center of the inner disc.
        If the provided image is valid, it will be drawn over the disc.
    */
    void setAlbumArt(const juce::Image& img);

    //==============================================================================
    // Component overrides:
    // paint: Responsible for drawing the jog wheel using the custom LookAndFeel.
    void paint(juce::Graphics& g) override;
    // resized: Called when the component's bounds change; can be used for layout adjustments.
    void resized() override;

    /**
        mouseDown:
        Captures the initial angle when the mouse is pressed.
        This is used to calculate the drag delta later.
    */
    void mouseDown(const juce::MouseEvent& event) override;

    /**
        mouseDrag:
        Called when the mouse is dragged. Computes the change in angle since the last event,
        then calls the onJogWheelMove callback with the delta angle.
    */
    void mouseDrag(const juce::MouseEvent& event) override;

private:
    //==============================================================================
    /**
        JogWheelLookAndFeel is a custom LookAndFeel class dedicated to drawing the jog wheel.
        It implements a metallic black aesthetic with glossy highlights and ray shading effects.
        The drawing is broken into multiple parts:
          1) Outer ring with a gradient for a metallic look.
          2) Outer dots acting as progress markers that remain fixed (do not rotate with the disc).
          3) The inner disc that rotates according to the current angle, includes:
             - Base disc gradient.
             - Natural ray shading.
             - Glossy highlights via segmented wedges.
             - Concentric grooves.
             - The album art displayed at the center, clipped to a circular region.
    */
    class JogWheelLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        // Default constructor.
        JogWheelLookAndFeel() = default;
        // Default destructor.
        ~JogWheelLookAndFeel() override = default;

        /**
            drawJogWheel:
            Draws the entire jog wheel, including the outer ring, progress dots, inner disc, and album art.
            Parameters:
              - g: The graphics context.
              - bounds: The rectangular area in which to draw the wheel.
              - currentAngle: The current playback or progress angle (in degrees).
              - albumArt: The album art image to display in the center (if valid).
              - numDots: Number of dots to draw around the outer ring as progress markers.
        */
        void drawJogWheel(juce::Graphics& g,
            const juce::Rectangle<float>& bounds,
            float currentAngle,
            const juce::Image& albumArt,
            int numDots)
        {
            auto center = bounds.getCentre();
            // Determine the outer radius based on the smaller dimension of the bounds.
            float outerRadius = juce::jmin(bounds.getWidth(), bounds.getHeight()) * 0.5f - 5.0f;

            // Define the thickness of the outer ring and compute inner dimensions.
            float ringThickness = outerRadius * 0.15f;
            float ringOuter = outerRadius;
            float ringInner = ringOuter - ringThickness;
            // The inner disc fills most of the area inside the ring.
            float discRadius = ringInner * 0.98f;

            // Define a radius for the album art circle, typically half the disc radius.
            float artRadius = discRadius * 0.5f;

            //==================================================
            // 1) Draw the outer ring with a metallic black gradient.
            //==================================================
            {
                juce::ColourGradient outerGrad(juce::Colour::fromRGB(40, 40, 40), center.x, center.y,
                    juce::Colour::fromRGB(15, 15, 15), center.x, center.y + ringOuter, true);
                // Add an intermediate color stop to refine the gradient.
                outerGrad.addColour(0.4, juce::Colour::fromRGB(30, 30, 30));
                g.setGradientFill(outerGrad);
                // Draw the outer ring as an ellipse.
                g.fillEllipse(center.x - ringOuter,
                    center.y - ringOuter,
                    ringOuter * 2.0f,
                    ringOuter * 2.0f);
            }

            // Punch a hole in the ring by drawing a filled ellipse with a darker color.
            {
                g.setColour(juce::Colour::fromRGB(15, 15, 15));
                g.fillEllipse(center.x - ringInner,
                    center.y - ringInner,
                    ringInner * 2.0f,
                    ringInner * 2.0f);
            }

            //==================================================
            // 2) Draw outer dots (progress markers)
            //    - These dots are positioned along the outer edge.
            //    - They do NOT rotate with the inner disc.
            //    - A dot is lit (green) if its angle is less than or equal to currentAngle.
            //==================================================
            {
                float dotSize = 8.0f;
                // Position dots near the outer edge.
                float dotCenterRadius = ringOuter - (dotSize * 0.5f);
                for (int i = 0; i < numDots; ++i)
                {
                    // Calculate the angle for this dot.
                    float dotAngle = i * (360.0f / numDots);
                    // Determine if this dot should be lit based on currentAngle.
                    bool isLit = (dotAngle <= currentAngle);
                    juce::Colour dotColour = isLit ? juce::Colours::green : juce::Colours::white;
                    // Adjust the drawing angle so 0° is at the top.
                    float drawAngleDeg = dotAngle - 90.0f;
                    float drawAngleRad = juce::degreesToRadians(drawAngleDeg);
                    // Calculate the dot's position.
                    float x = center.x + dotCenterRadius * std::cos(drawAngleRad);
                    float y = center.y + dotCenterRadius * std::sin(drawAngleRad);
                    g.setColour(dotColour);
                    float halfSize = dotSize * 0.5f;
                    g.fillEllipse(x - halfSize, y - halfSize, dotSize, dotSize);
                }
            }

            //==================================================
            // 3) Rotate + draw the inner disc.
            //==================================================
            // Save the current graphics state to later restore the unrotated context.
            g.saveState();
            {
                // Convert the current angle from degrees to radians.
                float discAngleRadians = juce::degreesToRadians(currentAngle);
                // Apply a rotation transform around the center of the wheel.
                g.addTransform(juce::AffineTransform::rotation(discAngleRadians, center.x, center.y));

                // (3a) Draw the base disc with a metallic black gradient.
                {
                    juce::ColourGradient discGrad(juce::Colour::fromRGB(20, 20, 20),
                        center.x, center.y,
                        juce::Colour::fromRGB(0, 0, 0),
                        center.x, center.y + discRadius,
                        true);
                    discGrad.addColour(0.3, juce::Colour::fromRGB(10, 10, 10));
                    discGrad.addColour(0.7, juce::Colour::fromRGB(0, 0, 0));
                    g.setGradientFill(discGrad);
                    g.fillEllipse(center.x - discRadius,
                        center.y - discRadius,
                        discRadius * 2.0f,
                        discRadius * 2.0f);
                }

                // (3a.5) Overlay a subtle radial gradient to simulate natural ray shading.
                {
                    juce::ColourGradient raysGrad(juce::Colours::white.withAlpha(0.15f),
                        center.x, center.y,
                        juce::Colours::white.withAlpha(0.0f),
                        center.x, center.y + discRadius,
                        false);
                    g.setGradientFill(raysGrad);
                    g.fillEllipse(center.x - discRadius,
                        center.y - discRadius,
                        discRadius * 2.0f,
                        discRadius * 2.0f);
                }

                // (3b) Create a glossy reflection effect by drawing multiple pie segments (wedges).
                {
                    int numSlices = 24;
                    float wedgeAngle = juce::MathConstants<float>::twoPi / (float)numSlices;
                    for (int i = 0; i < numSlices; ++i)
                    {
                        float startAngle = i * wedgeAngle;
                        float endAngle = (i + 1) * wedgeAngle;
                        juce::Path wedge;
                        // Add a pie segment with a cutoff to limit its radial extent.
                        wedge.addPieSegment(center.x - discRadius,
                            center.y - discRadius,
                            discRadius * 2.0f,
                            discRadius * 2.0f,
                            startAngle, endAngle,
                            artRadius / discRadius);
                        // Determine a glossy factor using a sine function for variation.
                        float fraction = (float)i / (float)numSlices;
                        float glossyFactor = 0.3f + 0.7f * std::sin(fraction * juce::MathConstants<float>::twoPi * 2.0f);
                        // Blend between a dark overlay and a white highlight.
                        juce::Colour darkOverlay = juce::Colour::fromRGB(0, 0, 0).withAlpha(0.4f);
                        juce::Colour glossyHighlight = juce::Colours::white.withAlpha(0.3f);
                        juce::Colour wedgeColour = darkOverlay.interpolatedWith(glossyHighlight, glossyFactor);
                        g.setColour(wedgeColour);
                        g.fillPath(wedge);
                    }

                    // Draw an additional glossy gradient over the disc.
                    juce::ColourGradient glossGradient(juce::Colours::white.withAlpha(0.3f),
                        center.x, center.y - discRadius * 0.7f,
                        juce::Colours::white.withAlpha(0.0f),
                        center.x, center.y,
                        false);
                    g.setGradientFill(glossGradient);
                    g.fillEllipse(center.x - discRadius,
                        center.y - discRadius,
                        discRadius * 2.0f,
                        discRadius * 2.0f);
                }

                // (3c) Draw concentric grooves in the outer part of the disc.
                {
                    float grooveStart = artRadius;
                    float grooveEnd = ringInner;
                    int numGrooves = 8;
                    g.setColour(juce::Colours::black.withAlpha(0.7f));
                    for (int i = 1; i <= numGrooves; ++i)
                    {
                        // Linearly interpolate the groove radius.
                        float t = (float)i / (numGrooves + 1);
                        float r = juce::jmap(t, grooveStart, grooveEnd);
                        g.drawEllipse(center.x - r,
                            center.y - r,
                            r * 2.0f,
                            r * 2.0f,
                            1.0f);
                    }
                }

                // (3d) Draw the album art image, if available.
                // The album art is drawn last to ensure it appears on top.
                if (albumArt.isValid())
                {
                    juce::Rectangle<float> artBounds(center.x - artRadius,
                        center.y - artRadius,
                        artRadius * 2.0f,
                        artRadius * 2.0f);
                    // Create a circular clipping path so the album art appears in a circle.
                    juce::Path circleClip;
                    circleClip.addEllipse(artBounds);
                    g.saveState();
                    g.reduceClipRegion(circleClip);
                    g.drawImage(albumArt, artBounds);
                    g.restoreState();
                }
            }
            // Restore the graphics state to undo the rotation transform.
            g.restoreState();
        }
    };

    //==============================================================================
    // Private member variables for JogWheelComponent.
    // currentAngle: The current rotation angle (in degrees) of the inner disc.
    float currentAngle = 0.0f;  // in degrees
    // lastAngle: The angle recorded during the last mouse event; used to compute delta.
    float lastAngle = 0.0f;

    // albumArt: The image to display in the center of the inner disc.
    juce::Image albumArt;
    // onJogWheelMove: Callback function to notify external code of jog wheel movement.
    std::function<void(float)> onJogWheelMove;

    // Instance of the custom LookAndFeel used to draw the jog wheel.
    JogWheelLookAndFeel lookAndFeel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(JogWheelComponent)
};
