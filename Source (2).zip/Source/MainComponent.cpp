#include "MainComponent.h"

//==============================================================================
// MainComponent Constructor
//==============================================================================
// Sets up the main audio application UI and audio processing.
// The component aggregates various sub-components including:
// - RecordingOptionsComponent (for recording controls)
// - Two DeckGUI components (left and right) and their corresponding controls
// - GlobalControls (for global audio effects and volume metering)
// - PlaylistComponent (for the music library)
// Additionally, it initializes audio players, registers audio formats, links callbacks,
// adds all components to the UI, and sets up the audio mixer.
MainComponent::MainComponent()
{
    // Set the initial size of the main window.
    setSize(600, 600);

    // Register basic audio formats (e.g., WAV, MP3, AIFF) for file reading.
    formatManager.registerBasicFormats();

    // Add UI sub-components to the main component.
    addAndMakeVisible(recordingOptionsComponent);
    addAndMakeVisible(deckGuiVisualsLeft);
    addAndMakeVisible(deckGuiControls1);
    addAndMakeVisible(deckGuiControls2);
    addAndMakeVisible(globalControls);    // Global controls are now visible.
    addAndMakeVisible(deckGuiVisualsRight);
    addAndMakeVisible(playlistComponent);

    // Set names for the components (useful for debugging and logging).
    recordingOptionsComponent.setName("Recording Options");
    deckGuiVisualsLeft.setName("Left DeckGUI");
    deckGuiControls1.setName("Deck GUI 1 Controls");
    deckGuiControls2.setName("Deck GUI 2 Controls");
    globalControls.setName("Global Controls");
    deckGuiVisualsRight.setName("Right DeckGUI");

    // Example callbacks for recording actions.
    recordingOptionsComponent.onStartRecording = [this]() { /* start recording */ };
    recordingOptionsComponent.onStopRecording = [this]() { /* stop recording */ };
    recordingOptionsComponent.onSaveRecording = [this]() { /* save recording */ };

    // Callback for loading a track into the left deck visual.
    playlistComponent.onLoadLeft = [this](const std::string& filePath)
        {
            juce::File file(filePath);
            juce::URL trackURL(file);
            deckGuiVisualsLeft.loadTrack(trackURL);
        };

    // Callback for loading a track into the right deck visual.
    playlistComponent.onLoadRight = [this](const std::string& filePath)
        {
            juce::File file(filePath);
            juce::URL trackURL(file);
            deckGuiVisualsRight.loadTrack(trackURL);
        };

    // Link the DeckGUIControls to their corresponding DJAudioPlayer instances.
    deckGuiControls1.setAudioPlayer(&player1);
    deckGuiControls2.setAudioPlayer(&player2);

    // --- Set up GlobalControls callbacks ---
    // When the crossfade slider changes, adjust the volumes of the two players:
    // A value of 0.0 results in full left (player1), and 1.0 results in full right (player2).
    globalControls.onCrossfadeChanged = [this](double value)
        {
            player1.setVolume(1.0 - value);
            player2.setVolume(value);
        };

    // New effect callback for the drive control:
    // Maps the slider value (0.0 to 1.0) to the drive effect on both players.
    globalControls.onDriveChanged = [this](double value)
        {
            float mappedDrive = static_cast<float>(value); // Range is 0.0 to 1.0.
            player1.setDrive(mappedDrive);
            player2.setDrive(mappedDrive);
        };

    // New effect callback for the stereo width control:
    // Maps the slider value (expected range 0.0 to 1.5) to the stereo widening effect.
    globalControls.onWidthChanged = [this](double value)
        {
            float mappedWidth = static_cast<float>(value);
            player1.setStereoWidth(mappedWidth);
            player2.setStereoWidth(mappedWidth);
        };

    // New effect callback for the 8D audio control:
    // Maps the slider value (0.0 to 1.0) to the 8D effect on both players.
    globalControls.onEightDChanged = [this](double value)
        {
            float mappedEightD = static_cast<float>(value);
            player1.setEightD(mappedEightD);
            player2.setEightD(mappedEightD);
        };

    // Prepare the mixer by adding both players as inputs.
    mixerSource.addInputSource(&player1, false);
    mixerSource.addInputSource(&player2, false);

    // ***** NEW: Add BeatPadComponents from both decks to the mixer *****
    // This allows beat pads to be part of the overall audio output.
    mixerSource.addInputSource(&deckGuiVisualsLeft.getBeatPadComponent(), false);
    mixerSource.addInputSource(&deckGuiVisualsRight.getBeatPadComponent(), false);

    // Start a timer (10 Hz) to periodically update the volume meter levels.
    startTimerHz(10);

    // Enable audio I/O. Request 0 input channels and 2 output channels.
    // Check for and request audio recording permissions if necessary.
    if (juce::RuntimePermissions::isRequired(juce::RuntimePermissions::recordAudio)
        && !juce::RuntimePermissions::isGranted(juce::RuntimePermissions::recordAudio))
    {
        juce::RuntimePermissions::request(juce::RuntimePermissions::recordAudio,
            [this](bool granted)
            {
                if (granted)
                    setAudioChannels(2, 2);
            });
    }
    else
    {
        setAudioChannels(0, 2);
    }
}

//==============================================================================
// MainComponent Destructor
//==============================================================================
// Shuts down audio and stops the timer.
MainComponent::~MainComponent()
{
    shutdownAudio();
    stopTimer();
}

//==============================================================================
// prepareToPlay: Called before audio playback begins.
// Prepares both DJAudioPlayers and the mixer source with the given sample rate and block size.
void MainComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    // Prepare each audio player.
    player1.prepareToPlay(samplesPerBlockExpected, sampleRate);
    player2.prepareToPlay(samplesPerBlockExpected, sampleRate);

    // Prepare the mixer that combines all audio sources.
    mixerSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

//==============================================================================
// getNextAudioBlock: Fills the audio buffer with mixed audio output.
// Retrieves audio from the mixer and calculates RMS levels for volume metering.
void MainComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    // Get audio from the mixer, which aggregates inputs from both players and beat pads.
    mixerSource.getNextAudioBlock(bufferToFill);

    // If the audio buffer is valid, compute RMS (root mean square) levels for left and right channels.
    if (bufferToFill.buffer != nullptr)
    {
        float leftRMS = bufferToFill.buffer->getRMSLevel(0, bufferToFill.startSample, bufferToFill.numSamples);
        float rightRMS = (bufferToFill.buffer->getNumChannels() > 1)
            ? bufferToFill.buffer->getRMSLevel(1, bufferToFill.startSample, bufferToFill.numSamples)
            : leftRMS;
        // Scale the RMS values using an empirical factor to map them into the range 0.0 to 1.0.
        leftRMS = juce::jlimit(0.0f, 1.0f, leftRMS * 5.0f);
        rightRMS = juce::jlimit(0.0f, 1.0f, rightRMS * 5.0f);

        // Store the computed RMS levels in atomic variables for thread-safe access.
        measuredLeftLevel.store(leftRMS);
        measuredRightLevel.store(rightRMS);
    }
}

//==============================================================================
// releaseResources: Called when audio playback stops.
// Releases resources for both players and the mixer.
void MainComponent::releaseResources()
{
    player1.releaseResources();
    player2.releaseResources();
    mixerSource.releaseResources();
}

//==============================================================================
// paint: Draws custom UI elements on the main component.
// Draws lines to separate different sections of the UI such as recording options, the main area, and the music library.
void MainComponent::paint(juce::Graphics& g)
{
    // Fill the background using the current LookAndFeel's background colour for resizable windows.
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));
    g.setColour(juce::Colours::grey);
    g.setFont(15.0f);

    // Get the bounds of the entire component.
    auto totalBounds = getLocalBounds();

    // Define heights for the top and bottom rows:
    // Top row (recording options) occupies 5% of the total height.
    float topHeight = totalBounds.getHeight() * 0.05f;
    // Bottom row (music library) occupies 25% of the total height.
    float bottomHeight = totalBounds.getHeight() * 0.25f;
    // Middle area takes up the remaining height.
    float middleHeight = totalBounds.getHeight() - (topHeight + bottomHeight);

    // Draw horizontal divider lines for the top and bottom rows.
    g.drawLine(0.0f, topHeight, (float)getWidth(), topHeight, 2.0f);
    float bottomLineY = (float)getHeight() - bottomHeight;
    g.drawLine(0.0f, bottomLineY, (float)getWidth(), bottomLineY, 2.0f);

    // Divide the middle area vertically into three columns:
    // 30% for the left column, 40% for the center, and 30% for the right.
    float middleW = (float)getWidth();
    float leftColWidth = middleW * 0.30f;
    float centerColWidth = middleW * 0.40f;
    float leftLineX = leftColWidth;
    g.drawLine(leftLineX, topHeight, leftLineX, topHeight + middleHeight, 2.0f);
    float rightLineX = leftLineX + centerColWidth;
    g.drawLine(rightLineX, topHeight, rightLineX, topHeight + middleHeight, 2.0f);

    // Draw a horizontal line in the center of the middle area.
    float centerTopH = middleHeight * 0.50f;
    g.drawLine(leftLineX, topHeight + centerTopH, leftLineX + centerColWidth, topHeight + centerTopH, 2.0f);

    // Draw a vertical line in the center of the center column.
    float centerControlsLineX = leftLineX + (centerColWidth / 2.0f);
    g.drawLine(centerControlsLineX, topHeight, centerControlsLineX, topHeight + centerTopH, 2.0f);
}

//==============================================================================
// resized: Lays out all the child components when the main component is resized.
// The layout is divided into three regions: top row (recording options), middle (deck GUIs and controls),
// and bottom row (music library). The middle region is further divided into left, center, and right columns.
void MainComponent::resized()
{
    auto area = getLocalBounds();

    // Top row: Recording Options occupy 5% of the component's height.
    int topHeight = static_cast<int> (area.getHeight() * 0.05f);
    auto topRow = area.removeFromTop(topHeight);
    recordingOptionsComponent.setBounds(topRow);

    // Bottom row: Music Library (playlist) occupies 25% of the component's height.
    int bottomHeight = static_cast<int> (area.getHeight() * 0.25f);
    auto bottomRow = area.removeFromBottom(bottomHeight);
    playlistComponent.setBounds(bottomRow);

    // The remaining area (middle area) is divided into three columns:
    // left (30% width), center (40% width), and right (30% width).
    int totalWidth = area.getWidth();
    int leftWidth = static_cast<int> (totalWidth * 0.30f);
    int centerWidth = static_cast<int> (totalWidth * 0.40f);
    int rightWidth = totalWidth - leftWidth - centerWidth;

    // Left column: Contains the left deck visuals.
    auto leftCol = area.removeFromLeft(leftWidth);
    deckGuiVisualsLeft.setBounds(leftCol);

    // Right column: Contains the right deck visuals.
    auto rightCol = area.removeFromRight(rightWidth);
    deckGuiVisualsRight.setBounds(rightCol);

    // Center column: Divided into two rows.
    // Top half for DeckGUIControls (one for each deck) and bottom half for GlobalControls.
    int centerTopHeight = area.getHeight() / 2;
    auto centerTopRow = area.removeFromTop(centerTopHeight);
    auto centerBottomRow = area; // Remaining area

    // In the top center row, divide the area equally for two decks.
    int halfCenterWidth = centerTopRow.getWidth() / 2;
    auto deck1Area = centerTopRow.removeFromLeft(halfCenterWidth);
    auto deck2Area = centerTopRow; // Remainder

    // Set bounds for each DeckGUIControls component.
    deckGuiControls1.setBounds(deck1Area);
    deckGuiControls2.setBounds(deck2Area);

    // GlobalControls occupy the bottom half of the center column.
    globalControls.setBounds(centerBottomRow);
}

//==============================================================================
// timerCallback: Called periodically by the timer (set at 10 Hz).
// Updates the volume levels shown on the GlobalControls LED meters by reading
// the stored RMS values from the audio output.
void MainComponent::timerCallback()
{
    globalControls.setVolumeLevels(measuredLeftLevel.load(), measuredRightLevel.load());
}
