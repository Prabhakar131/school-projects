#pragma once

#include "../JuceLibraryCode/JuceHeader.h"

// Forward-declare WaveformDisplay so we can use a pointer without including its header.
class WaveformDisplay;

//==============================================================================
// DJAudioPlayer Class Declaration
//==============================================================================
// This class handles audio playback, EQ processing, and several audio effects.
// It inherits from juce::AudioSource to integrate with the JUCE audio engine.
class DJAudioPlayer : public juce::AudioSource
{
public:
    // Constructor: Initializes the DJAudioPlayer with an AudioFormatManager reference.
    DJAudioPlayer(juce::AudioFormatManager& _formatManager);

    // Destructor: Ensures that any allocated resources are properly released.
    ~DJAudioPlayer() override;

    // AudioSource overrides:

    // Prepare the audio source to play. This sets up buffers and sample rate.
    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;

    // Called repeatedly to get the next block of audio data for playback.
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;

    // Release resources allocated during playback.
    void releaseResources() override;

    // Playback controls:

    // Loads an audio file from a URL.
    void loadURL(juce::URL audioURL);

    // Start audio playback.
    void play();       // renamed from start()

    // Pause audio playback.
    void pause();      // renamed from stop()

    // Control methods:

    // Set the playback volume (renamed from setGain()).
    void setVolume(double vol);

    // Set the playback speed (resampling ratio).
    void setSpeed(double ratio);

    // Set the playback position in seconds.
    void setPosition(double posInSecs);

    // Set the playback position relative to the track's length (0.0 to 1.0).
    void setPositionRelative(double pos);

    // Query methods:

    // Get the current playback position relative to the total length (0.0 to 1.0).
    double getPositionRelative();

    // Get the current playback position in seconds.
    double getCurrentPosition();

    // Get the total length of the loaded audio in seconds.
    double getLengthInSeconds();

    // Associate a WaveformDisplay with this DJAudioPlayer.
    // The audio player will feed samples into the waveform display.
    void setWaveformDisplay(WaveformDisplay* wd) { waveformDisplay = wd; }

    // EQ control methods – adjust the gain (in dB) for each frequency band.
    void setLowGain(float gainDb);
    void setMidGain(float gainDb);
    void setHighGain(float gainDb);

    // Bypass control methods – enable or disable the EQ effect for each band.
    void setLowBypass(bool shouldBypass);
    void setMidBypass(bool shouldBypass);
    void setHighBypass(bool shouldBypass);

    // New effect control methods (replacing flanger, echo, bass boost):

    // Distortion / Overdrive effect ("Drive")
    // Range: 0.0 (clean) to 1.0 (max distortion)
    void setDrive(float driveValue);

    // Stereo Widening effect ("Width")
    // Range: 0.0 (mono) to ~1.5 (extra wide); default is 1.0.
    void setStereoWidth(float widthValue);

    // 8D Audio effect ("8D")
    // Range: 0.0 (off) to 1.0 (max 8D effect)
    void setEightD(float eightDValue);

    // Looping control method: Enable or disable looping of the audio track.
    void setLooping(bool shouldLoop);

private:
    // Reference to the AudioFormatManager used to handle different audio file formats.
    juce::AudioFormatManager& formatManager;

    // Unique pointer to an AudioFormatReaderSource, which reads the loaded audio file.
    std::unique_ptr<juce::AudioFormatReaderSource> readerSource;

    // AudioTransportSource for managing playback (start, stop, etc.).
    juce::AudioTransportSource transportSource;

    // ResamplingAudioSource for handling playback speed changes.
    // It wraps the transportSource and provides resampling capabilities.
    juce::ResamplingAudioSource resampleSource{ &transportSource, false, 2 };

    // Pointer to an associated WaveformDisplay for visualizing the audio waveform.
    WaveformDisplay* waveformDisplay{ nullptr };

    // EQ parameters: current gain (in dB) for each frequency band.
    float lowGainDb = 0.0f;
    float midGainDb = 0.0f;
    float highGainDb = 0.0f;

    // Bypass flags: if true, the corresponding EQ filter is bypassed.
    bool lowBypass = false;
    bool midBypass = false;
    bool highBypass = false;

    // Current sample rate used for audio processing.
    double sampleRate = 44100.0;

    // EQ filters: one IIR filter per channel (assuming stereo) for each band.
    juce::IIRFilter lowFilter[2], midFilter[2], highFilter[2];

    // Helper function to update the coefficients for the EQ filters based on current settings.
    void updateFilterCoefficients();

    // New effect parameters (replacing flanger, echo, bass boost):

    // Drive (Distortion/Overdrive effect) parameter.
    float drive = 0.0f;

    // Stereo width parameter (for widening effect).
    float stereoWidth = 1.0f;

    // 8D effect intensity.
    float eightD = 0.0f;

    // LFO phase used for modulating the 8D audio panning effect.
    float eightDLFOPhase = 0.0f;

    // LFO rate in Hz for the 8D effect modulation.
    float eightDLFORate = 0.25f;

    // Macro to help catch any memory leaks.
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DJAudioPlayer)
};
