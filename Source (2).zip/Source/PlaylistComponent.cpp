#include "PlaylistComponent.h"

//==============================================================================
// Constructor for PlaylistComponent
//==============================================================================
// Initializes the playlist UI, loads an existing library if available,
// otherwise imports tracks from the "resources" folder.
// Also sets up UI components like the search box, import button, table,
// and an empty message label.
PlaylistComponent::PlaylistComponent()
    : importButton("Import Track")
{
    // Set the component's look and feel to the custom playlist look and feel.
    setLookAndFeel(&playlistLookAndFeel);
    // Make the component opaque.
    setOpaque(true);

    // Check if a persistent library file ("musicLibrary.xml") exists in the user application data directory.
    auto libraryFile = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("musicLibrary.xml");

    if (libraryFile.existsAsFile())
    {
        // Persistent file exists: load the library from file (even if it is empty).
        loadLibraryToFile();
    }
    else
    {
        // First launch: attempt to load tracks from the "resources" folder.
        juce::File sourceDir(String(__FILE__));
        sourceDir = sourceDir.getParentDirectory();
        juce::File resourcesDir = sourceDir.getChildFile("resources");

        // Check if the resources directory exists and is a directory.
        if (resourcesDir.exists() && resourcesDir.isDirectory())
        {
            juce::Array<juce::File> audioFiles;
            // Find all .mp3 and .wav files in the resources folder.
            resourcesDir.findChildFiles(audioFiles, juce::File::findFiles, false, "*.mp3;*.wav");

            juce::AudioFormatManager formatManager;
            formatManager.registerBasicFormats();

            // Iterate over each audio file found.
            for (auto& file : audioFiles)
            {
                // Create a reader for the file to calculate duration.
                std::unique_ptr<juce::AudioFormatReader> reader(formatManager.createReaderFor(file));
                std::string durationStr = "N/A";
                if (reader != nullptr)
                {
                    // Calculate the duration in seconds.
                    double seconds = reader->lengthInSamples / reader->sampleRate;
                    int minutes = static_cast<int>(seconds / 60);
                    int secs = static_cast<int>(seconds) % 60;
                    // Format the duration as "m:ss".
                    durationStr = std::to_string(minutes) + ":" + (secs < 10 ? "0" : "") + std::to_string(secs);
                }
                // Use the file name (without extension) as the track title.
                std::string trackTitle = file.getFileNameWithoutExtension().toStdString();
                // Load album art for the track from the resources folder.
                juce::Image art = loadAlbumArtForFile(file);

                // Add the track information to the tracks vector.
                tracks.push_back({ trackTitle, durationStr, file.getFullPathName().toStdString(), art });
            }
            // Save the loaded library to a persistent file.
            saveLibraryToFile();
        }

        // If no tracks were loaded, add some default empty tracks.
        if (tracks.empty())
        {
            tracks.push_back({ "Track 1", "0:00", "", juce::Image() });
            tracks.push_back({ "Track 2", "0:00", "", juce::Image() });
            tracks.push_back({ "Track 3", "0:00", "", juce::Image() });
            tracks.push_back({ "Track 4", "0:00", "", juce::Image() });
            tracks.push_back({ "Track 5", "0:00", "", juce::Image() });
            tracks.push_back({ "Track 6", "0:00", "", juce::Image() });
            // Save the default library to file.
            saveLibraryToFile();
        }
    }
    // Initially, filteredTracks is the same as the complete tracks list.
    filteredTracks = tracks;

    //============================================================================== 
    // Setup the search box.
    //==============================================================================
    searchBox.setOpaque(true);
    // Set a dark navy background for the search box.
    searchBox.setColour(juce::TextEditor::backgroundColourId, juce::Colours::navy.darker(0.8f));
    // Remove the outline colour.
    searchBox.setColour(juce::TextEditor::outlineColourId, juce::Colours::transparentBlack);
    // Set placeholder text with grey colour.
    searchBox.setTextToShowWhenEmpty("Search...", juce::Colours::grey);
    // Set the text colour to white.
    searchBox.setColour(juce::TextEditor::textColourId, juce::Colours::white);
    // Set the caret colour to white.
    searchBox.setColour(juce::CaretComponent::caretColourId, juce::Colours::white);
    // Add this class as a listener to detect text changes.
    searchBox.addListener(this);
    // Add the search box to the UI.
    addAndMakeVisible(searchBox);

    //============================================================================== 
    // Setup the import button.
    //==============================================================================
    importButton.addListener(this);
    addAndMakeVisible(importButton);

    //============================================================================== 
    // Setup the table component (track list).
    //==============================================================================
    // Add columns to the table header:
    // Column 1: Album Art (width: 100)
    tableComponent.getHeader().addColumn("Album Art", 1, 100);
    // Column 2: Track Title (width: 300)
    tableComponent.getHeader().addColumn("Track Title", 2, 300);
    // Column 3: Duration (width: 100)
    tableComponent.getHeader().addColumn("Duration", 3, 100);
    // Column 4: Load 1 (width: 100) - button to load track into left deck.
    tableComponent.getHeader().addColumn("Load 1", 4, 100);
    // Column 5: Load 2 (width: 100) - button to load track into right deck.
    tableComponent.getHeader().addColumn("Load 2", 5, 100);
    // Column 6: Delete (width: 100) - button to delete track from library.
    tableComponent.getHeader().addColumn("Delete", 6, 100);
    // Set this class as the model for the table.
    tableComponent.setModel(this);
    // Add the table to the UI.
    addAndMakeVisible(tableComponent);
    // Allow the table header columns to stretch to fit the available space.
    tableComponent.getHeader().setStretchToFitActive(true);

    //============================================================================== 
    // Setup the empty message label.
    //==============================================================================
    emptyMessageLabel.setText("No tracks available. Please select files from the resources subfolder for the best experience.", juce::dontSendNotification);
    emptyMessageLabel.setJustificationType(juce::Justification::centred);
    emptyMessageLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible(emptyMessageLabel);

    // Update the visibility of the empty message label based on whether there are any tracks.
    updateEmptyMessageVisibility();
}

//==============================================================================
// Destructor for PlaylistComponent
//==============================================================================
// Resets the look and feel and saves the library to file upon destruction.
PlaylistComponent::~PlaylistComponent()
{
    setLookAndFeel(nullptr);
    saveLibraryToFile();
}

//==============================================================================
// paint: Custom drawing method for the PlaylistComponent.
// Fills the background and draws the title "Music Library" at the top.
void PlaylistComponent::paint(juce::Graphics& g)
{
    // Fill the background using the color defined in the look and feel.
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));
    g.setColour(juce::Colours::white);
    g.setFont(15.0f);
    // Draw the title text centered in the top 20 pixels.
    g.drawText("Music Library", getLocalBounds().removeFromTop(20),
        juce::Justification::centred, true);
}

//==============================================================================
// resized: Layout method called when the component's size changes.
// Positions the import button and search box in the top row, and the table fills the rest.
void PlaylistComponent::resized()
{
    auto area = getLocalBounds();
    // Reserve a 30-pixel high top row.
    auto topRow = area.removeFromTop(30);
    // Reserve 100 pixels for the import button from the left side of the top row.
    auto importArea = topRow.removeFromLeft(100);
    importButton.setBounds(importArea.reduced(4));
    // Set the remaining area in the top row for the search box.
    searchBox.setBounds(topRow.reduced(4));
    // The table component fills the remaining area.
    tableComponent.setBounds(area);

    // Position the empty message label over the table component.
    emptyMessageLabel.setBounds(tableComponent.getBounds());
}

//==============================================================================
// getNumRows: Returns the number of rows in the table.
// This is based on the number of filtered tracks.
int PlaylistComponent::getNumRows()
{
    return static_cast<int>(filteredTracks.size());
}

//==============================================================================
// paintRowBackground: Paints the background for a table row.
// Fills with a lighter navy if the row is selected, otherwise a darker navy.
void PlaylistComponent::paintRowBackground(juce::Graphics& g,
    int /*rowNumber*/,
    int /*width*/,
    int height,
    bool rowIsSelected)
{
    if (rowIsSelected)
        g.fillAll(juce::Colours::navy.darker(0.4f));
    else
        g.fillAll(juce::Colours::navy.darker(0.8f));
}

//==============================================================================
// paintCell: Renders the content of a cell in the table.
// For the "Track Title" and "Duration" columns, draws the corresponding text.
void PlaylistComponent::paintCell(juce::Graphics& g,
    int rowNumber,
    int columnId,
    int width,
    int height,
    bool /*rowIsSelected*/)
{
    if (rowNumber < static_cast<int>(filteredTracks.size()))
    {
        g.setColour(juce::Colours::white);
        if (columnId == 2) // Track Title column
        {
            g.drawText(filteredTracks[rowNumber].title,
                2, 0, width - 4, height,
                juce::Justification::centredLeft, true);
        }
        else if (columnId == 3) // Duration column
        {
            g.drawText(filteredTracks[rowNumber].duration,
                2, 0, width - 4, height,
                juce::Justification::centred, true);
        }
    }
}

//==============================================================================
// refreshComponentForCell: Provides a component for interactive cells in the table.
// For columns 4, 5, and 6 (Load 1, Load 2, and Delete buttons), creates and returns a TextButton.
// For column 1 (Album Art), creates or updates an ImageComponent with the album art image.
juce::Component* PlaylistComponent::refreshComponentForCell(int rowNumber,
    int columnId,
    bool /*isRowSelected*/,
    juce::Component* existingComp)
{
    // For interactive button columns.
    if (columnId == 4 || columnId == 5 || columnId == 6)
    {
        if (existingComp == nullptr)
        {
            auto* btn = new juce::TextButton();
            // Set button text based on the column.
            if (columnId == 4)
                btn->setButtonText("Load 1");
            else if (columnId == 5)
                btn->setButtonText("Load 2");
            else if (columnId == 6)
                btn->setButtonText("Delete");

            // Set a unique component ID combining column and row numbers.
            btn->setComponentID(std::to_string(columnId) + "_" + std::to_string(rowNumber));
            btn->addListener(this);
            return btn;
        }
        return existingComp;
    }
    // For the Album Art column.
    else if (columnId == 1)
    {
        if (rowNumber < static_cast<int>(filteredTracks.size()))
        {
            if (existingComp == nullptr)
            {
                auto* imageComp = new juce::ImageComponent();
                // Set the image to the album art of the track.
                imageComp->setImage(filteredTracks[rowNumber].albumArt);
                // Ensure the image fills the component.
                imageComp->setImagePlacement(juce::RectanglePlacement::stretchToFit);
                return imageComp;
            }
            else
            {
                // If an ImageComponent already exists, update its image.
                auto* imageComp = dynamic_cast<juce::ImageComponent*>(existingComp);
                if (imageComp)
                    imageComp->setImage(filteredTracks[rowNumber].albumArt);
            }
        }
        return existingComp;
    }
    return existingComp;
}

//==============================================================================
// buttonClicked: Handles button click events.
// If the import button is clicked, opens a file chooser to import a new track.
// Otherwise, checks the component ID to determine which button was pressed in the table.
void PlaylistComponent::buttonClicked(juce::Button* button)
{
    // Check if the import button was clicked.
    if (button == &importButton)
    {
        // Create a file chooser for selecting an audio file.
        auto* chooser = new juce::FileChooser("Select an Audio file",
            juce::File::getSpecialLocation(juce::File::userHomeDirectory),
            "*.mp3;*.wav");
        // Launch the file chooser asynchronously.
        chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
            [this, chooser](const juce::FileChooser& fc)
            {
                // Get the selected file.
                auto file = fc.getResult();
                if (file.existsAsFile())
                {
                    // Import the selected track.
                    importTrack(file);
                    // Update and repaint the table content.
                    tableComponent.updateContent();
                    tableComponent.repaint();
                    // Save the updated library and update the empty message visibility.
                    saveLibraryToFile();
                    updateEmptyMessageVisibility();
                }
                delete chooser;
            });
        return;
    }

    // For buttons in the table, parse the component ID to extract column and row numbers.
    auto compID = button->getComponentID().toStdString();
    auto pos = compID.find("_");
    if (pos != std::string::npos)
    {
        int col = std::stoi(compID.substr(0, pos));
        int row = std::stoi(compID.substr(pos + 1));
        if (row < static_cast<int>(filteredTracks.size()))
        {
            // Column 4: Load track into left deck.
            if (col == 4)
            {
                if (onLoadLeft) onLoadLeft(filteredTracks[row].filePath);
            }
            // Column 5: Load track into right deck.
            else if (col == 5)
            {
                if (onLoadRight) onLoadRight(filteredTracks[row].filePath);
            }
            // Column 6: Delete track from the library.
            else if (col == 6)
            {
                auto filePath = filteredTracks[row].filePath;
                // Remove the track from the complete tracks vector.
                tracks.erase(std::remove_if(tracks.begin(), tracks.end(),
                    [&](const TrackInfo& t) { return t.filePath == filePath; }),
                    tracks.end());
                // Remove the track from the filtered tracks vector.
                filteredTracks.erase(filteredTracks.begin() + row);
                tableComponent.updateContent();
                tableComponent.repaint();
                // Save the updated library to file and update empty message visibility.
                saveLibraryToFile();
                updateEmptyMessageVisibility();
            }
        }
    }
}

//==============================================================================
// textEditorTextChanged: Called when the text in the search box changes.
// Filters the track list based on the search query.
void PlaylistComponent::textEditorTextChanged(juce::TextEditor& editor)
{
    if (&editor == &searchBox)
    {
        // Convert the search query to lowercase for case-insensitive comparison.
        auto query = searchBox.getText().toLowerCase();
        filteredTracks.clear();
        // Iterate through all tracks.
        for (auto& t : tracks)
        {
            // If the track title contains the query, add it to the filtered list.
            if (juce::String(t.title).toLowerCase().contains(query))
                filteredTracks.push_back(t);
        }
        // Update and repaint the table to reflect the filtered tracks.
        tableComponent.updateContent();
        tableComponent.repaint();
        updateEmptyMessageVisibility();
    }
}

//==============================================================================
// saveLibraryToFile: Saves the current track library to an XML file.
// Each track's title, duration, and file path are saved as attributes.
void PlaylistComponent::saveLibraryToFile()
{
    juce::XmlElement library("Library");
    for (auto& track : tracks)
    {
        auto* trackElem = new juce::XmlElement("Track");
        trackElem->setAttribute("title", track.title);
        trackElem->setAttribute("duration", track.duration);
        trackElem->setAttribute("filePath", track.filePath);
        library.addChildElement(trackElem);
    }

    // Save the XML to "musicLibrary.xml" in the user application data directory.
    auto file = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("musicLibrary.xml");
    library.writeToFile(file, {});
}

//==============================================================================
// loadLibraryToFile: Loads the track library from an XML file.
// Clears the current tracks and repopulates them from the file.
void PlaylistComponent::loadLibraryToFile()
{
    auto file = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("musicLibrary.xml");
    if (file.existsAsFile())
    {
        std::unique_ptr<juce::XmlElement> library(juce::XmlDocument::parse(file));
        if (library)
        {
            tracks.clear();
            // Iterate through each child XML element.
            forEachXmlChildElement(*library, trackElem)
            {
                if (trackElem->hasTagName("Track"))
                {
                    // Read track attributes.
                    auto title = trackElem->getStringAttribute("title");
                    auto duration = trackElem->getStringAttribute("duration");
                    auto path = trackElem->getStringAttribute("filePath");
                    juce::Image art;
                    // Add the track to the library.
                    tracks.push_back({ title.toStdString(), duration.toStdString(), path.toStdString(), art });
                }
            }
        }
    }
    // Set filteredTracks to match the full library.
    filteredTracks = tracks;
    tableComponent.updateContent();
    tableComponent.repaint();
    updateEmptyMessageVisibility();
}

//==============================================================================
// loadAlbumArtForFile: Attempts to load album art for a given audio file.
// Looks in the "resources" folder for an image with a matching base file name.
// Supports common image formats such as .jpg, .jpeg, and .png.
juce::Image PlaylistComponent::loadAlbumArtForFile(const juce::File& audioFile)
{
    juce::Image loaded;
    // Locate the "resources" folder relative to this source file.
    juce::File sourceDir(String(__FILE__));
    sourceDir = sourceDir.getParentDirectory();
    juce::File resourcesDir = sourceDir.getChildFile("resources");

    if (!resourcesDir.exists() || !resourcesDir.isDirectory())
        return loaded;

    auto baseName = audioFile.getFileNameWithoutExtension();
    static const char* exts[] = { ".jpg", ".jpeg", ".png" };
    // Look for an image file in the resources folder that matches the audio file name.
    for (auto* ext : exts)
    {
        auto imageFile = resourcesDir.getChildFile(baseName + ext);
        if (imageFile.existsAsFile())
        {
            loaded = juce::ImageFileFormat::loadFrom(imageFile);
            if (loaded.isValid())
                break;
        }
    }
    return loaded;
}

//==============================================================================
// importTrack: Imports an audio track from a file into the library.
// Reads the audio file to determine its duration, extracts the title, loads album art,
// and adds the new track to both the complete and filtered track lists.
void PlaylistComponent::importTrack(const juce::File& file)
{
    juce::AudioFormatManager fmt;
    fmt.registerBasicFormats();

    auto reader = std::unique_ptr<juce::AudioFormatReader>(fmt.createReaderFor(file));
    std::string dur = "N/A";
    if (reader)
    {
        double secs = reader->lengthInSamples / reader->sampleRate;
        int minutes = static_cast<int>(secs / 60);
        int s = static_cast<int>(secs) % 60;
        dur = std::to_string(minutes) + ":" + (s < 10 ? "0" : "") + std::to_string(s);
    }
    std::string title = file.getFileNameWithoutExtension().toStdString();
    // Load album art from the "resources" folder.
    auto art = loadAlbumArtForFile(file);

    // Create a new TrackInfo structure for the imported track.
    TrackInfo newT{ title, dur, file.getFullPathName().toStdString(), art };
    // Add the new track to the main tracks list.
    tracks.push_back(newT);

    // If the current search query is empty or matches the new track title,
    // add the new track to the filtered tracks list.
    auto query = searchBox.getText().toLowerCase();
    if (query.isEmpty() || juce::String(newT.title).toLowerCase().contains(query))
        filteredTracks.push_back(newT);

    // Save the updated library to file and update the empty message visibility.
    saveLibraryToFile();
    updateEmptyMessageVisibility();
}

//==============================================================================
// updateEmptyMessageVisibility: Updates the visibility of the empty message label.
// If the filtered track list is empty, the label is shown; otherwise, it is hidden.
void PlaylistComponent::updateEmptyMessageVisibility()
{
    emptyMessageLabel.setVisible(filteredTracks.empty());
}
