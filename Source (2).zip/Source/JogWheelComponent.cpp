#include "JogWheelComponent.h"

//==============================================================================
// Constructor for JogWheelComponent
//==============================================================================
// Initializes the jog wheel component and sets its custom LookAndFeel,
// which handles all the drawing of the jog wheel (outer ring, inner disc, album art, etc.).
JogWheelComponent::JogWheelComponent()
{
    // Set the LookAndFeel to our custom JogWheelLookAndFeel instance.
    setLookAndFeel(&lookAndFeel);
}

//==============================================================================
// Destructor for JogWheelComponent
//==============================================================================
// Resets the LookAndFeel to avoid any dangling pointer issues.
JogWheelComponent::~JogWheelComponent()
{
    setLookAndFeel(nullptr);
}

//==============================================================================
// setJogWheelCallback
//==============================================================================
// Allows external code to register a callback function that receives a float value,
// representing the change in angle (in degrees) when the jog wheel is rotated.
void JogWheelComponent::setJogWheelCallback(std::function<void(float)> callback)
{
    onJogWheelMove = callback;
}

//==============================================================================
// setAngle
//==============================================================================
// Sets the current rotation angle of the jog wheel (in degrees).
// The angle is normalized to be within the range [0, 360) degrees.
// Triggers a repaint to update the visual representation.
void JogWheelComponent::setAngle(float angleDegrees)
{
    // Use modulus to ensure the angle wraps around after 360.
    currentAngle = std::fmod(angleDegrees, 360.0f);
    if (currentAngle < 0.0f)
        currentAngle += 360.0f;
    // Repaint the component to reflect the new angle.
    repaint();
}

//==============================================================================
// setAlbumArt
//==============================================================================
// Sets the album art image that is displayed in the center of the jog wheel.
// If a valid image is provided, the wheel will repaint to show it.
void JogWheelComponent::setAlbumArt(const juce::Image& img)
{
    albumArt = img;
    repaint();
}

//==============================================================================
// paint
//==============================================================================
// Custom paint method for the jog wheel.
// Delegates drawing to the custom LookAndFeel's drawJogWheel method.
// If the LookAndFeel cast fails, it fills the component with a fallback dark grey color.
void JogWheelComponent::paint(juce::Graphics& g)
{
    // Attempt to cast the current LookAndFeel to our custom JogWheelLookAndFeel.
    if (auto* laf = dynamic_cast<JogWheelLookAndFeel*>(&getLookAndFeel()))
        // Draw the jog wheel using the custom drawing routine.
        laf->drawJogWheel(g, getLocalBounds().toFloat(), currentAngle, albumArt, 16);
    else
        // Fallback: if the custom LookAndFeel is not set, fill with dark grey.
        g.fillAll(juce::Colours::darkgrey);
}

//==============================================================================
// resized
//==============================================================================
// This component does not have any sub-components that need layout adjustment.
// The method is overridden for completeness.
void JogWheelComponent::resized()
{
    // No special layout needed; all drawing is done in paint().
}

//==============================================================================
// mouseDown
//==============================================================================
// Called when the mouse button is pressed.
// Records the initial angle between the mouse position and the center of the component,
// so that the subsequent drag operations can compute the rotation delta accurately.
void JogWheelComponent::mouseDown(const juce::MouseEvent& event)
{
    // Calculate the center point of the component.
    auto center = getLocalBounds().toFloat().getCentre();
    // Compute the difference vector from the center to the mouse position.
    auto diff = event.position - center;
    // Compute the angle (in radians) using arctan2, which handles quadrants correctly.
    float angle = std::atan2(diff.y, diff.x);
    // Convert the angle from radians to degrees.
    lastAngle = juce::radiansToDegrees(angle);
    // Adjust if the angle is negative to ensure it is within 0 to 360 degrees.
    if (lastAngle < 0)
        lastAngle += 360.0f;
}

//==============================================================================
// mouseDrag
//==============================================================================
// Called when the mouse is dragged.
// Computes the new angle based on the current mouse position relative to the center,
// calculates the delta (change in angle) since the last recorded angle,
// and then calls the registered callback (if any) with the delta value.
// Also updates the current angle of the jog wheel accordingly.
void JogWheelComponent::mouseDrag(const juce::MouseEvent& event)
{
    // Calculate the center point of the component.
    auto center = getLocalBounds().toFloat().getCentre();
    // Compute the difference vector from the center to the current mouse position.
    auto diff = event.position - center;
    // Calculate the new angle (in radians) using arctan2.
    float angle = std::atan2(diff.y, diff.x);
    // Convert the new angle from radians to degrees.
    float newAng = juce::radiansToDegrees(angle);
    if (newAng < 0)
        newAng += 360.0f;

    // Compute the difference between the new angle and the last recorded angle.
    float deltaAngle = newAng - lastAngle;
    // Handle wrap-around: if the delta is too large (positive or negative), adjust it.
    if (deltaAngle > 180.0f)
        deltaAngle -= 360.0f;
    else if (deltaAngle < -180.0f)
        deltaAngle += 360.0f;

    // Update the last recorded angle with the new angle.
    lastAngle = newAng;
    // If a callback has been set, call it with the computed delta.
    if (onJogWheelMove)
        onJogWheelMove(deltaAngle);

    // Update the current angle of the jog wheel by adding the delta.
    setAngle(currentAngle + deltaAngle);
}
