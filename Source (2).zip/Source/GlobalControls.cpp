#include "GlobalControls.h"

// LED colors for volumeBarLeft / volumeBarRight.
// This static array defines a gradient of colors used to simulate an LED-style volume meter.
// The colors range from cyan at the bottom to dark red at the top, representing increasing volume levels.
static const juce::Colour ledColours[] =
{
    juce::Colour::fromRGB(0, 255, 255), // bottom-most segment (cyan)
    juce::Colour::fromRGB(0, 255, 200),
    juce::Colour::fromRGB(0, 255, 150),
    juce::Colour::fromRGB(0, 255,   0), // middle segment (green)
    juce::Colour::fromRGB(100, 255,   0),
    juce::Colour::fromRGB(180, 255,   0),
    juce::Colour::fromRGB(255, 255,   0), // yellow segment
    juce::Colour::fromRGB(255, 180,   0), // orange segment
    juce::Colour::fromRGB(255, 130,   0),
    juce::Colour::fromRGB(255,  70,   0),
    juce::Colour::fromRGB(255,   0,   0), // red segment
    juce::Colour::fromRGB(200,   0,   0)  // top-most segment (dark red)
};

//==============================================================================
// GlobalControlsLookAndFeel Implementation
//==============================================================================

// Constructor for GlobalControlsLookAndFeel.
// Currently, it does not initialize any special settings.
GlobalControlsLookAndFeel::GlobalControlsLookAndFeel() {}

// Destructor for GlobalControlsLookAndFeel.
GlobalControlsLookAndFeel::~GlobalControlsLookAndFeel() {}

// drawLinearSlider: Custom rendering of a linear slider based on its name and style.
// Depending on the slider's name and orientation, different visual styles are applied.
void GlobalControlsLookAndFeel::drawLinearSlider(juce::Graphics& g,
    int x, int y, int width, int height,
    float sliderPos, float minSliderPos,
    float maxSliderPos,
    const juce::Slider::SliderStyle style,
    juce::Slider& slider)
{
    // Retrieve the slider's name to decide which custom style to use.
    juce::String sliderName = slider.getName();

    //============================================================================
    // 1) volumeBarLeft / volumeBarRight => LED style vertical slider
    //============================================================================
    // If the slider is either "volumeBarLeft" or "volumeBarRight" and is vertical,
    // render it using an LED-style display.
    if ((sliderName == "volumeBarLeft" || sliderName == "volumeBarRight")
        && style == juce::Slider::LinearVertical)
    {
        // Calculate the fraction of the slider's range that is "lit" based on its current value.
        float range = slider.getMaximum() - slider.getMinimum();
        float value = slider.getValue() - slider.getMinimum();
        float fraction = (range > 0.0f) ? (value / range) : 0.0f;

        // Determine the number of LED segments using the static ledColours array.
        const int numSegments = (int)(sizeof(ledColours) / sizeof(juce::Colour));
        // Calculate the height of each LED segment.
        float segmentHeight = (float)height / (float)numSegments;
        // Determine the number of segments that should be lit based on the current fraction.
        int litSegments = (int)std::ceil(fraction * numSegments);

        // Fill the background with black to provide a clean slate.
        g.setColour(juce::Colours::black);
        g.fillRect(x, y, width, height);

        // Loop through each segment from bottom to top.
        for (int i = 0; i < numSegments; ++i)
        {
            // Calculate the y-position for the current segment.
            float segY = (float)y + height - (i + 1) * segmentHeight;
            // Define the rectangle for the current segment, with a small gap between segments.
            juce::Rectangle<float> segmentRect((float)x, segY, (float)width, segmentHeight - 1.0f);

            // Set the segment color: use the LED color if the segment is "lit", otherwise a slightly bright black.
            if (i < litSegments)
                g.setColour(ledColours[i]);
            else
                g.setColour(juce::Colours::black.brighter(0.2f));

            // Fill the rectangle with the chosen color.
            g.fillRect(segmentRect);
        }

        // Draw a dark grey border around the entire LED display.
        g.setColour(juce::Colours::darkgrey);
        g.drawRect((float)x, (float)y, (float)width, (float)height, 2.0f);
        return;
    }

    //============================================================================
    // 2) Crossfade => horizontal slider with partial green track and rectangular knob
    //============================================================================
    // If the slider is named "crossfade" and is horizontal, render it with a custom style.
    if (sliderName == "crossfade" && style == juce::Slider::LinearHorizontal)
    {
        // Calculate the center y-coordinate of the slider area.
        float centerY = (float)y + (float)height * 0.5f;

        // Fill the slider background with black.
        g.setColour(juce::Colours::black);
        g.fillRect(x, y, width, height);

        // Define the start and end x-coordinates of the slider.
        float startX = (float)x;
        float endX = (float)x + (float)width;
        // The current slider position represents the knob's x-coordinate.
        float knobX = sliderPos;

        // Draw the green portion of the track from the left end up to the knob.
        g.setColour(juce::Colours::green);
        g.drawLine(startX, centerY, knobX, centerY, 2.0f);

        // Draw the white portion of the track from the knob to the right end.
        g.setColour(juce::Colours::white);
        g.drawLine(knobX, centerY, endX, centerY, 2.0f);

        // Draw a rectangular knob with horizontal stripes.
        float knobWidth = 40.0f;
        float knobHeight = 20.0f;
        // Center the knob horizontally around knobX.
        float knobLeft = knobX - knobWidth * 0.5f;
        // Center the knob vertically around centerY.
        float knobTop = centerY - knobHeight * 0.5f;
        juce::Rectangle<float> knobRect(knobLeft, knobTop, knobWidth, knobHeight);

        // Define the number of stripes to draw on the knob.
        const int numStripes = 6;
        // Calculate the width of each stripe.
        float stripeW = knobRect.getWidth() / (float)numStripes;
        // Loop through each stripe.
        for (int i = 0; i < numStripes; ++i)
        {
            // Calculate the x-position for the current stripe.
            float sX = knobLeft + i * stripeW;
            // Define the stripe's rectangle, with a small gap to separate stripes.
            juce::Rectangle<float> stripeRect(sX, knobTop, stripeW - 1.0f, knobHeight);

            // Alternate stripe colors for a subtle pattern: darker and slightly transparent white.
            if ((i % 2) == 0)
                g.setColour(juce::Colours::white.darker(0.1f));
            else
                g.setColour(juce::Colours::white.withAlpha(0.8f));

            // Fill the stripe rectangle.
            g.fillRect(stripeRect);
        }

        // Draw a dark grey border around the knob to outline it.
        g.setColour(juce::Colours::darkgrey);
        g.drawRect(knobRect, 2.0f);
        return;
    }

    //============================================================================
    // 3) drive, width, 8d => Vertical sliders replicating DeckGUIControls style
    //============================================================================
    // If the slider is named "drive", "width", or "8d" and is vertical, render using a specific style.
    if ((sliderName == "drive" || sliderName == "width" || sliderName == "8d")
        && style == juce::Slider::LinearVertical)
    {
        // 1) Draw the slider's track background:
        // Calculate the x-position for the track, centered in the slider.
        const int trackX = x + width / 2;
        const int trackWidth = 6;
        // Fill a black rectangle for the track.
        g.setColour(juce::Colours::black);
        g.fillRect(trackX - trackWidth / 2, y, trackWidth, height);

        // 2) Draw a white line along the track.
        g.setColour(juce::Colours::white);
        g.drawLine((float)trackX, (float)y, (float)trackX, (float)(y + height), 2.0f);

        // 3) Calculate the normalized slider value (between 0 and 1).
        float sliderRange = slider.getMaximum() - slider.getMinimum();
        float sliderValueNorm = 0.0f;
        if (sliderRange > 0.0f)
            sliderValueNorm = (slider.getValue() - slider.getMinimum()) / sliderRange;

        // 4) Draw tick marks next to the track.
        // These ticks change to green up to the current slider value.
        const int scaleX = trackX + 15;
        const int numTicks = 5;
        for (int i = 0; i <= numTicks; ++i)
        {
            // Determine the fractional position for each tick.
            float frac = (float)i / (float)numTicks;
            // Calculate the y-coordinate for the tick.
            int tickY = y + (int)(height - height * frac);
            // Set the tick color: green if below the current value, white otherwise.
            juce::Colour tickColour = (sliderValueNorm >= frac) ? juce::Colours::green
                : juce::Colours::white;
            g.setColour(tickColour);
            // Draw a small horizontal line for the tick.
            g.drawLine((float)scaleX, (float)tickY,
                (float)(scaleX + 10), (float)tickY, 1.0f);
        }

        // 5) Draw the slider knob as a rectangular box with horizontal stripes.
        float knobCenterY = sliderPos; // The vertical position of the knob.
        float knobHeight = 40.0f;
        float knobWidth = 20.0f;
        // Calculate the top of the knob so it is centered on the sliderPos.
        float knobTop = knobCenterY - knobHeight * 0.5f;
        // Center the knob horizontally along the track.
        float knobLeft = (float)trackX - knobWidth * 0.5f;
        juce::Rectangle<float> knobRect(knobLeft, knobTop, knobWidth, knobHeight);

        // Draw stripes on the knob to add visual texture.
        const int numStripes = 6;
        float stripeHeight = knobRect.getHeight() / (float)numStripes;
        for (int i = 0; i < numStripes; ++i)
        {
            // Calculate the y-coordinate for the current stripe.
            float stripeY = knobTop + i * stripeHeight;
            // Define the rectangle for the stripe.
            juce::Rectangle<float> stripeRect(knobLeft, stripeY, knobWidth, stripeHeight - 1.0f);

            // Alternate the brightness of the stripes for visual contrast.
            if ((i % 2) == 0)
                g.setColour(juce::Colours::white.darker(0.1f));
            else
                g.setColour(juce::Colours::white.brighter(0.1f));

            // Fill the stripe rectangle.
            g.fillRect(stripeRect);
        }

        // Draw a dark grey border around the knob.
        g.setColour(juce::Colours::darkgrey);
        g.drawRect(knobRect, 2.0f);
        return;
    }

    //============================================================================
    // Fallback: For any other slider types, use the default LookAndFeel_V4 drawing.
    //============================================================================
    juce::LookAndFeel_V4::drawLinearSlider(g, x, y, width, height,
        sliderPos, minSliderPos, maxSliderPos,
        style, slider);
}

//==============================================================================
// GlobalControls Implementation
//==============================================================================

// Constructor for GlobalControls.
// Sets up the global control components (sliders and labels) and applies the custom LookAndFeel.
GlobalControls::GlobalControls()
{
    // Apply our custom LookAndFeel to this component.
    setLookAndFeel(&globalLNF);

    // ----------------
    // Setup for Crossfade (horizontal slider)
    // ----------------
    crossfadeSlider.setName("crossfade");
    // Use a horizontal linear style.
    crossfadeSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    // Set the range of the slider from 0.0 to 1.0 with a step of 0.01.
    crossfadeSlider.setRange(0.0, 1.0, 0.01);
    // Do not display a text box.
    crossfadeSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    // Add the slider to the component.
    addAndMakeVisible(crossfadeSlider);

    // Configure the label for the crossfade slider.
    crossfadeLabel.setText("Crossfade", juce::dontSendNotification);
    crossfadeLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(crossfadeLabel);

    // ----------------
    // Setup for volumeBarLeft (vertical LED-style slider)
    // ----------------
    volumeBarLeft.setName("volumeBarLeft");
    // Use a vertical linear style.
    volumeBarLeft.setSliderStyle(juce::Slider::LinearVertical);
    // Set range from 0.0 to 1.0.
    volumeBarLeft.setRange(0.0, 1.0, 0.01);
    // Do not display a text box.
    volumeBarLeft.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(volumeBarLeft);

    // Configure the label for the left volume bar.
    volumeBarLeftLabel.setText("Volume L", juce::dontSendNotification);
    volumeBarLeftLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(volumeBarLeftLabel);

    // ----------------
    // Setup for drive slider (vertical) - controls Distortion/Drive effect.
    // ----------------
    driveSlider.setName("drive");
    driveSlider.setSliderStyle(juce::Slider::LinearVertical);
    // Range from 0.0 (no drive) to 1.0 (max drive) with step of 0.01.
    driveSlider.setRange(0.0, 1.0, 0.01);
    driveSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(driveSlider);

    // Configure the label for the drive slider.
    driveLabel.setText("Drive", juce::dontSendNotification);
    driveLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(driveLabel);

    // ----------------
    // Setup for width slider (vertical) - controls Stereo Width effect.
    // ----------------
    widthSlider.setName("width");
    widthSlider.setSliderStyle(juce::Slider::LinearVertical);
    // Range from 0.0 (mono) to 1.5 (extra wide) with a step of 0.01.
    widthSlider.setRange(0.0, 1.5, 0.01);
    widthSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(widthSlider);

    // Configure the label for the width slider.
    widthLabel.setText("Width", juce::dontSendNotification);
    widthLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(widthLabel);

    // ----------------
    // Setup for eightD slider (vertical) - controls 8D audio effect.
    // ----------------
    eightDSlider.setName("8d");
    eightDSlider.setSliderStyle(juce::Slider::LinearVertical);
    // Range from 0.0 (effect off) to 1.0 (max effect) with a step of 0.01.
    eightDSlider.setRange(0.0, 1.0, 0.01);
    eightDSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(eightDSlider);

    // Configure the label for the eightD slider.
    eightDLabel.setText("8D", juce::dontSendNotification);
    eightDLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(eightDLabel);

    // ----------------
    // Setup for volumeBarRight (vertical LED-style slider)
    // ----------------
    volumeBarRight.setName("volumeBarRight");
    volumeBarRight.setSliderStyle(juce::Slider::LinearVertical);
    volumeBarRight.setRange(0.0, 1.0, 0.01);
    volumeBarRight.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    addAndMakeVisible(volumeBarRight);

    // Configure the label for the right volume bar.
    volumeBarRightLabel.setText("Volume R", juce::dontSendNotification);
    volumeBarRightLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(volumeBarRightLabel);

    // ----------------
    // Setup slider callbacks.
    // Each slider's onValueChange lambda will call the corresponding external callback,
    // if it has been set by the parent component.
    // ----------------

    // Crossfade slider callback.
    crossfadeSlider.onValueChange = [this]()
        {
            if (onCrossfadeChanged)
                onCrossfadeChanged(crossfadeSlider.getValue());
        };

    // Drive slider callback.
    driveSlider.onValueChange = [this]()
        {
            if (onDriveChanged)
                onDriveChanged(driveSlider.getValue());
        };

    // Width slider callback.
    widthSlider.onValueChange = [this]()
        {
            if (onWidthChanged)
                onWidthChanged(widthSlider.getValue());
        };

    // 8D slider callback.
    eightDSlider.onValueChange = [this]()
        {
            if (onEightDChanged)
                onEightDChanged(eightDSlider.getValue());
        };
}

// Destructor for GlobalControls.
// Resets the LookAndFeel to prevent dangling pointers.
GlobalControls::~GlobalControls()
{
    setLookAndFeel(nullptr);
}

// paint: Custom paint method for GlobalControls.
// Fills the entire background with black.
void GlobalControls::paint(juce::Graphics& g)
{
    // Fill entire background with black.
    g.fillAll(juce::Colours::black);
}

// resized: Layout method called when the component is resized.
// Arranges the crossfade slider at the top and five vertical sliders below in equal columns.
void GlobalControls::resized()
{
    // Get the bounds of the component.
    auto area = getLocalBounds();

    // --- Top: Crossfade slider ---
    // Define a fixed height for the crossfade area.
    const int crossfadeHeight = 60;
    auto crossfadeArea = area.removeFromTop(crossfadeHeight);

    // Reserve space for the label (either on the right or above).
    const int labelWidth = 80;
    // Set bounds for the crossfade slider in the remaining area after reserving label width.
    crossfadeSlider.setBounds(crossfadeArea.removeFromLeft(crossfadeArea.getWidth() - labelWidth).reduced(5));
    // Set bounds for the crossfade label.
    crossfadeLabel.setBounds(crossfadeArea.reduced(5));

    // --- Bottom: Row of 5 vertical sliders ---
    int numColumns = 5;
    // Calculate the width for each column by dividing the remaining area width by the number of columns.
    int columnWidth = area.getWidth() / numColumns;

    // Layout for volumeBarLeft.
    auto volLeftArea = area.removeFromLeft(columnWidth);
    // Trim the top and bottom to create margins.
    volumeBarLeft.setBounds(volLeftArea.withTrimmedTop(10).withTrimmedBottom(20));
    // Place the label at the bottom of the allocated area.
    volumeBarLeftLabel.setBounds(volLeftArea.removeFromBottom(20));

    // Layout for drive slider.
    auto driveArea = area.removeFromLeft(columnWidth);
    driveSlider.setBounds(driveArea.withTrimmedTop(10).withTrimmedBottom(20));
    driveLabel.setBounds(driveArea.removeFromBottom(20));

    // Layout for width slider.
    auto widthArea = area.removeFromLeft(columnWidth);
    widthSlider.setBounds(widthArea.withTrimmedTop(10).withTrimmedBottom(20));
    widthLabel.setBounds(widthArea.removeFromBottom(20));

    // Layout for eightD slider.
    auto eightDArea = area.removeFromLeft(columnWidth);
    eightDSlider.setBounds(eightDArea.withTrimmedTop(10).withTrimmedBottom(20));
    eightDLabel.setBounds(eightDArea.removeFromBottom(20));

    // Layout for volumeBarRight.
    auto volRightArea = area; // Remaining area for the right volume bar.
    volumeBarRight.setBounds(volRightArea.withTrimmedTop(10).withTrimmedBottom(20));
    volumeBarRightLabel.setBounds(volRightArea.removeFromBottom(20));
}

// setVolumeLevels: Updates the values of the LED-style volume meters.
// This function is called externally (e.g., by audio metering code) to reflect the current volume levels.
// It updates the sliders without sending a notification, so callbacks are not triggered.
void GlobalControls::setVolumeLevels(double leftLevel, double rightLevel)
{
    volumeBarLeft.setValue(leftLevel, juce::dontSendNotification);
    volumeBarRight.setValue(rightLevel, juce::dontSendNotification);
}
