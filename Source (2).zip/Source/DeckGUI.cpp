#include "DeckGUI.h"

//==============================================================================
// DeckGUI Constructor
//==============================================================================
// Initializes the DeckGUI with a DJAudioPlayer, AudioFormatManager, and AudioThumbnailCache.
// Sets up the waveform display, jog wheel, and beat pad, and establishes callbacks for user interaction.
DeckGUI::DeckGUI(DJAudioPlayer* _player,
    juce::AudioFormatManager& formatManagerToUse,
    juce::AudioThumbnailCache& cacheToUse)
    : player(_player),
    waveformDisplay(formatManagerToUse, cacheToUse)
{
    // Make the waveform display visible and add it to the component.
    addAndMakeVisible(waveformDisplay);

    // Make the jog wheel visible.
    addAndMakeVisible(bigJogWheel);
    // Set a callback for the jog wheel to adjust the track position based on rotation.
    bigJogWheel.setJogWheelCallback([this](float deltaAngle)
        {
            // The idea is to map a full 360 degree rotation to the entire track range [0..1].
            double currentPos = player->getPositionRelative();
            double newPos = currentPos + (deltaAngle / 360.0);
            // Clamp the new position between 0 and 1.
            newPos = juce::jlimit(0.0, 1.0, newPos);
            player->setPositionRelative(newPos);
        });

    // Make the beat pad component visible.
    addAndMakeVisible(beatPadComponent);

    // Register the waveform display with the audio player so it receives sample data.
    player->setWaveformDisplay(&waveformDisplay);

    // Start the timer to update visuals (approximately 25 times per second)
    // This timer is used to animate the jog wheel.
    startTimerHz(25);
}

//==============================================================================
// DeckGUI Destructor
//==============================================================================
// Stops the timer when the DeckGUI is destroyed.
DeckGUI::~DeckGUI()
{
    stopTimer();
}

//==============================================================================
// Paint Method
//==============================================================================
// Fills the background with black and draws a descriptive text at the top left.
void DeckGUI::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::black);
    g.setColour(juce::Colours::white);
    g.setFont(15.0f);
    g.drawFittedText("Deck GUI (Waveform + JogWheel + BeatPad)",
        getLocalBounds().reduced(10),
        juce::Justification::topLeft,
        1);
}

//==============================================================================
// Resized Method
//==============================================================================
// Lays out the subcomponents in the following vertical arrangement:
// - Top 20%: Waveform Display
// - Middle 50%: Jog Wheel
// - Bottom 30%: Beat Pad
void DeckGUI::resized()
{
    // Get the available area for this component.
    auto area = getLocalBounds();
    int totalHeight = area.getHeight();
    int waveformHeight = (int)(totalHeight * 0.20f);  // Allocate top 20% for waveform display.
    int jogWheelHeight = (int)(totalHeight * 0.50f);    // Allocate middle 50% for the jog wheel.
    // The remaining area (approximately 30%) is for the beat pad.

    // Set bounds for the waveform display with a slight margin.
    auto waveformArea = area.removeFromTop(waveformHeight);
    waveformDisplay.setBounds(waveformArea.reduced(5));

    // Set bounds for the jog wheel with a slightly larger margin.
    auto jogArea = area.removeFromTop(jogWheelHeight);
    bigJogWheel.setBounds(jogArea.reduced(10));

    // Set bounds for the beat pad component with margins.
    beatPadComponent.setBounds(area.reduced(10));
}

//==============================================================================
// Timer Callback Method
//==============================================================================
// Called periodically (25 times per second) to update the jog wheel's angle
// based on the current track playback position.
void DeckGUI::timerCallback()
{
    // Get the current track position as a value between 0 and 1.
    double posRel = player->getPositionRelative(); // [0..1]
    // Map the position to an angle in degrees.
    double angle = posRel * 360.0;
    // Update the jog wheel's angle accordingly.
    bigJogWheel.setAngle((float)angle);
}

//==============================================================================
// Load Track Method
//==============================================================================
// Loads a new track into the audio player and updates the waveform display,
// as well as attempts to load album art from the resources folder.
void DeckGUI::loadTrack(const juce::URL& trackURL)
{
    // 1) Load the audio track into the DJAudioPlayer.
    player->loadURL(trackURL);

    // 2) Load the waveform display in "thumbnail" mode (time-domain representation).
    waveformDisplay.loadURL(trackURL);
    waveformDisplay.setMode(WaveformDisplay::Mode_Thumbnail);

    // 3) Attempt to load album art from the same resources folder as used in the PlaylistComponent.
    juce::File audioFile = trackURL.getLocalFile();

    // Locate the "resources" directory relative to this source file.
    juce::File sourceDir(String(__FILE__));
    sourceDir = sourceDir.getParentDirectory();
    juce::File resourcesDir = sourceDir.getChildFile("resources");

    juce::Image albumArt;
    // Check if the resources directory exists and is a directory.
    if (resourcesDir.exists() && resourcesDir.isDirectory())
    {
        // Extract the base name of the audio file (without extension).
        juce::String baseName = audioFile.getFileNameWithoutExtension();

        // Try several common image file extensions (case-insensitive).
        static const char* exts[] = { ".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG" };
        for (auto* ext : exts)
        {
            // Construct the file path for each potential album art image.
            auto imageFile = resourcesDir.getChildFile(baseName + ext);
            // If the image file exists, attempt to load it.
            if (imageFile.existsAsFile())
            {
                juce::Image temp = juce::ImageFileFormat::loadFrom(imageFile);
                // If the image is valid, store it and break out of the loop.
                if (temp.isValid())
                {
                    albumArt = temp;
                    break; // Found valid album art.
                }
            }
        }
    }

    // 4) Update the jog wheel to display the album art, if found.
    bigJogWheel.setAlbumArt(albumArt);
}
