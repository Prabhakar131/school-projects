#pragma once

#include "../JuceLibraryCode/JuceHeader.h"
#include "DJAudioPlayer.h"
#include "WaveformDisplay.h"
#include "JogWheelComponent.h"
#include "BeatPadComponent.h"

/**
    A simplified DeckGUI that contains only:
    1) A WaveformDisplay at the top,
    2) A JogWheel in the middle,
    3) A BeatPadComponent at the bottom.

    This class inherits from juce::Component to allow custom drawing and layout,
    and from juce::Timer to enable periodic updates (such as for animating the jog wheel).
*/
class DeckGUI : public juce::Component,
    public juce::Timer
{
public:
    // Constructor: Initializes the DeckGUI with an audio player,
    // an audio format manager and a thumbnail cache for the waveform display.
    DeckGUI(DJAudioPlayer* player,
        juce::AudioFormatManager& formatManagerToUse,
        juce::AudioThumbnailCache& cacheToUse);

    // Destructor: Ensures proper cleanup of the DeckGUI.
    ~DeckGUI() override;

    // Custom painting routine for the DeckGUI component.
    void paint(juce::Graphics& g) override;

    // Called when the component is resized, and lays out subcomponents.
    void resized() override;

    // Timer callback: used here to update or rotate the jog wheel periodically.
    void timerCallback() override;

    // Loads a track from a given URL to display its waveform.
    // Useful for updating the WaveformDisplay with new track data.
    void loadTrack(const juce::URL& trackURL);

    // ***** New Public Getter to expose the BeatPadComponent as an AudioSource *****
    // Provides access to the BeatPadComponent for further audio processing or control.
    BeatPadComponent& getBeatPadComponent() { return beatPadComponent; }

private:
    // Pointer to the DJAudioPlayer instance to control audio playback.
    DJAudioPlayer* player;

    // Waveform display component located at the top of the DeckGUI.
    WaveformDisplay waveformDisplay;

    // Jog wheel component located in the middle of the DeckGUI,
    // which may be used for adjusting playback or simulating vinyl controls.
    JogWheelComponent bigJogWheel;

    // Beat pad component located at the bottom of the DeckGUI,
    // likely used for triggering samples or beats.
    BeatPadComponent beatPadComponent;

    // Macro to help catch any potential memory leaks.
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DeckGUI)
};
