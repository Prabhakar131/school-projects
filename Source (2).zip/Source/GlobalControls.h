#pragma once

#include <JuceHeader.h>

/**
    A custom LookAndFeel to draw:
    - Two vertical "LED-style" sliders ("volumeBarLeft" & "volumeBarRight")
    - One horizontal slider ("crossfade") with partial green track + rectangular knob
    - Three vertical sliders ("drive", "width", "8d") using the same style
      as your DeckGUIControls vertical sliders:
       * black track background, white line, green tick marks,
       * rectangular knob with stripes
*/
class GlobalControlsLookAndFeel : public juce::LookAndFeel_V4
{
public:
    GlobalControlsLookAndFeel();
    ~GlobalControlsLookAndFeel() override;

    void drawLinearSlider(juce::Graphics& g,
        int x, int y, int width, int height,
        float sliderPos, float minSliderPos, float maxSliderPos,
        const juce::Slider::SliderStyle style,
        juce::Slider& slider) override;

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(GlobalControlsLookAndFeel)
};

/**
    GlobalControls is a component containing:
    - One horizontal slider at the top ("crossfade")
    - Five vertical sliders in a row below:
        * "volumeBarLeft"  (LED-style)
        * "drive"          (to control the Distortion/Drive effect)
        * "width"          (to control the Stereo Width effect)
        * "8d"             (to control the 8D audio effect)
        * "volumeBarRight" (LED-style)
*/
class GlobalControls : public juce::Component
{
public:
    GlobalControls();
    ~GlobalControls() override;

    void paint(juce::Graphics& g) override;
    void resized() override;

    // Callback functions for slider changes (set by the parent)
    std::function<void(double)> onCrossfadeChanged;
    std::function<void(double)> onDriveChanged;
    std::function<void(double)> onWidthChanged;
    std::function<void(double)> onEightDChanged;

    // Call this method from external audio metering code to update the volume meters.
    void setVolumeLevels(double leftLevel, double rightLevel);

private:
    GlobalControlsLookAndFeel globalLNF;

    // Top horizontal slider
    juce::Slider crossfadeSlider;
    juce::Label  crossfadeLabel;

    // Left LED bar
    juce::Slider volumeBarLeft;
    juce::Label  volumeBarLeftLabel;

    // Three vertical sliders (drive, width, 8d)
    juce::Slider driveSlider;
    juce::Label  driveLabel;

    juce::Slider widthSlider;
    juce::Label  widthLabel;

    juce::Slider eightDSlider;
    juce::Label  eightDLabel;

    // Right LED bar
    juce::Slider volumeBarRight;
    juce::Label  volumeBarRightLabel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(GlobalControls)
};
