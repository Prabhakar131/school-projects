#pragma once

#include <JuceHeader.h>
#include <functional>

/**
    RecordingOptionsComponent is a user interface component that provides controls for
    audio recording. It includes buttons for starting, stopping, and saving recordings.
    In addition, it exposes callback functions for each button action so that external code
    can easily react to user input.

    This component also provides a writeBuffer() method to be called from the audio callback
    in order to write incoming audio data to a file while recording.

    The visual appearance of the component is customized via a nested LookAndFeel class.
*/
class RecordingOptionsComponent : public juce::Component,
    public juce::Button::Listener
{
public:
    //==============================================================================
    // Constructor: Initializes buttons, state variables, and the recording thread.
    RecordingOptionsComponent();
    // Destructor: Ensures proper cleanup and stops the recording thread.
    ~RecordingOptionsComponent() override;

    //==============================================================================
    // Component Overrides

    /**
        paint:
        Custom drawing routine for the component. Typically used to draw background,
        borders, or any additional graphical elements.
    */
    void paint(juce::Graphics& g) override;

    /**
        resized:
        Called when the component's size changes. Lays out child components (buttons) accordingly.
    */
    void resized() override;

    //==============================================================================
    // Button::Listener Override

    /**
        buttonClicked:
        Callback method that is invoked when any of the component's buttons is clicked.
        Determines which button was pressed and triggers the appropriate action.
    */
    void buttonClicked(juce::Button* button) override;

    //==============================================================================
    // Callback Functions for Recording Actions
    // These can be set by the parent component to handle recording events.
    std::function<void()> onStartRecording;
    std::function<void()> onStopRecording;
    std::function<void()> onSaveRecording;

    /**
        writeBuffer:
        Called from the audio callback to write incoming audio data to the recording file.
        Parameters:
            - bufferToFill: Contains the audio data (channels, samples) to be written.
    */
    void writeBuffer(const juce::AudioSourceChannelInfo& bufferToFill);

private:
    //==============================================================================
    // UI Components: Buttons for controlling recording actions.
    juce::TextButton startRecordingButton{ "Start recording" };
    juce::TextButton stopRecordingButton{ "Stop recording" };
    juce::TextButton saveRecordingButton{ "Save recording" };

    //==============================================================================
    // Recording State and Objects:
    // Flag to indicate if a recording is currently in progress.
    bool isRecording = false;
    // Timestamp marking the start time of the recording.
    juce::Time recordStartTime;
    // File object representing the file where recording will be saved.
    juce::File recordedFile;
    // A threaded writer that writes audio data to a file on a separate thread.
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> writer;
    // TimeSliceThread to manage the writer thread for recording.
    juce::TimeSliceThread recordThread{ "Recording Thread" };

    //==============================================================================
    // Custom LookAndFeel for the Recording Options:
    // This nested class customizes the visual appearance of the recording buttons.
    class RecordingOptionsLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        // Constructor: Sets default colors for the buttons.
        RecordingOptionsLookAndFeel()
        {
            // Use a dark navy blue fill for buttons.
            setColour(juce::TextButton::buttonColourId, juce::Colours::navy.darker(0.6f));
            // Set the text color for both states (on and off) to white.
            setColour(juce::TextButton::textColourOffId, juce::Colours::white);
            setColour(juce::TextButton::textColourOnId, juce::Colours::white);
        }

        //==============================================================================
        /**
            drawButtonBackground:
            Customizes the drawing of a button's background.
            Fills the button with a dark navy blue and draws a rounded rectangle border
            with a blue-to-purple gradient that varies in thickness depending on the button state.
            Parameters:
                - g: The graphics context used for drawing.
                - button: The button being drawn.
                - backgroundColour: (Ignored in this override) the default background colour.
                - isMouseOverButton: Indicates whether the mouse is hovering over the button.
                - isButtonDown: Indicates whether the button is being pressed.
        */
        void drawButtonBackground(juce::Graphics& g,
            juce::Button& button,
            const juce::Colour& /*backgroundColour*/,
            bool isMouseOverButton,
            bool isButtonDown) override
        {
            // Get the button's bounds as a float rectangle and slightly reduce it for padding.
            auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);

            // Fill the button with a dark navy blue.
            g.setColour(juce::Colours::navy.darker(0.6f));
            g.fillRoundedRectangle(bounds, 8.0f);

            // Create a gradient for the border: from a bright blue to a bright purple.
            juce::ColourGradient gradient(juce::Colours::blue.brighter(0.8f),
                bounds.getTopLeft().x, bounds.getTopLeft().y,
                juce::Colours::purple.brighter(0.8f),
                bounds.getBottomRight().x, bounds.getBottomRight().y,
                false);
            g.setGradientFill(gradient);

            // Set the border thickness based on the button state:
            // Thicker when pressed, medium when hovered, thin otherwise.
            float thickness = isButtonDown ? 3.0f
                : isMouseOverButton ? 2.0f
                : 1.0f;
            // Draw the rounded border with the computed thickness.
            g.drawRoundedRectangle(bounds, 8.0f, thickness);
        }
    };

    // Instance of the custom LookAndFeel for the recording options.
    RecordingOptionsLookAndFeel customLookAndFeel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RecordingOptionsComponent)
};
