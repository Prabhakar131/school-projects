#pragma once

#include <JuceHeader.h>
#include <vector>
#include <string>
#include <functional>

//==============================================================================
// Structure: TrackInfo
//==============================================================================
// Holds metadata for an audio track, including:
// - title: The track's title.
// - duration: The formatted duration string ("m:ss").
// - filePath: Full file path to the audio file.
// - albumArt: The album art image associated with the track.
struct TrackInfo
{
    std::string title;
    std::string duration; // formatted as "m:ss"
    std::string filePath; // full file path to the audio
    juce::Image albumArt; // album art image
};

//==============================================================================
// PlaylistComponent Class Declaration
//==============================================================================
// PlaylistComponent is a UI component that displays a list of audio tracks in a table.
// It also provides functionality for searching, importing, and selecting tracks.
// This class implements multiple interfaces:
// - juce::Component: Base class for all UI components.
// - juce::TableListBoxModel: Provides model functionality for a table list box.
// - juce::Button::Listener: Receives button click events (e.g., for import button).
// - juce::TextEditor::Listener: Handles changes in the search box input.
class PlaylistComponent : public juce::Component,
    public juce::TableListBoxModel,
    public juce::Button::Listener,
    public juce::TextEditor::Listener
{
public:
    // Constructor: Initializes the playlist component and sets up UI elements.
    PlaylistComponent();
    // Destructor: Cleans up resources.
    ~PlaylistComponent() override;

    //============================================================================== 
    // Component Overrides
    //==============================================================================

    // paint: Custom drawing routine for the component.
    void paint(juce::Graphics& g) override;
    // resized: Called when the component's size changes; layouts child components.
    void resized() override;

    //============================================================================== 
    // TableListBoxModel Methods
    //==============================================================================

    // getNumRows: Returns the number of rows (tracks) in the playlist.
    int getNumRows() override;
    // paintRowBackground: Draws the background for a given row.
    // Parameters include row number, dimensions, and selection state.
    void paintRowBackground(juce::Graphics& g,
        int rowNumber,
        int width,
        int height,
        bool rowIsSelected) override;
    // paintCell: Draws the content of a specific cell in the table.
    void paintCell(juce::Graphics& g,
        int rowNumber,
        int columnId,
        int width,
        int height,
        bool rowIsSelected) override;
    // refreshComponentForCell: Called to provide or update a component for a given cell.
    // Can be used for interactive elements in cells.
    juce::Component* refreshComponentForCell(int rowNumber,
        int columnId,
        bool isRowSelected,
        juce::Component* existingComponentToUpdate) override;

    //============================================================================== 
    // Button::Listener Override
    //==============================================================================

    // buttonClicked: Handles click events from buttons (e.g., the "Import Track" button).
    void buttonClicked(juce::Button* button) override;

    //============================================================================== 
    // TextEditor::Listener Override
    //==============================================================================

    // textEditorTextChanged: Called when the text in the search box changes.
    // Can be used to update the displayed track list based on search criteria.
    void textEditorTextChanged(juce::TextEditor& editor) override;

    //============================================================================== 
    // Callback Functions for Loading Tracks
    //==============================================================================

    // onLoadLeft: A callback function set by the parent component to load a track into the left deck.
    // It receives the file path of the track to be loaded.
    std::function<void(const std::string& filePath)> onLoadLeft;
    // onLoadRight: Similar callback for loading a track into the right deck.
    std::function<void(const std::string& filePath)> onLoadRight;

private:
    //============================================================================== 
    // Custom LookAndFeel for PlaylistComponent
    //==============================================================================

    /**
        PlaylistLookAndFeel is a custom LookAndFeel that alters the visual appearance of
        the playlist component, including:
        - Darker navy backgrounds for table rows and headers.
        - White text for better contrast.
        - Blue-to-purple gradient borders for buttons and the search box.
        - The search bar's border is drawn as a normal rectangle to ensure text remains visible.
    */
    class PlaylistLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        // Constructor: Sets up the colours for various elements.
        PlaylistLookAndFeel()
        {
            // Set the overall background colour to black.
            setColour(juce::ResizableWindow::backgroundColourId, juce::Colours::black);

            // Set the table header background to a darker navy.
            setColour(juce::TableHeaderComponent::backgroundColourId, juce::Colours::navy.darker(0.7f));
            // Set the table header text colour to white.
            setColour(juce::TableHeaderComponent::textColourId, juce::Colours::white);

            // Set the table list background colour to black.
            setColour(juce::TableListBox::backgroundColourId, juce::Colours::black);

            // Set the button text colours (for both off and on states) to white.
            setColour(juce::TextButton::textColourOffId, juce::Colours::white);
            setColour(juce::TextButton::textColourOnId, juce::Colours::white);
        }

        // Override for drawing a button's background.
        // Draws a navy background with a blue-to-purple gradient stroke around the edges.
        void drawButtonBackground(juce::Graphics& g,
            juce::Button& button,
            const juce::Colour& /*backgroundColour*/,
            bool isMouseOverButton,
            bool isButtonDown) override
        {
            auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);

            // Fill the button with a darker navy colour.
            g.setColour(juce::Colours::navy.darker(0.6f));
            g.fillRoundedRectangle(bounds, 8.0f);

            // Create a gradient from blue (top-left) to purple (bottom-right) for the border.
            juce::ColourGradient gradient(juce::Colours::blue,
                bounds.getTopLeft().x,
                bounds.getTopLeft().y,
                juce::Colours::purple,
                bounds.getBottomRight().x,
                bounds.getBottomRight().y,
                false);

            g.setGradientFill(gradient);

            // Determine the stroke thickness based on button state.
            float thickness = isButtonDown ? 3.0f
                : isMouseOverButton ? 2.0f
                : 1.0f;
            // Draw the rounded border.
            g.drawRoundedRectangle(bounds, 8.0f, thickness);
        }

        // Override for drawing the outline of a TextEditor.
        // Draws a normal rectangular border with a blue-to-purple gradient.
        void drawTextEditorOutline(juce::Graphics& g,
            int width,
            int height,
            juce::TextEditor& /*editor*/) override
        {
            juce::Rectangle<float> r(0.0f, 0.0f, (float)width, (float)height);
            r = r.reduced(1.0f);

            // Create a gradient from blue to purple.
            juce::ColourGradient gradient(juce::Colours::blue,
                r.getTopLeft().x,
                r.getTopLeft().y,
                juce::Colours::purple,
                r.getBottomRight().x,
                r.getBottomRight().y,
                false);

            g.setGradientFill(gradient);
            // Draw a normal rectangle border with a thickness of 2.0f.
            g.drawRect(r, 2.0f);
        }
    };

    //============================================================================== 
    // Private Members of PlaylistComponent
    //==============================================================================

    // Instance of the custom look and feel.
    PlaylistLookAndFeel playlistLookAndFeel;

    // TableListBox component that displays the track list.
    juce::TableListBox tableComponent;
    // Vector of all tracks in the library.
    std::vector<TrackInfo> tracks;
    // Vector of tracks filtered based on search criteria.
    std::vector<TrackInfo> filteredTracks;

    // TextEditor used as a search box for filtering tracks.
    juce::TextEditor searchBox;
    // Button for importing a new track into the playlist.
    juce::TextButton importButton; // "Import Track" button

    // Label displayed when no tracks are available.
    juce::Label emptyMessageLabel;

    // Helper function to save the current library to a file.
    void saveLibraryToFile();
    // Helper function to load the library from a file.
    void loadLibraryToFile();

    // Helper function to load album art for a given audio file.
    juce::Image loadAlbumArtForFile(const juce::File& audioFile);

    // Helper function to import a track from a file.
    void importTrack(const juce::File& file);

    // Updates the visibility of the empty message label depending on whether there are tracks.
    void updateEmptyMessageVisibility();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PlaylistComponent)
};
