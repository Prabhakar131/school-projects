#pragma once

#include <JuceHeader.h>
#include <vector>
#include <deque>

/**
    WaveformDisplay is a component that visualizes audio waveforms.
    It supports two visualization modes:
      - Mode_Thumbnail: Displays a static time-domain thumbnail of the loaded audio.
      - Mode_FFT: Displays a dynamic FFT (frequency domain) visualization.

    The class uses a timer to update the FFT visualization and listens for changes
    from the AudioThumbnail to update the display when the audio file is loaded.
*/
class WaveformDisplay : public juce::Component,
    public juce::Timer,
    public juce::ChangeListener
{
public:
    // Enum to select between two visualization modes.
    enum VisualizerMode
    {
        Mode_Thumbnail, // Display a static time-domain thumbnail.
        Mode_FFT        // Display a real-time FFT visualization.
    };

    /**
        Constructor: Initializes the WaveformDisplay.
        Parameters:
          - formatManager: Reference to an AudioFormatManager to support loading different audio formats.
          - cache: Reference to an AudioThumbnailCache to cache and speed up thumbnail drawing.
    */
    WaveformDisplay(juce::AudioFormatManager& formatManager,
        juce::AudioThumbnailCache& cache);

    // Destructor: Ensures proper cleanup.
    ~WaveformDisplay() override;

    //==============================================================================
    // Component Overrides

    /**
        paint:
        Custom drawing routine for the component.
        Depending on the current mode (thumbnail or FFT), different visualizations are drawn.
    */
    void paint(juce::Graphics& g) override;

    /**
        resized:
        Called when the component's size changes.
        Can be used to adjust internal layout if necessary.
    */
    void resized() override;

    //==============================================================================
    // Visualization Control Methods

    /**
        setMode:
        Sets the visualization mode.
        Parameters:
          - newMode: The new mode (Mode_Thumbnail or Mode_FFT).
    */
    void setMode(VisualizerMode newMode);

    /**
        loadURL:
        Loads an audio file from the given URL.
        When called, it updates the time-domain thumbnail display.
        Parameters:
          - audioURL: The URL of the audio file to load.
    */
    void loadURL(const juce::URL& audioURL);

    /**
        pushNextSampleIntoFifo:
        Called from the audio thread for every incoming sample.
        This method adds the sample into a FIFO (first-in, first-out) buffer for FFT processing.
        Parameters:
          - sample: The next audio sample.
    */
    void pushNextSampleIntoFifo(float sample);

    //==============================================================================
    // Timer Callback and ChangeListener Methods

    /**
        timerCallback:
        Called periodically on a non-audio thread.
        Used to trigger a repaint of the component once the FFT data is ready.
    */
    void timerCallback() override;

    /**
        changeListenerCallback:
        Callback method for ChangeBroadcaster sources.
        For example, this is used to listen for changes in the AudioThumbnail
        when a new file is loaded.
        Parameters:
          - source: Pointer to the ChangeBroadcaster that has sent the notification.
    */
    void changeListenerCallback(juce::ChangeBroadcaster* source) override;

private:
    //==============================================================================
    /**
        drawFFTGrid:
        Helper method to draw a grid (frequency/amplitude lines) over the FFT visualization.
        This grid can aid in reading frequency and amplitude values from the display.
        Parameters:
          - g: The graphics context.
          - width: Width of the component.
          - height: Height of the component.
    */
    void drawFFTGrid(juce::Graphics& g, float width, float height);

    // Current visualization mode (thumbnail or FFT).
    VisualizerMode mode = Mode_Thumbnail;

    //==============================================================================
    // Members for Thumbnail Visualization

    // AudioThumbnail is used to display a time-domain waveform thumbnail.
    juce::AudioThumbnail audioThumb;
    // Flag to indicate if a file has been successfully loaded.
    bool fileLoaded = false;

    //==============================================================================
    // Members for FFT Analysis and Visualization

    // FFT parameters:
    enum
    {
        fftOrder = 11,         // FFT order: 2^11 = 2048 samples.
        fftSize = 1 << fftOrder  // FFT size (number of samples in FFT).
    };
    // JUCE's FFT object for performing FFT analysis.
    juce::dsp::FFT fft;
    // Windowing function to reduce spectral leakage in the FFT.
    juce::dsp::WindowingFunction<float> window;
    // FIFO buffer to store incoming audio samples for FFT processing.
    std::vector<float> fifo;
    // Index to track the current position in the FIFO.
    int fifoIndex = 0;
    // Vector used for FFT input and output data.
    std::vector<float> fftData;
    // Flag indicating if the next FFT block is ready to be processed.
    bool nextFFTBlockReady = false;
    // Data for drawing the FFT magnitude spectrum (scope data).
    std::vector<float> scopeData;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WaveformDisplay)
};
