#include "DJAudioPlayer.h"
#include "WaveformDisplay.h"  // For pushNextSampleIntoFifo
#include <cmath>

//==============================================================================
// Minimal looping reader implementation
//==============================================================================

namespace
{
    // A simple wrapper that resets the read position to 0 when the end is reached.
    // This allows continuous looping of the audio file.
    class LoopingAudioFormatReaderSource : public juce::AudioFormatReaderSource
    {
    public:
        // Constructor: Initializes with a given reader and a flag indicating if the reader should be deleted when done.
        LoopingAudioFormatReaderSource(juce::AudioFormatReader* readerToUse, bool deleteReaderWhenDone)
            : juce::AudioFormatReaderSource(readerToUse, deleteReaderWhenDone)
        {
        }

        // Override getNextAudioBlock to loop back to the beginning when the end is reached.
        void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override
        {
            juce::AudioFormatReaderSource::getNextAudioBlock(bufferToFill);
            // If we've reached or passed the end of the audio file, reset the read position to 0.
            if (getNextReadPosition() >= getTotalLength())
                setNextReadPosition(0);
        }
    };
}

//==============================================================================
// DJAudioPlayer Implementation
//==============================================================================

// Constructor: Initializes the DJAudioPlayer with a reference to an AudioFormatManager.
// This manager is used to handle various audio file formats.
DJAudioPlayer::DJAudioPlayer(juce::AudioFormatManager& _formatManager)
    : formatManager(_formatManager)
{
}

// Destructor: No explicit resource deallocation required here as smart pointers handle cleanup.
DJAudioPlayer::~DJAudioPlayer()
{
}

// prepareToPlay: Called before audio playback starts. Prepares transport sources and EQ filters.
void DJAudioPlayer::prepareToPlay(int samplesPerBlockExpected, double sr)
{
    sampleRate = sr;
    transportSource.prepareToPlay(samplesPerBlockExpected, sr);
    resampleSource.prepareToPlay(samplesPerBlockExpected, sr);

    // Reset the EQ filters for both channels.
    for (int ch = 0; ch < 2; ++ch)
    {
        lowFilter[ch].reset();
        midFilter[ch].reset();
        highFilter[ch].reset();
    }
    // Update filter coefficients based on the current EQ gain values.
    updateFilterCoefficients();
}

// getNextAudioBlock: Called repeatedly to fill a buffer with audio samples.
// Processes the audio through EQ filters and applies global effects.
void DJAudioPlayer::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    // First, get audio from the resampleSource (which handles playback speed changes).
    resampleSource.getNextAudioBlock(bufferToFill);

    // Process EQ filters on each channel if they are not bypassed.
    for (int ch = 0; ch < bufferToFill.buffer->getNumChannels(); ++ch)
    {
        if (!lowBypass)
            lowFilter[ch].processSamples(bufferToFill.buffer->getWritePointer(ch, bufferToFill.startSample),
                bufferToFill.numSamples);
        if (!midBypass)
            midFilter[ch].processSamples(bufferToFill.buffer->getWritePointer(ch, bufferToFill.startSample),
                bufferToFill.numSamples);
        if (!highBypass)
            highFilter[ch].processSamples(bufferToFill.buffer->getWritePointer(ch, bufferToFill.startSample),
                bufferToFill.numSamples);
    }

    // --- Apply New Global Effects ---
    const int numSamples = bufferToFill.numSamples;
    const int numChannels = bufferToFill.buffer->getNumChannels();

    // 1) Distortion / Overdrive (Drive):
    // Applies a tanh function to introduce soft clipping distortion.
    for (int ch = 0; ch < numChannels; ++ch)
    {
        float* channelData = bufferToFill.buffer->getWritePointer(ch, bufferToFill.startSample);
        for (int i = 0; i < numSamples; ++i)
        {
            float sample = channelData[i];
            float gainFactor = 1.0f + drive * 10.0f;
            channelData[i] = std::tanh(sample * gainFactor);
        }
    }

    // 2) Stereo Widening / Narrowing (Width):
    // Adjusts the balance between left and right channels by modifying the mid and side signals.
    if (numChannels >= 2)
    {
        float* leftChannel = bufferToFill.buffer->getWritePointer(0, bufferToFill.startSample);
        float* rightChannel = bufferToFill.buffer->getWritePointer(1, bufferToFill.startSample);
        for (int i = 0; i < numSamples; ++i)
        {
            float L = leftChannel[i];
            float R = rightChannel[i];
            float mid = (L + R) * 0.5f;
            float side = (L - R) * 0.5f;
            side *= stereoWidth;
            leftChannel[i] = mid + side;
            rightChannel[i] = mid - side;
        }
    }

    // 3) 8D Audio Effect:
    // Uses an LFO to modulate panning, creating a spatial audio effect.
    if (numChannels >= 2 && eightD > 0.0f)
    {
        float* leftChannel = bufferToFill.buffer->getWritePointer(0, bufferToFill.startSample);
        float* rightChannel = bufferToFill.buffer->getWritePointer(1, bufferToFill.startSample);
        float phaseIncrement = juce::MathConstants<float>::twoPi * eightDLFORate / static_cast<float>(sampleRate);
        for (int i = 0; i < numSamples; ++i)
        {
            float currentPhase = eightDLFOPhase + i * phaseIncrement;
            float panMod = std::sin(currentPhase);
            leftChannel[i] *= (1.0f + eightD * panMod);
            rightChannel[i] *= (1.0f - eightD * panMod);
        }
        // Increment the LFO phase.
        eightDLFOPhase += phaseIncrement * numSamples;
        // Wrap the phase value to keep it within 0 to 2*PI.
        while (eightDLFOPhase > juce::MathConstants<float>::twoPi)
            eightDLFOPhase -= juce::MathConstants<float>::twoPi;
    }

    // Feed samples to the WaveformDisplay for visualization.
    if (waveformDisplay != nullptr)
    {
        const float* leftChannel = bufferToFill.buffer->getReadPointer(0, bufferToFill.startSample);
        const float* rightChannel = (bufferToFill.buffer->getNumChannels() > 1)
            ? bufferToFill.buffer->getReadPointer(1, bufferToFill.startSample)
            : nullptr;
        for (int i = 0; i < numSamples; ++i)
        {
            float l = leftChannel[i];
            float r = (rightChannel != nullptr) ? rightChannel[i] : l;
            float mono = 0.5f * (l + r);
            // Push the averaged mono sample into the waveform display's FIFO.
            waveformDisplay->pushNextSampleIntoFifo(mono);
        }
    }
}

// releaseResources: Called when audio playback stops to free resources.
void DJAudioPlayer::releaseResources()
{
    transportSource.releaseResources();
    resampleSource.releaseResources();
}

// loadURL: Loads an audio file from the given URL.
// Wraps the reader in a looping source so that playback loops continuously.
void DJAudioPlayer::loadURL(juce::URL audioURL)
{
    auto* reader = formatManager.createReaderFor(audioURL.createInputStream(false));
    if (reader != nullptr)
    {
        // Wrap the AudioFormatReaderSource in our LoopingAudioFormatReaderSource for looping.
        std::unique_ptr<juce::AudioFormatReaderSource> newSource(
            new LoopingAudioFormatReaderSource(reader, true));
        transportSource.setSource(newSource.get(), 0, nullptr, reader->sampleRate);
        readerSource.reset(newSource.release());
    }
}

// play: Starts audio playback.
// Also sets the waveform display mode to FFT for visual feedback.
void DJAudioPlayer::play()
{
    transportSource.start();
    if (waveformDisplay != nullptr)
        waveformDisplay->setMode(WaveformDisplay::Mode_FFT);
}

// pause: Stops audio playback.
void DJAudioPlayer::pause()
{
    transportSource.stop();
}

// setVolume: Sets the playback volume (gain) between 0.0 and 1.0.
// Displays a debug message if the volume is out of range.
void DJAudioPlayer::setVolume(double vol)
{
    if (vol < 0.0 || vol > 1.0)
        DBG("DJAudioPlayer::setVolume: volume should be between 0.0 and 1.0");
    else
        transportSource.setGain(vol);
}

// setSpeed: Sets the playback speed by adjusting the resampling ratio.
// Displays a debug message if the ratio is out of the expected range.
void DJAudioPlayer::setSpeed(double ratio)
{
    if (ratio < 0.0 || ratio > 100.0)
        DBG("DJAudioPlayer::setSpeed: ratio should be between 0.0 and 100.0");
    else
        resampleSource.setResamplingRatio(ratio);
}

// setPosition: Sets the playback position in seconds.
void DJAudioPlayer::setPosition(double posInSecs)
{
    transportSource.setPosition(posInSecs);
}

// setPositionRelative: Sets the playback position as a fraction of the total track length (0.0 to 1.0).
// If the value is out of range, a debug message is displayed.
void DJAudioPlayer::setPositionRelative(double pos)
{
    if (pos < 0.0 || pos > 1.0)
    {
        DBG("DJAudioPlayer::setPositionRelative: pos should be between 0.0 and 1.0");
        return;
    }
    double length = transportSource.getLengthInSeconds();
    setPosition(length * pos);
}

// getPositionRelative: Returns the current playback position as a fraction of the total track length.
double DJAudioPlayer::getPositionRelative()
{
    double length = transportSource.getLengthInSeconds();
    if (length > 0)
        return transportSource.getCurrentPosition() / length;
    return 0.0;
}

// getCurrentPosition: Returns the current playback position in seconds.
double DJAudioPlayer::getCurrentPosition()
{
    return transportSource.getCurrentPosition();
}

// getLengthInSeconds: Returns the total length of the loaded audio track in seconds.
double DJAudioPlayer::getLengthInSeconds()
{
    return transportSource.getLengthInSeconds();
}

// setLowGain: Sets the gain for the low frequency band in dB and updates the filter coefficients.
void DJAudioPlayer::setLowGain(float gainDb)
{
    lowGainDb = gainDb;
    updateFilterCoefficients();
}

// setMidGain: Sets the gain for the mid frequency band in dB and updates the filter coefficients.
void DJAudioPlayer::setMidGain(float gainDb)
{
    midGainDb = gainDb;
    updateFilterCoefficients();
}

// setHighGain: Sets the gain for the high frequency band in dB and updates the filter coefficients.
void DJAudioPlayer::setHighGain(float gainDb)
{
    highGainDb = gainDb;
    updateFilterCoefficients();
}

// setLowBypass: Enables or disables bypass for the low frequency filter.
void DJAudioPlayer::setLowBypass(bool shouldBypass)
{
    lowBypass = shouldBypass;
}

// setMidBypass: Enables or disables bypass for the mid frequency filter.
void DJAudioPlayer::setMidBypass(bool shouldBypass)
{
    midBypass = shouldBypass;
}

// setHighBypass: Enables or disables bypass for the high frequency filter.
void DJAudioPlayer::setHighBypass(bool shouldBypass)
{
    highBypass = shouldBypass;
}

// updateFilterCoefficients: Recalculates and updates the IIR filter coefficients for each frequency band based on the current gain values.
void DJAudioPlayer::updateFilterCoefficients()
{
    auto lowCoeffs = juce::IIRCoefficients::makeLowShelf(sampleRate, 200.0, 0.7f,
        juce::Decibels::decibelsToGain(lowGainDb));
    auto midCoeffs = juce::IIRCoefficients::makePeakFilter(sampleRate, 1000.0, 0.7f,
        juce::Decibels::decibelsToGain(midGainDb));
    auto highCoeffs = juce::IIRCoefficients::makeHighShelf(sampleRate, 5000.0, 0.7f,
        juce::Decibels::decibelsToGain(highGainDb));

    for (int ch = 0; ch < 2; ++ch)
    {
        if (!lowBypass)
            lowFilter[ch].setCoefficients(lowCoeffs);
        if (!midBypass)
            midFilter[ch].setCoefficients(midCoeffs);
        if (!highBypass)
            highFilter[ch].setCoefficients(highCoeffs);
    }
}

// ------------------------------------------------------------------
// New effect control methods (replacing flanger, echo, bass boost)
// ------------------------------------------------------------------

// setDrive: Sets the distortion/overdrive effect intensity (drive) in the range 0.0 to 1.0.
void DJAudioPlayer::setDrive(float driveValue)
{
    drive = juce::jlimit(0.0f, 1.0f, driveValue);
    DBG("DJAudioPlayer::setDrive set to " << drive);
}

// setStereoWidth: Sets the stereo widening effect. Values greater than 1.0 widen the stereo image.
void DJAudioPlayer::setStereoWidth(float widthValue)
{
    stereoWidth = widthValue;
    DBG("DJAudioPlayer::setStereoWidth set to " << stereoWidth);
}

// setEightD: Sets the 8D audio effect intensity in the range 0.0 to 1.0.
void DJAudioPlayer::setEightD(float eightDValue)
{
    eightD = juce::jlimit(0.0f, 1.0f, eightDValue);
    DBG("DJAudioPlayer::setEightD set to " << eightD);
}

// ------------------------------------------------------------------
// Looping control method implementation
// ------------------------------------------------------------------

// setLooping: Enables or disables looping of the audio track.
// When enabled, playback will loop continuously.
void DJAudioPlayer::setLooping(bool shouldLoop)
{
    transportSource.setLooping(shouldLoop);
    DBG("DJAudioPlayer::setLooping set to " << (shouldLoop ? "true" : "false"));
}
