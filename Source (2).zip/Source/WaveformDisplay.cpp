#include "WaveformDisplay.h"
#include <algorithm>
#include <cmath>

//==============================================================================
// Constructor for WaveformDisplay
//==============================================================================
// Initializes the audio thumbnail, FFT components, and associated buffers.
// Registers this component as a change listener for the audio thumbnail and
// starts a timer to update the display approximately 30 times per second.
WaveformDisplay::WaveformDisplay(juce::AudioFormatManager& formatManager,
    juce::AudioThumbnailCache& cache)
    : audioThumb(512, formatManager, cache),      // Initialize the audio thumbnail with a cache size of 512.
    fft(fftOrder),                              // Initialize the FFT object with the defined order.
    window(fftSize, juce::dsp::WindowingFunction<float>::hann), // Create a Hann window to apply before FFT.
    fifo(fftSize, 0.0f),                        // Initialize the FIFO buffer with fftSize samples set to 0.
    fftData(2 * fftSize, 0.0f),                 // FFT data buffer is twice the size (real and imaginary parts).
    scopeData(fftSize / 2, 0.0f)                // Scope data for drawing the magnitude spectrum.
{
    // Add this component as a change listener to the audio thumbnail,
    // so it can repaint when the thumbnail data changes.
    audioThumb.addChangeListener(this);

    // Start a timer that fires at 30 Hz to periodically update the display.
    startTimerHz(30);
}

//==============================================================================
// Destructor for WaveformDisplay
//==============================================================================
// Stops the timer and removes this component as a change listener from the audio thumbnail.
WaveformDisplay::~WaveformDisplay()
{
    stopTimer();
    audioThumb.removeChangeListener(this);
}

//==============================================================================
// setMode
//==============================================================================
// Changes the visualization mode between thumbnail (time-domain) and FFT (frequency-domain).
// When switching to FFT mode, it resets the FIFO index and FFT readiness flag.
void WaveformDisplay::setMode(VisualizerMode newMode)
{
    mode = newMode;
    if (mode == Mode_FFT)
    {
        fifoIndex = 0;
        nextFFTBlockReady = false;
    }
    repaint();
}

//==============================================================================
// loadURL
//==============================================================================
// Loads an audio file from the provided URL into the audio thumbnail.
// Only local files are accepted; sets a flag to indicate whether a file was successfully loaded.
void WaveformDisplay::loadURL(const juce::URL& audioURL)
{
    fileLoaded = false;
    if (audioURL.isLocalFile())
    {
        juce::File audioFile = audioURL.getLocalFile();
        // Set the source of the audio thumbnail to the selected file.
        audioThumb.setSource(new juce::FileInputSource(audioFile));
        fileLoaded = true;
    }
    repaint();
}

//==============================================================================
// pushNextSampleIntoFifo
//==============================================================================
// Called from the audio thread to push incoming audio samples into a FIFO buffer,
// which is used later for performing FFT analysis. Only operates in FFT mode.
void WaveformDisplay::pushNextSampleIntoFifo(float sample)
{
    if (mode != Mode_FFT)
        return;

    if (fifoIndex < fftSize)
    {
        fifo[(size_t)fifoIndex++] = sample;
        // Once the FIFO is full, mark that the next FFT block is ready to be processed.
        if (fifoIndex == fftSize)
            nextFFTBlockReady = true;
    }
}

//==============================================================================
// timerCallback
//==============================================================================
// Timer callback function that runs on a non-audio thread.
// When in FFT mode and the FFT block is ready, copies the FIFO into the FFT data buffer,
// applies the windowing function, performs the FFT, updates the scope data (for drawing),
// and then resets the FIFO index for the next block.
void WaveformDisplay::timerCallback()
{
    if (mode == Mode_FFT && nextFFTBlockReady)
    {
        // Copy the collected samples from the FIFO into the FFT data vector.
        std::copy(fifo.begin(), fifo.end(), fftData.begin());
        // Zero out the remaining part of the FFT data buffer.
        std::fill(fftData.begin() + fftSize, fftData.end(), 0.0f);

        // Apply the windowing function to the FFT input data to reduce spectral leakage.
        window.multiplyWithWindowingTable(fftData.data(), fftSize);
        // Perform the FFT transformation on the windowed data.
        fft.performFrequencyOnlyForwardTransform(fftData.data());

        // Copy the FFT magnitude data to scopeData for drawing the frequency spectrum.
        for (int i = 0; i < fftSize / 2; ++i)
            scopeData[(size_t)i] = fftData[(size_t)i];

        // Reset the FIFO index and mark the FFT block as processed.
        fifoIndex = 0;
        nextFFTBlockReady = false;
        // Request a repaint to update the FFT visualization.
        repaint();
    }
}

//==============================================================================
// paint
//==============================================================================
// Draws the waveform display component.
// - Fills the background with black.
// - Draws a gradient border around the component.
// - Depending on the mode, either draws the audio thumbnail (if a file is loaded)
//   or displays a "No file loaded..." message, or draws the FFT visualization.
void WaveformDisplay::paint(juce::Graphics& g)
{
    // Fill the entire background with black.
    g.fillAll(juce::Colours::black);

    // Get the bounds of the component.
    juce::Rectangle<int> bounds = getLocalBounds();

    // Create a gradient for the border: from dark blue to dark purple.
    juce::ColourGradient borderGradient(juce::Colours::blue.darker(0.8f),
        (float)bounds.getX(), (float)bounds.getY(),
        juce::Colours::purple.darker(0.8f),
        (float)bounds.getRight(), (float)bounds.getBottom(),
        false);
    g.setGradientFill(borderGradient);
    // Draw a 2-pixel border around the component.
    g.drawRect(bounds, 2.0f);

    // Depending on the visualization mode...
    if (mode == Mode_Thumbnail)
    {
        if (fileLoaded)
        {
            // Create a gradient for the waveform display (from blue to purple).
            juce::ColourGradient waveformGradient(juce::Colours::blue,
                (float)bounds.getX(), (float)bounds.getY(),
                juce::Colours::purple,
                (float)bounds.getRight(), (float)bounds.getBottom(),
                false);
            g.setGradientFill(waveformGradient);

            // Use the audio thumbnail to draw the waveform across the entire component.
            audioThumb.drawChannel(g,
                bounds,
                0.0,
                audioThumb.getTotalLength(),
                0,
                1.0f);
        }
        else
        {
            // If no file is loaded, display a message.
            g.setColour(juce::Colours::grey);
            g.setFont(20.0f);
            g.drawFittedText("No file loaded...", bounds,
                juce::Justification::centred, 1);
        }
    }
    else // Mode_FFT
    {
        // Retrieve the dimensions of the component.
        float width = (float)getWidth();
        float height = (float)getHeight();

        // Draw a grid over the FFT visualization for reference.
        drawFFTGrid(g, width, height);

        // Set the drawing color for the FFT magnitude lines.
        g.setColour(juce::Colours::lightgreen);
        int numBins = (int)scopeData.size();
        // Determine the width of each FFT bin in the display.
        float binWidth = width / (float)numBins;

        // For each FFT bin, map the magnitude to a vertical line.
        for (int i = 0; i < numBins; ++i)
        {
            float magnitude = scopeData[(size_t)i];
            // Map the magnitude value to a scaled height for drawing.
            float scaledHeight = juce::jmap(magnitude, 0.0f, 10.0f, 0.0f, height);
            float x = i * binWidth;
            float y = height - scaledHeight;
            // Draw a line representing the magnitude of the frequency bin.
            g.drawLine(x, height, x, y, 2.0f);
        }
    }
}

//==============================================================================
// resized
//==============================================================================
// Called when the component's size changes; since there are no child components,
// nothing is done here.
void WaveformDisplay::resized()
{
    // No child components to layout.
}

//==============================================================================
// changeListenerCallback
//==============================================================================
// Callback function that listens for changes from the AudioThumbnail.
// When the audio thumbnail changes (for example, when a new file is loaded),
// the component is repainted.
void WaveformDisplay::changeListenerCallback(juce::ChangeBroadcaster* source)
{
    if (source == &audioThumb)
        repaint();
}

//==============================================================================
// drawFFTGrid
//==============================================================================
// Helper function to draw a grid on top of the FFT visualization.
// Draws vertical lines corresponding to frequency markers and horizontal lines for amplitude.
void WaveformDisplay::drawFFTGrid(juce::Graphics& g, float width, float height)
{
    // Predefined frequency markers (in Hz).
    std::vector<float> freqMarkers = { 20.0f, 50.0f, 100.0f, 200.0f,
                                       500.0f, 1000.0f, 2000.0f,
                                       5000.0f, 10000.0f, 20000.0f };

    float freqMin = 20.0f;
    float freqMax = 20000.0f;

    // Set a light grey color with some transparency for the grid lines.
    g.setColour(juce::Colours::grey.withAlpha(0.3f));

    // Draw vertical lines for each frequency marker.
    for (auto freq : freqMarkers)
    {
        // Skip markers outside the displayable frequency range.
        if (freq < freqMin || freq > freqMax)
            continue;

        // Normalize the frequency on a logarithmic scale between freqMin and freqMax.
        float normalized = (std::log10(freq) - std::log10(freqMin))
            / (std::log10(freqMax) - std::log10(freqMin));
        float x = normalized * width;
        // Draw a vertical line at the computed x-coordinate.
        g.drawLine(x, 0.0f, x, height, 1.0f);
    }

    // Draw horizontal lines to indicate amplitude levels.
    int numAmplitudeLines = 4;
    for (int i = 1; i <= numAmplitudeLines; ++i)
    {
        float fraction = (float)i / (float)(numAmplitudeLines + 1);
        float y = height * (1.0f - fraction);
        // Draw a horizontal line at the calculated y-coordinate.
        g.drawLine(0.0f, y, width, y, 1.0f);
    }

    // Draw frequency labels at the bottom of the component.
    g.setColour(juce::Colours::white);
    g.setFont(10.0f);
    for (auto freq : freqMarkers)
    {
        if (freq < freqMin || freq > freqMax)
            continue;

        // Normalize the frequency value.
        float normalized = (std::log10(freq) - std::log10(freqMin))
            / (std::log10(freqMax) - std::log10(freqMin));
        float x = normalized * width;
        // Create a text string for the frequency (in Hz).
        juce::String text = juce::String((int)freq) + " Hz";
        int textWidth = 40;
        int textHeight = 12;
        // Draw the frequency label centered at the bottom of the grid.
        g.drawFittedText(text,
            (int)(x - textWidth * 0.5f),
            (int)(height - textHeight),
            textWidth, textHeight,
            juce::Justification::centred, 1);
    }
}
