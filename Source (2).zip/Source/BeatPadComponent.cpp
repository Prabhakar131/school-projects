#include "BeatPadComponent.h"

// Example color scheme for 6 pads. Adjust to your liking.
static juce::Array<juce::Colour> padColours
{
    juce::Colour::fromRGB(0, 200, 255),   // bright cyan
    juce::Colour::fromRGB(255,   0, 255), // bright magenta
    juce::Colour::fromRGB(255, 192,   0), // gold
    juce::Colour::fromRGB(0, 255,   0),   // bright green
    juce::Colour::fromRGB(255,   0,   0), // bright red
    juce::Colour::fromRGB(128,   0, 255)   // purple
};

BeatPadComponent::BeatPadComponent()
{
    // Register basic audio formats (e.g., WAV, MP3, AIFF) for reading beat files.
    formatManager.registerBasicFormats();

    // Create 6 pad buttons dynamically.
    for (int i = 0; i < numPads; ++i)
    {
        auto* pad = new juce::TextButton();
        pad->setButtonText(""); // Remove text label from pad; the pad is visually styled.
        // Assign a colour from our predefined padColours array.
        juce::Colour padColor = padColours[i % padColours.size()];
        pad->setColour(juce::TextButton::buttonColourId, padColor);
        // Save the original colour for potential state changes.
        originalPadColours.add(padColor);
        // Set the custom LookAndFeel for a glowing pad appearance.
        pad->setLookAndFeel(&padLookAndFeel);
        // Register this component as a listener for button clicks.
        pad->addListener(this);
        // Add the pad button to our owned array and make it visible.
        pads.add(pad);
        addAndMakeVisible(pad);
    }

    // Load audio files from the "beats" folder into filePaths and setup transports.
    loadBeatsFromFolder();

    // Add each transport source (one per pad) to our internal mixer.
    for (int i = 0; i < numPads; ++i)
        mixerSource.addInputSource(&transportSources[i], false);

    // Start a timer to poll ~30 times per second to update pad playback states.
    startTimerHz(30);
}

BeatPadComponent::~BeatPadComponent()
{
    // Remove custom LookAndFeel for each pad before destruction.
    for (auto* pad : pads)
        pad->setLookAndFeel(nullptr);
    // Remove each transport source from the mixer to avoid dangling pointers.
    for (int i = 0; i < numPads; ++i)
        mixerSource.removeInputSource(&transportSources[i]);
}

void BeatPadComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    // Prepare the mixer source with the expected number of samples per block and the sample rate.
    mixerSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void BeatPadComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    // Delegate getting the next block of audio data to the mixer source.
    mixerSource.getNextAudioBlock(bufferToFill);
}

void BeatPadComponent::releaseResources()
{
    // Release audio resources held by the mixer source.
    mixerSource.releaseResources();
}

void BeatPadComponent::paint(juce::Graphics& g)
{
    // Fill the component background with black.
    g.fillAll(juce::Colours::black);
}

void BeatPadComponent::resized()
{
    // Get the available area to layout the pad buttons.
    auto area = getLocalBounds();
    int spacing = 10;      // Space between pads.
    int columns = 3;       // 3 columns for pad layout.
    int rows = 2;          // 2 rows for pad layout.
    area.reduce(spacing, spacing);  // Reduce area for outer margins.
    // Calculate width and height for each pad based on spacing and number of columns/rows.
    int padWidth = (area.getWidth() - (columns - 1) * spacing) / columns;
    int padHeight = (area.getHeight() - (rows - 1) * spacing) / rows;

    // Set bounds for each pad button.
    for (int i = 0; i < numPads; ++i)
    {
        int row = i / columns;
        int col = i % columns;
        int x = area.getX() + col * (padWidth + spacing);
        int y = area.getY() + row * (padHeight + spacing);
        pads[i]->setBounds(x, y, padWidth, padHeight);
    }
}

void BeatPadComponent::buttonClicked(juce::Button* button)
{
    // Iterate through the pads to determine which one was clicked.
    for (int i = 0; i < pads.size(); ++i)
    {
        if (button == pads[i])
        {
            // If no file path is set for this pad, do nothing.
            if (filePaths.size() <= i || filePaths[i].isEmpty())
                return;
            // Reset the transport's position to the beginning.
            transportSources[i].setPosition(0.0);
            // Start playback for the selected pad.
            transportSources[i].start();
            break;
        }
    }
}

void BeatPadComponent::timerCallback()
{
    // Optional: Update pad state (e.g., visual indicators) periodically.
}

void BeatPadComponent::loadBeatsFromFolder()
{
    // Locate the "beats" folder relative to this source file.
    juce::File sourceDir(String(__FILE__));
    sourceDir = sourceDir.getParentDirectory();
    juce::File beatsFolder = sourceDir.getChildFile("beats");

    // Check if the folder exists and is a directory.
    if (!beatsFolder.exists() || !beatsFolder.isDirectory())
    {
        DBG("[BeatPadComponent] 'beats' folder not found: " << beatsFolder.getFullPathName());
        return;
    }

    // Clear any existing file paths.
    filePaths.clear();
    // Allowed audio file extensions.
    static const char* exts[] = { ".mp3", ".wav", ".aif", ".aiff" };

    // Loop through the expected beat file names: beat_1, beat_2, ..., beat_6.
    for (int i = 1; i <= numPads; ++i)
    {
        juce::String baseName = "beat_" + juce::String(i);
        juce::File beatFile;
        bool found = false;
        // Try each extension to find a valid file.
        for (auto* ext : exts)
        {
            beatFile = beatsFolder.getChildFile(baseName + ext);
            if (beatFile.existsAsFile())
            {
                found = true;
                break;
            }
        }
        if (found)
        {
            // Store the full file path.
            filePaths.add(beatFile.getFullPathName());
            // Create an AudioFormatReader for the file.
            if (auto* reader = formatManager.createReaderFor(beatFile))
            {
                // Create a reader source and transfer ownership.
                readerSources[i - 1].reset(new juce::AudioFormatReaderSource(reader, true));
                // Set up the transport source with the reader source.
                transportSources[i - 1].setSource(readerSources[i - 1].get(),
                    0,
                    nullptr,
                    reader->sampleRate);
            }
            else
            {
                // Print a debug message if the reader could not be created.
                DBG("Could not create a reader for file: " << beatFile.getFullPathName());
            }
        }
        else
        {
            // Debug output if the beat file is not found.
            DBG("Beat file not found for: " << baseName);
        }
    }
}
