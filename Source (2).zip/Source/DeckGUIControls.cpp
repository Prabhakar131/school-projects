#include "DeckGUIControls.h"
#include <cmath>

//==============================================================================
// CustomLookAndFeel Implementation
//==============================================================================

// Constructor for CustomLookAndFeel.
// Currently does not initialize any specific settings.
CustomLookAndFeel::CustomLookAndFeel() {}

// Destructor for CustomLookAndFeel.
CustomLookAndFeel::~CustomLookAndFeel() {}

// Custom drawing for linear sliders.
// This implementation handles drawing for a vertical slider with custom visuals.
void CustomLookAndFeel::drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
    float sliderPos, float /*minSliderPos*/, float /*maxSliderPos*/,
    const juce::Slider::SliderStyle style, juce::Slider& slider)
{
    if (style == juce::Slider::LinearVertical)
    {
        // Calculate the x position and width for the slider track.
        const int trackX = x + width / 2;
        const int trackWidth = 6;

        // Draw the track background in black.
        g.setColour(juce::Colours::black);
        g.fillRect(trackX - trackWidth / 2, y, trackWidth, height);

        // Draw a white line as the slider track.
        g.setColour(juce::Colours::white);
        g.drawLine(trackX, y, trackX, y + height, 2.0f);

        // Compute the normalized slider value.
        float sliderRange = slider.getMaximum() - slider.getMinimum();
        float sliderValueNorm = (sliderRange > 0.0f)
            ? (slider.getValue() - slider.getMinimum()) / sliderRange : 0.0f;

        // Draw tick marks (without numeric labels) that turn green up to the slider's value.
        const int scaleX = trackX + 15;
        const int numTicks = 5;
        for (int i = 0; i <= numTicks; ++i)
        {
            // Calculate fractional position of each tick.
            float frac = (float)i / (float)numTicks;
            int tickY = y + static_cast<int>(height - height * frac);
            // Use green color for ticks up to current value, white otherwise.
            juce::Colour tickColour = (sliderValueNorm >= frac) ? juce::Colours::green
                : juce::Colours::white;
            g.setColour(tickColour);
            g.drawLine((float)scaleX, (float)tickY, (float)(scaleX + 10), (float)tickY, 1.0f);
        }

        // Draw the slider knob as a rectangular box with alternating white stripes.
        float knobCenterY = sliderPos;
        float knobHeight = 40.0f;
        float knobWidth = 20.0f;
        float knobTop = knobCenterY - knobHeight * 0.5f;
        float knobLeft = static_cast<float>(trackX) - knobWidth * 0.5f;
        juce::Rectangle<float> knobRect(knobLeft, knobTop, knobWidth, knobHeight);

        // Draw stripes on the knob.
        const int numStripes = 6;
        float stripeHeight = knobRect.getHeight() / (float)numStripes;
        for (int i = 0; i < numStripes; ++i)
        {
            float stripeY = knobTop + i * stripeHeight;
            juce::Rectangle<float> stripeRect(knobLeft, stripeY, knobWidth, stripeHeight - 1.0f);
            // Alternate stripe brightness.
            if ((i % 2) == 0)
                g.setColour(juce::Colours::white.darker(0.1f));
            else
                g.setColour(juce::Colours::white.brighter(0.1f));
            g.fillRect(stripeRect);
        }
        // Draw an outline for the knob.
        g.setColour(juce::Colours::darkgrey);
        g.drawRect(knobRect, 2.0f);
    }
    else
    {
        // Fallback to default drawing for other slider styles.
        juce::LookAndFeel_V4::drawLinearSlider(g, x, y, width, height,
            sliderPos, 0.0f, 1.0f, style, slider);
    }
}

// Custom drawing for rotary sliders.
// Draws a decagon that rotates based on the slider's value, along with tick marks.
void CustomLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
    float sliderPosProportional, float rotaryStartAngle,
    float rotaryEndAngle, juce::Slider& slider)
{
    // Calculate centre and radius for the rotary slider.
    float centreX = x + width * 0.5f;
    float centreY = y + height * 0.5f;
    float radius = juce::jmin((float)width, (float)height) * 0.4f;

    // Compute normalized slider value.
    float sliderRange = slider.getMaximum() - slider.getMinimum();
    float sliderValueNorm = (sliderRange > 0.0f)
        ? (slider.getValue() - slider.getMinimum()) / sliderRange : 0.0f;

    // Calculate the angle corresponding to the current slider position.
    float angleRange = rotaryEndAngle - rotaryStartAngle;
    float sliderAngle = rotaryStartAngle + sliderPosProportional * angleRange;

    // Create a decagon (10-sided polygon) path.
    juce::Path decagon;
    const int numSides = 10;
    for (int i = 0; i < numSides; ++i)
    {
        float fraction = (float)i / (float)numSides;
        float angle = juce::MathConstants<float>::twoPi * fraction - juce::MathConstants<float>::halfPi;
        float px = centreX + radius * std::cos(angle);
        float py = centreY + radius * std::sin(angle);
        if (i == 0)
            decagon.startNewSubPath(px, py);
        else
            decagon.lineTo(px, py);
    }
    decagon.closeSubPath();

    // Rotate the decagon according to the slider angle.
    juce::AffineTransform rotation = juce::AffineTransform::rotation(sliderAngle, centreX, centreY);
    juce::Path rotatedDecagon;
    rotatedDecagon.addPath(decagon, rotation);

    // Fill and stroke the rotated decagon.
    g.setColour(juce::Colours::white);
    g.fillPath(rotatedDecagon);
    g.setColour(juce::Colours::darkgrey);
    g.strokePath(rotatedDecagon, juce::PathStrokeType(2.0f));

    // Draw tick marks around the decagon.
    const int numTicks = numSides;
    float tickLength = 5.0f;
    for (int i = 0; i < numTicks; ++i)
    {
        float tickAngle = juce::MathConstants<float>::twoPi * i / numSides - juce::MathConstants<float>::halfPi;
        float tickFraction = (float)i / (float)numSides;
        // Tick color changes based on slider value.
        juce::Colour tickColour = (sliderValueNorm >= tickFraction)
            ? juce::Colours::green
            : juce::Colours::white;
        g.setColour(tickColour);

        // Calculate inner and outer points for each tick.
        float innerX = centreX + radius * std::cos(tickAngle);
        float innerY = centreY + radius * std::sin(tickAngle);
        float outerX = centreX + (radius + tickLength) * std::cos(tickAngle);
        float outerY = centreY + (radius + tickLength) * std::sin(tickAngle);
        g.drawLine(innerX, innerY, outerX, outerY, 2.0f);
    }
}

// Custom button background drawing.
// Draws the button with different effects when hovered or clicked, and custom icons for play, pause, and loop.
void CustomLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& button,
    const juce::Colour& /*backgroundColour*/,
    bool isMouseOverButton, bool isButtonDown)
{
    // Get the button bounds.
    auto bounds = button.getLocalBounds().toFloat();

    // Fill background with black.
    g.fillAll(juce::Colours::black);

    // Overlay with green tint when button is clicked or hovered.
    if (isButtonDown)
        g.fillAll(juce::Colours::green.withAlpha(0.5f));
    else if (isMouseOverButton)
        g.fillAll(juce::Colours::green.withAlpha(0.2f));

    // Set drawing colour to white for icons.
    g.setColour(juce::Colours::white);

    // Get the button name in lowercase to determine which icon to draw.
    juce::String btnName = button.getName().toLowerCase();

    if (btnName.contains("play"))
    {
        // Draw a play icon as a triangle.
        juce::Path triangle;
        float halfHeight = bounds.getHeight() * 0.3f;
        float centerY = bounds.getCentreY();
        float leftX = bounds.getWidth() * 0.3f;
        triangle.startNewSubPath(leftX, centerY - halfHeight);
        triangle.lineTo(leftX, centerY + halfHeight);
        triangle.lineTo(leftX + halfHeight * 2.0f, centerY);
        triangle.closeSubPath();
        g.fillPath(triangle);
    }
    else if (btnName.contains("pause"))
    {
        // Draw a pause icon as two vertical rectangles.
        float rectWidth = bounds.getWidth() * 0.15f;
        float gap = rectWidth * 0.5f;
        float leftX = bounds.getWidth() * 0.3f;
        float topY = bounds.getHeight() * 0.2f;
        float h = bounds.getHeight() * 0.6f;
        g.fillRect(leftX, topY, rectWidth, h);
        g.fillRect(leftX + rectWidth + gap, topY, rectWidth, h);
    }
    else if (btnName.contains("loop"))
    {
        // Draw a loop icon using an infinity symbol.
        float cx = bounds.getCentreX();
        float cy = bounds.getCentreY();
        // Determine separation and sizes for the loops.
        float d = bounds.getWidth() * 0.3f;         // horizontal separation between loop centers
        float loopRadiusX = d * 0.5f;                 // horizontal radius of each loop
        float loopRadiusY = bounds.getHeight() * 0.3f;  // vertical radius of each loop

        juce::Path infinityPath;
        // Start at the leftmost point of the left loop.
        infinityPath.startNewSubPath(cx - d / 2 - loopRadiusX, cy);
        // Upper half of left loop and connect to the crossing point.
        infinityPath.cubicTo(cx - d / 2 - loopRadiusX, cy - loopRadiusY,
            cx - d / 2 + loopRadiusX, cy - loopRadiusY,
            cx, cy);
        // Upper half of right loop.
        infinityPath.cubicTo(cx + d / 2 - loopRadiusX, cy - loopRadiusY,
            cx + d / 2 + loopRadiusX, cy - loopRadiusY,
            cx + d / 2 + loopRadiusX, cy);
        // Lower half of right loop and back to the crossing.
        infinityPath.cubicTo(cx + d / 2 + loopRadiusX, cy + loopRadiusY,
            cx + d / 2 - loopRadiusX, cy + loopRadiusY,
            cx, cy);
        // Lower half of left loop.
        infinityPath.cubicTo(cx - d / 2 + loopRadiusX, cy + loopRadiusY,
            cx - d / 2 - loopRadiusX, cy + loopRadiusY,
            cx - d / 2 - loopRadiusX, cy);
        // Draw the infinity symbol.
        g.strokePath(infinityPath, juce::PathStrokeType(2.0f));
    }
}

//==============================================================================
// DeckGUIControls Implementation
//==============================================================================

// Constructor for DeckGUIControls.
// Initializes all the GUI components (sliders, knobs, buttons, labels)
// and sets up their default properties and callbacks.
DeckGUIControls::DeckGUIControls()
{
    // Apply the custom look and feel to this component.
    setLookAndFeel(&customLNF);

    // --- Sliders (Volume, Speed, Position) ---
    // Configure each slider's style and remove the text box.
    volumeSlider.setSliderStyle(juce::Slider::LinearVertical);
    volumeSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    speedSlider.setSliderStyle(juce::Slider::LinearVertical);
    speedSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    positionSlider.setSliderStyle(juce::Slider::LinearVertical);
    positionSlider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);

    // Set slider ranges and default values.
    volumeSlider.setRange(0.0, 1.0, 0.01);
    volumeSlider.setValue(0.8);
    // When the volume slider value changes, update the audio player's volume.
    volumeSlider.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setVolume(volumeSlider.getValue());
        };

    speedSlider.setRange(0.5, 2.0, 0.01);
    speedSlider.setValue(1.0);
    // When the speed slider value changes, update the audio player's playback speed.
    speedSlider.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setSpeed(speedSlider.getValue());
        };

    positionSlider.setRange(0.0, 1.0, 0.01);
    positionSlider.setValue(0.0);
    // When the position slider value changes, update the audio player's playback position.
    positionSlider.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setPositionRelative(positionSlider.getValue());
        };

    // Set text and centering for slider labels.
    volumeLabel.setText("Volume", juce::dontSendNotification);
    speedLabel.setText("Speed", juce::dontSendNotification);
    positionLabel.setText("Position", juce::dontSendNotification);
    volumeLabel.setJustificationType(juce::Justification::centred);
    speedLabel.setJustificationType(juce::Justification::centred);
    positionLabel.setJustificationType(juce::Justification::centred);

    // Add sliders and labels to the component.
    addAndMakeVisible(volumeSlider);
    addAndMakeVisible(speedSlider);
    addAndMakeVisible(positionSlider);
    addAndMakeVisible(volumeLabel);
    addAndMakeVisible(speedLabel);
    addAndMakeVisible(positionLabel);

    // --- Knobs (Low, Mid, High) ---
    // Configure each knob's style and remove the text box.
    lowKnob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    lowKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    midKnob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    midKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    highKnob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    highKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);

    // Set knob ranges and default values for EQ gain (in dB).
    lowKnob.setRange(-12.0, 12.0, 0.1);
    lowKnob.setValue(0.0);
    // Update low frequency gain in the audio player when changed.
    lowKnob.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setLowGain(lowKnob.getValue());
        };

    midKnob.setRange(-12.0, 12.0, 0.1);
    midKnob.setValue(0.0);
    // Update mid frequency gain in the audio player when changed.
    midKnob.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setMidGain(midKnob.getValue());
        };

    highKnob.setRange(-12.0, 12.0, 0.1);
    highKnob.setValue(0.0);
    // Update high frequency gain in the audio player when changed.
    highKnob.onValueChange = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->setHighGain(highKnob.getValue());
        };

    // Set text and centering for knob labels.
    lowLabel.setText("Low", juce::dontSendNotification);
    midLabel.setText("Mid", juce::dontSendNotification);
    highLabel.setText("High", juce::dontSendNotification);
    lowLabel.setJustificationType(juce::Justification::centred);
    midLabel.setJustificationType(juce::Justification::centred);
    highLabel.setJustificationType(juce::Justification::centred);

    // Add knobs and labels to the component.
    addAndMakeVisible(lowKnob);
    addAndMakeVisible(midKnob);
    addAndMakeVisible(highKnob);
    addAndMakeVisible(lowLabel);
    addAndMakeVisible(midLabel);
    addAndMakeVisible(highLabel);

    // --- Buttons (Play, Pause, Loop) and their labels ---
    // Initialize button texts as empty since custom icons will be drawn.
    playButton.setButtonText("");
    pauseButton.setButtonText("");
    loopButton.setButtonText("");

    // Set names for buttons to be used in custom drawing.
    playButton.setName("play");
    pauseButton.setName("pause");
    loopButton.setName("loop");

    // Define the onClick behaviour for the play button.
    playButton.onClick = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->play();
        };
    // Define the onClick behaviour for the pause button.
    pauseButton.onClick = [this]()
        {
            if (audioPlayer != nullptr)
                audioPlayer->pause();
        };
    // Define the onClick behaviour for the loop button.
    loopButton.onClick = [this]()
        {
            // Toggle the looping state.
            loopState = !loopState;
            if (audioPlayer != nullptr)
                audioPlayer->setLooping(loopState);
        };

    // Set text and centering for button labels.
    playLabel.setText("Play", juce::dontSendNotification);
    pauseLabel.setText("Pause", juce::dontSendNotification);
    loopLabel.setText("Loop", juce::dontSendNotification);
    playLabel.setJustificationType(juce::Justification::centred);
    pauseLabel.setJustificationType(juce::Justification::centred);
    loopLabel.setJustificationType(juce::Justification::centred);

    // Add buttons and labels to the component.
    addAndMakeVisible(playButton);
    addAndMakeVisible(pauseButton);
    addAndMakeVisible(loopButton);
    addAndMakeVisible(playLabel);
    addAndMakeVisible(pauseLabel);
    addAndMakeVisible(loopLabel);
}

// Destructor for DeckGUIControls.
// Resets the look and feel to prevent dangling pointer issues.
DeckGUIControls::~DeckGUIControls()
{
    setLookAndFeel(nullptr);
}

// Sets the audio player that this GUI will interact with.
void DeckGUIControls::setAudioPlayer(DJAudioPlayer* newPlayer)
{
    audioPlayer = newPlayer;
}

// Paint method for DeckGUIControls.
// Fills the component background with black.
void DeckGUIControls::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::black);
}

// Called when the component is resized.
// Lays out all subcomponents (buttons, sliders, knobs, labels) in a grid.
void DeckGUIControls::resized()
{
    // Get the available area.
    auto area = getLocalBounds();
    int rowHeight = area.getHeight() / 3;
    const int labelHeight = 20;
    const int labelOffset = 5;

    // --- Top row: buttons with labels underneath ---
    auto topRow = area.removeFromTop(rowHeight);
    // Split top row into button area and label area.
    auto buttonArea = topRow.removeFromTop(rowHeight - labelHeight);
    auto labelArea = topRow; // remaining height for labels

    {
        // Divide button area into three parts.
        int buttonWidth = buttonArea.getWidth() / 3;
        auto playButtonArea = buttonArea.removeFromLeft(buttonWidth).reduced(5);
        auto pauseButtonArea = buttonArea.removeFromLeft(buttonWidth).reduced(5);
        auto loopButtonArea = buttonArea.reduced(5);

        // Set bounds for each button.
        playButton.setBounds(playButtonArea);
        pauseButton.setBounds(pauseButtonArea);
        loopButton.setBounds(loopButtonArea);

        // Divide label area into three parts.
        int labelWidth = labelArea.getWidth() / 3;
        auto playLabelArea = labelArea.removeFromLeft(labelWidth);
        auto pauseLabelArea = labelArea.removeFromLeft(labelWidth);
        auto loopLabelArea = labelArea;

        // Set bounds for each label, with an offset.
        playLabel.setBounds(playLabelArea.withTrimmedTop(labelOffset));
        pauseLabel.setBounds(pauseLabelArea.withTrimmedTop(labelOffset));
        loopLabel.setBounds(loopLabelArea.withTrimmedTop(labelOffset));
    }

    // --- Middle row: sliders with labels ---
    auto midRow = area.removeFromTop(rowHeight);
    {
        // Divide the midRow area into three parts.
        int sliderWidth = midRow.getWidth() / 3;
        auto volArea = midRow.removeFromLeft(sliderWidth);
        auto spdArea = midRow.removeFromLeft(sliderWidth);
        auto posArea = midRow;

        // Set bounds for volume slider and its label.
        volumeSlider.setBounds(volArea.reduced(10));
        {
            auto volLabelBounds = volArea.removeFromBottom(labelHeight);
            volLabelBounds.translate(0, labelOffset);
            volumeLabel.setBounds(volLabelBounds);
        }

        // Set bounds for speed slider and its label.
        speedSlider.setBounds(spdArea.reduced(10));
        {
            auto spdLabelBounds = spdArea.removeFromBottom(labelHeight);
            spdLabelBounds.translate(0, labelOffset);
            speedLabel.setBounds(spdLabelBounds);
        }

        // Set bounds for position slider and its label.
        positionSlider.setBounds(posArea.reduced(10));
        {
            auto posLabelBounds = posArea.removeFromBottom(labelHeight);
            posLabelBounds.translate(0, labelOffset);
            positionLabel.setBounds(posLabelBounds);
        }
    }

    // --- Bottom row: knobs with labels ---
    // Adjust the knob areas upward slightly.
    const int knobYOffset = -5;
    auto botRow = area;
    {
        // Divide bottom row into three parts.
        int knobWidth = botRow.getWidth() / 3;
        auto lowArea = botRow.removeFromLeft(knobWidth);
        auto midArea = botRow.removeFromLeft(knobWidth);
        auto highArea = botRow; // remaining area

        // Set bounds for low knob and its label.
        lowKnob.setBounds(lowArea.reduced(10).translated(0, knobYOffset));
        {
            auto lowLabelBounds = lowArea.removeFromBottom(labelHeight);
            lowLabelBounds.translate(0, labelOffset + knobYOffset);
            lowLabel.setBounds(lowLabelBounds);
        }

        // Set bounds for mid knob and its label.
        midKnob.setBounds(midArea.reduced(10).translated(0, knobYOffset));
        {
            auto midLabelBounds = midArea.removeFromBottom(labelHeight);
            midLabelBounds.translate(0, labelOffset + knobYOffset);
            midLabel.setBounds(midLabelBounds);
        }

        // Set bounds for high knob and its label.
        highKnob.setBounds(highArea.reduced(10).translated(0, knobYOffset));
        {
            auto highLabelBounds = highArea.removeFromBottom(labelHeight);
            highLabelBounds.translate(0, labelOffset + knobYOffset);
            highLabel.setBounds(highLabelBounds);
        }
    }
}
